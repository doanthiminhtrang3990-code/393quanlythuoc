/**
 * Utility helper functions for formatting dates, currencies, and numbers
 */

export function formatDateVN(dateStr: string | undefined | null): string {
  if (!dateStr) return '---';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  } catch {
    return dateStr;
  }
}

export function formatVND(amount: number | undefined | null): string {
  if (amount === undefined || amount === null) return '0 đ';
  return amount.toLocaleString('vi-VN') + ' đ';
}

export function formatNumber(num: number | undefined | null): string {
  if (num === undefined || num === null) return '0';
  return num.toLocaleString('vi-VN');
}

export function getDaysRemaining(expDateStr: string | undefined | null): number {
  if (!expDateStr) return 999;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const exp = new Date(expDateStr);
  exp.setHours(0, 0, 0, 0);
  const diffTime = exp.getTime() - now.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}
