import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Plus,
  Upload,
  Download,
  Filter,
  UserCheck,
  AlertTriangle,
  Heart,
  Eye,
  Edit2,
  Trash2,
  X,
  Check,
  FileSpreadsheet,
  Phone,
  ShieldAlert,
  Stethoscope,
  Info,
} from 'lucide-react';
import { db, formatDateVN } from '../services/db';
import { Student } from '../types';

interface StudentDirectoryProps {
  onSelectStudentForProfile?: (studentId: string) => void;
  onSelectStudentForIntake?: (studentId: string) => void;
  onNavigate?: (tab: string, filter?: string) => void;
}

export const StudentDirectory: React.FC<StudentDirectoryProps> = ({
  onSelectStudentForProfile,
  onSelectStudentForIntake,
  onNavigate,
}) => {
  const [students, setStudents] = useState<Student[]>(() => db.getStudents());
  const classes = db.getSchoolClasses();

  // Filters
  const [selectedGrade, setSelectedGrade] = useState<number | 'all'>('all');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [healthFilter, setHealthFilter] = useState<'all' | 'special' | 'normal'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [deleteConfirmStudent, setDeleteConfirmStudent] = useState<Student | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    studentCode: '',
    fullName: '',
    birthDate: '2014-01-01',
    gender: 'Nam' as 'Nam' | 'Nữ',
    grade: 6,
    className: '6/1',
    schoolYear: '2026-2027',
    citizenId: '',
    healthInsuranceCode: '',
    parentName: '',
    parentPhone: '',
    address: 'Xã Đông Thạnh, Hóc Môn, TP.HCM',
    bloodType: 'O',
    allergies: '',
    chronicConditions: '',
    specialAttention: false,
    notes: '',
  });

  // Import state
  const [importRows, setImportRows] = useState<any[]>([]);
  const [importFileName, setImportFileName] = useState('');
  const [importErrors, setImportErrors] = useState<string[]>([]);
  const [importSuccessCount, setImportSuccessCount] = useState<number | null>(null);

  const refreshList = () => {
    setStudents(db.getStudents());
  };

  // Filtered Students
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      if (selectedGrade !== 'all' && s.grade !== selectedGrade) return false;
      if (selectedClass !== 'all' && s.className !== selectedClass) return false;
      if (healthFilter === 'special' && !s.specialAttention) return false;
      if (healthFilter === 'normal' && s.specialAttention) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = s.fullName.toLowerCase().includes(q);
        const matchesCode = s.studentCode.toLowerCase().includes(q);
        const matchesPhone = s.parentPhone ? s.parentPhone.includes(q) : false;
        const matchesInsurance = s.healthInsuranceCode ? s.healthInsuranceCode.toLowerCase().includes(q) : false;
        if (!matchesName && !matchesCode && !matchesPhone && !matchesInsurance) return false;
      }
      return true;
    });
  }, [students, selectedGrade, selectedClass, healthFilter, searchQuery]);

  const stats = useMemo(() => {
    const total = students.length;
    const special = students.filter((s) => s.specialAttention).length;
    const grade6 = students.filter((s) => s.grade === 6).length;
    const grade7 = students.filter((s) => s.grade === 7).length;
    const grade8 = students.filter((s) => s.grade === 8).length;
    const grade9 = students.filter((s) => s.grade === 9).length;
    return { total, special, grade6, grade7, grade8, grade9 };
  }, [students]);

  // Open add modal
  const handleOpenAdd = () => {
    const nextCodeNum = students.length + 1;
    const autoCode = `HS${String(nextCodeNum).padStart(4, '0')}`;
    setFormData({
      studentCode: autoCode,
      fullName: '',
      birthDate: '2014-01-01',
      gender: 'Nam',
      grade: 6,
      className: '6/1',
      schoolYear: '2026-2027',
      citizenId: '',
      healthInsuranceCode: '',
      parentName: '',
      parentPhone: '',
      address: 'Xã Đông Thạnh, Huyện Hóc Môn, TP.HCM',
      bloodType: 'O',
      allergies: '',
      chronicConditions: '',
      specialAttention: false,
      notes: '',
    });
    setEditingStudent(null);
    setErrorMessage(null);
    setIsAddModalOpen(true);
  };

  // Open edit modal
  const handleOpenEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({
      studentCode: student.studentCode,
      fullName: student.fullName,
      birthDate: student.birthDate,
      gender: student.gender,
      grade: student.grade,
      className: student.className,
      schoolYear: student.schoolYear,
      citizenId: student.citizenId || '',
      healthInsuranceCode: student.healthInsuranceCode || '',
      parentName: student.parentName || '',
      parentPhone: student.parentPhone || '',
      address: student.address || '',
      bloodType: student.bloodType || 'O',
      allergies: student.allergies || '',
      chronicConditions: student.chronicConditions || '',
      specialAttention: !!student.specialAttention,
      notes: student.notes || '',
    });
    setErrorMessage(null);
    setIsAddModalOpen(true);
  };

  // Submit Add or Edit
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    try {
      if (editingStudent) {
        db.updateStudent(editingStudent.id, {
          ...formData,
          specialAttention: !!formData.specialAttention || !!formData.allergies || !!formData.chronicConditions,
        });
        setSuccessMessage(`Đã cập nhật học sinh ${formData.fullName}`);
      } else {
        db.addStudent({
          ...formData,
          specialAttention: !!formData.specialAttention || !!formData.allergies || !!formData.chronicConditions,
        });
        setSuccessMessage(`Đã thêm học sinh ${formData.fullName}`);
      }
      setIsAddModalOpen(false);
      refreshList();
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setErrorMessage(err.message);
    }
  };

  // Delete student
  const handleDeleteConfirm = () => {
    if (!deleteConfirmStudent) return;
    try {
      db.deleteStudent(deleteConfirmStudent.id);
      setSuccessMessage(`Đã xóa học sinh ${deleteConfirmStudent.fullName}`);
      setDeleteConfirmStudent(null);
      refreshList();
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(`Lỗi: ${err.message}`);
    }
  };

  // Sample CSV / Excel Download
  const handleDownloadSampleExcel = () => {
    const headers = [
      'Mã học sinh',
      'Họ và tên',
      'Lớp',
      'Giới tính',
      'Ngày sinh (YYYY-MM-DD)',
      'Khối',
      'Phụ huynh',
      'SĐT phụ huynh',
      'Mã BHYT',
      'CCCD/Định danh',
      'Dị ứng',
      'Bệnh nền',
    ];
    const sampleRows = [
      [
        'HS0050',
        'Nguyễn Gia Hưng',
        '6/1',
        'Nam',
        '2014-05-10',
        '6',
        'Nguyễn Văn Thắng',
        '0912345678',
        'GD4790123456888',
        '079214008888',
        'Dị ứng hải sản',
        'Không',
      ],
      [
        'HS0051',
        'Trần Khánh Vy',
        '6/2',
        'Nữ',
        '2014-09-18',
        '6',
        'Lê Thị Hương',
        '0987654321',
        'GD4790123456889',
        '079314008889',
        'Không',
        'Cận thị 2.0 diop',
      ],
    ];

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...sampleRows.map((r) => r.map((f) => `"${f}"`).join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Mau_Danh_Sach_Hoc_Sinh_THCS_Dong_Thanh.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export Filtered Student List to CSV/Excel
  const handleExportStudentsExcel = () => {
    const headers = [
      'STT',
      'Mã học sinh',
      'Họ và tên',
      'Lớp',
      'Khối',
      'Giới tính',
      'Ngày sinh',
      'Mã BHYT',
      'Họ tên phụ huynh',
      'Số điện thoại',
      'Địa chỉ',
      'Nhóm máu',
      'Dị ứng',
      'Bệnh nền',
      'Theo dõi đặc biệt',
    ];

    const rows = filteredStudents.map((s, idx) => [
      idx + 1,
      s.studentCode,
      s.fullName,
      s.className,
      s.grade,
      s.gender,
      formatDateVN(s.birthDate),
      s.healthInsuranceCode || '',
      s.parentName || '',
      s.parentPhone || '',
      s.address || '',
      s.bloodType || '',
      s.allergies || 'Không',
      s.chronicConditions || 'Không',
      s.specialAttention ? 'Có' : 'Không',
    ]);

    const csvContent =
      '\uFEFF' +
      [
        `"DANH SÁCH HỌC SINH - TRƯỜNG THCS ĐÔNG THẠNH"`,
        `"Năm học: 2026-2027 | Ngày xuất: ${new Date().toLocaleDateString('vi-VN')} | Tổng số: ${filteredStudents.length} học sinh"`,
        '',
        headers.join(','),
        ...rows.map((r) => r.map((f) => `"${f}"`).join(',')),
      ].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Danh_Sach_Hoc_Sinh_THCS_Dong_Thanh_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Handle CSV / Excel file drop / selection
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportFileName(file.name);
    setImportErrors([]);
    setImportSuccessCount(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = (event.target?.result as string) || '';
        // Parse CSV
        const lines = text.split(/\r\n|\n/).filter((l) => l.trim().length > 0);
        if (lines.length < 2) {
          setImportErrors(['Tệp không có dữ liệu hợp lệ hoặc chỉ có tiêu đề.']);
          return;
        }

        // Detect if line 0 is a title row
        let headerIndex = 0;
        if (lines[0].toLowerCase().includes('danh sách') || !lines[0].includes(',')) {
          headerIndex = 1;
        }

        const headerLine = lines[headerIndex] || '';
        const headers = headerLine
          .split(',')
          .map((h) => h.replace(/^["']|["']$/g, '').trim());

        const parsedRows: any[] = [];
        for (let i = headerIndex + 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;

          // Simple CSV line split supporting quotes
          const regex = /(".*?"|[^",]+)(?=\s*,|\s*$)/g;
          const matches = line.match(regex) || line.split(',');
          const values = matches.map((m) => m.replace(/^["']|["']$/g, '').trim());

          const rowObj: Record<string, string> = {};
          headers.forEach((h, idx) => {
            rowObj[h] = values[idx] || '';
          });
          parsedRows.push(rowObj);
        }

        setImportRows(parsedRows);
      } catch (err: any) {
        setImportErrors([`Lỗi khi đọc tệp: ${err.message}`]);
      }
    };
    reader.readAsText(file, 'UTF-8');
  };

  // Confirm Import
  const handleConfirmImport = () => {
    if (importRows.length === 0) return;
    const result = db.importStudentsFromExcel(importRows);
    setImportSuccessCount(result.added);
    setImportErrors(result.errors);
    refreshList();
    if (result.added > 0) {
      setSuccessMessage(`Đã nhập thành công ${result.added} học sinh!`);
      setTimeout(() => setSuccessMessage(null), 4000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Quick Stats */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
              GIAI ĐOẠN 3
            </span>
            <h1 className="text-xl font-bold text-slate-900">Quản Lý Hồ Sơ Học Sinh</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Trường THCS Đông Thạnh • Quản lý danh sách, tiền sử dị ứng, bệnh nền và liên kết khám phòng y tế
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="btn-add-student"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm học sinh</span>
          </button>

          <button
            id="btn-import-students"
            onClick={() => {
              setIsImportModalOpen(true);
              setImportRows([]);
              setImportFileName('');
              setImportErrors([]);
              setImportSuccessCount(null);
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-semibold border border-blue-200 transition-colors"
          >
            <Upload className="w-4 h-4" />
            <span>Import Excel</span>
          </button>

          <button
            id="btn-export-students"
            onClick={handleExportStudentsExcel}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Xuất Excel</span>
          </button>
        </div>
      </div>

      {/* Success Notification Alert */}
      {successMessage && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 px-4 py-3 rounded-xl flex items-center gap-2 text-xs font-medium animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-medium text-slate-500">Tổng số học sinh</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{stats.total}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Toàn trường 4 khối</p>
        </div>

        <div className="bg-rose-50/70 p-3.5 rounded-xl border border-rose-200 shadow-xs">
          <p className="text-[11px] font-medium text-rose-700 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-rose-600" />
            <span>Theo dõi đặc biệt</span>
          </p>
          <p className="text-xl font-bold text-rose-700 mt-1">{stats.special}</p>
          <p className="text-[10px] text-rose-600/80 mt-0.5">Có dị ứng hoặc bệnh nền</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-medium text-slate-500">Khối 6</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{stats.grade6}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Lớp 6/1, 6/2</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-medium text-slate-500">Khối 7</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{stats.grade7}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Lớp 7/1, 7/2, 7/3</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-medium text-slate-500">Khối 8</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{stats.grade8}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Lớp 8/1, 8/2</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-medium text-slate-500">Khối 9</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{stats.grade9}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Lớp 9/1, 9/2</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-search-student"
              type="text"
              placeholder="Tìm theo họ tên, mã học sinh (HS0001), SĐT phụ huynh, mã BHYT..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Grade selection */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            <span className="text-xs font-semibold text-slate-600 whitespace-nowrap mr-1">Khối:</span>
            {(['all', 6, 7, 8, 9] as const).map((g) => (
              <button
                key={g}
                onClick={() => {
                  setSelectedGrade(g);
                  setSelectedClass('all');
                }}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  selectedGrade === g
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {g === 'all' ? 'Tất cả' : `Khối ${g}`}
              </button>
            ))}
          </div>

          {/* Class selection */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-600 whitespace-nowrap">Lớp:</span>
            <select
              id="select-filter-class"
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600 font-medium"
            >
              <option value="all">Tất cả các lớp</option>
              {classes
                .filter((c) => selectedGrade === 'all' || c.grade === selectedGrade)
                .map((c) => (
                  <option key={c.id} value={c.name}>
                    Lớp {c.name} ({c.homeroomTeacher || 'GVCN'})
                  </option>
                ))}
            </select>
          </div>

          {/* Health Attention Filter */}
          <div className="flex items-center gap-1.5">
            <select
              id="select-filter-health"
              value={healthFilter}
              onChange={(e) => setHealthFilter(e.target.value as any)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600 font-medium"
            >
              <option value="all">Tất cả sức khỏe</option>
              <option value="special">⚠️ Cần theo dõi đặc biệt</option>
              <option value="normal">✓ Thể trạng bình thường</option>
            </select>
          </div>
        </div>

        {/* Filter Summary */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
          <span>
            Tìm thấy <strong>{filteredStudents.length}</strong> học sinh phù hợp
          </span>
          {(selectedGrade !== 'all' || selectedClass !== 'all' || healthFilter !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setSelectedGrade('all');
                setSelectedClass('all');
                setHealthFilter('all');
                setSearchQuery('');
              }}
              className="text-emerald-700 hover:text-emerald-800 font-medium underline"
            >
              Xóa tất cả bộ lọc
            </button>
          )}
        </div>
      </div>

      {/* Student List Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-3.5">Mã HS</th>
                <th className="py-3 px-3.5">Họ và tên</th>
                <th className="py-3 px-3">Lớp</th>
                <th className="py-3 px-3">Giới tính</th>
                <th className="py-3 px-3">Ngày sinh</th>
                <th className="py-3 px-3">Mã BHYT</th>
                <th className="py-3 px-3">Phụ huynh & SĐT</th>
                <th className="py-3 px-3">Sức khỏe & Dị ứng</th>
                <th className="py-3 px-3 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Users className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-sm text-slate-600">Không tìm thấy học sinh nào</p>
                    <p className="text-xs text-slate-400 mt-1">Thử thay đổi từ khóa tìm kiếm hoặc chọn bộ lọc khác.</p>
                  </td>
                </tr>
              ) : (
                filteredStudents.map((stu) => {
                  const hasAllergies = stu.allergies && stu.allergies !== 'Không';
                  const hasChronic = stu.chronicConditions && stu.chronicConditions !== 'Không';
                  const isSpecial = stu.specialAttention || hasAllergies || hasChronic;

                  return (
                    <tr
                      key={stu.id}
                      className="hover:bg-slate-50/80 transition-colors group"
                    >
                      <td className="py-3 px-3.5 font-bold text-slate-900 whitespace-nowrap">
                        <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-800 border border-slate-200">
                          {stu.studentCode}
                        </span>
                      </td>

                      <td className="py-3 px-3.5 font-semibold text-slate-900">
                        <div className="flex items-center gap-1.5">
                          <span>{stu.fullName}</span>
                          {stu.bloodType && (
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-red-100 text-red-700">
                              {stu.bloodType}
                            </span>
                          )}
                        </div>
                        {stu.notes && <p className="text-[10px] text-slate-400 truncate max-w-xs">{stu.notes}</p>}
                      </td>

                      <td className="py-3 px-3">
                        <span className="font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200/60">
                          {stu.className}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">{stu.gender}</td>

                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                        {formatDateVN(stu.birthDate)}
                      </td>

                      <td className="py-3 px-3 font-mono text-slate-600 whitespace-nowrap text-[11px]">
                        {stu.healthInsuranceCode || <span className="text-slate-300">—</span>}
                      </td>

                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                        <p className="font-medium text-slate-800">{stu.parentName || '—'}</p>
                        {stu.parentPhone && (
                          <p className="text-[11px] text-slate-500 flex items-center gap-1 font-mono">
                            <Phone className="w-3 h-3 text-slate-400" />
                            <span>{stu.parentPhone}</span>
                          </p>
                        )}
                      </td>

                      <td className="py-3 px-3 max-w-xs">
                        {isSpecial ? (
                          <div className="space-y-1">
                            {hasAllergies && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800 border border-rose-200">
                                <AlertTriangle className="w-3 h-3 text-rose-600 shrink-0" />
                                <span className="truncate max-w-[180px]">Dị ứng: {stu.allergies}</span>
                              </span>
                            )}
                            {hasChronic && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                                <Info className="w-3 h-3 text-amber-600 shrink-0" />
                                <span className="truncate max-w-[180px]">{stu.chronicConditions}</span>
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                            <Check className="w-3 h-3 text-slate-400" />
                            <span>Bình thường</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Quick Intake Button */}
                          <button
                            title="Tiếp nhận vào phòng y tế"
                            onClick={() => onSelectStudentForIntake?.(stu.id)}
                            className="p-1.5 text-emerald-700 hover:bg-emerald-100 rounded-lg transition-colors border border-emerald-200 bg-emerald-50"
                          >
                            <Stethoscope className="w-4 h-4" />
                          </button>

                          {/* View Health Profile */}
                          <button
                            title="Xem hồ sơ sức khỏe chi tiết"
                            onClick={() => onSelectStudentForProfile?.(stu.id)}
                            className="p-1.5 text-blue-700 hover:bg-blue-100 rounded-lg transition-colors border border-blue-200 bg-blue-50"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Edit student */}
                          <button
                            title="Chỉnh sửa thông tin"
                            onClick={() => handleOpenEdit(stu)}
                            className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete student */}
                          <button
                            title="Xóa học sinh"
                            onClick={() => setDeleteConfirmStudent(stu)}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    {editingStudent ? 'Chỉnh Sửa Thông Tin Học Sinh' : 'Thêm Học Sinh Mới'}
                  </h3>
                  <p className="text-[11px] text-slate-500">Trường THCS Đông Thạnh • Niên khóa 2026-2027</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-6 space-y-4">
              {errorMessage && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Row 1: Code, Name, Gender */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mã học sinh <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.studentCode}
                    onChange={(e) => setFormData({ ...formData, studentCode: e.target.value.toUpperCase() })}
                    placeholder="HS0001"
                    className="w-full text-xs font-mono border border-slate-200 rounded-xl px-3 py-2 uppercase focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Họ và tên học sinh <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="Nguyễn Văn An"
                    className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              {/* Row 2: Class, Grade, BirthDate, Gender */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Lớp <span className="text-rose-600">*</span>
                  </label>
                  <select
                    value={formData.className}
                    onChange={(e) => {
                      const cls = e.target.value;
                      const grade = parseInt(cls.charAt(0), 10) || 6;
                      setFormData({ ...formData, className: cls, grade });
                    }}
                    className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Giới tính</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white"
                  >
                    <option value="Nam">Nam</option>
                    <option value="Nữ">Nữ</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Ngày sinh</label>
                  <input
                    type="date"
                    required
                    value={formData.birthDate}
                    onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                    className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Nhóm máu</label>
                  <select
                    value={formData.bloodType}
                    onChange={(e) => setFormData({ ...formData, bloodType: e.target.value })}
                    className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white font-bold text-red-700"
                  >
                    <option value="O">Nhóm O</option>
                    <option value="A">Nhóm A</option>
                    <option value="B">Nhóm B</option>
                    <option value="AB">Nhóm AB</option>
                    <option value="Chưa rõ">Chưa rõ</option>
                  </select>
                </div>
              </div>

              {/* Row 3: BHYT & CCCD */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Mã thẻ BHYT</label>
                  <input
                    type="text"
                    value={formData.healthInsuranceCode}
                    onChange={(e) => setFormData({ ...formData, healthInsuranceCode: e.target.value })}
                    placeholder="GD4790123456789"
                    className="w-full text-xs font-mono border border-slate-200 rounded-xl px-3 py-2 uppercase"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Mã định danh / CCCD</label>
                  <input
                    type="text"
                    value={formData.citizenId}
                    onChange={(e) => setFormData({ ...formData, citizenId: e.target.value })}
                    placeholder="079214001234"
                    className="w-full text-xs font-mono border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              {/* Row 4: Parent info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Họ tên phụ huynh</label>
                  <input
                    type="text"
                    value={formData.parentName}
                    onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                    placeholder="Nguyễn Văn Hùng (Ba) / Lê Thị Mai (Mẹ)"
                    className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Số điện thoại liên hệ khẩn cấp
                  </label>
                  <input
                    type="text"
                    value={formData.parentPhone}
                    onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                    placeholder="0918 234 567"
                    className="w-full text-xs font-mono border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              {/* Row 5: Address */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Địa chỉ thường trú</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Ấp 1, Xã Đông Thạnh, Huyện Hóc Môn, TP.HCM"
                  className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
                />
              </div>

              {/* Section: Medical Alert / Allergies / Chronic conditions */}
              <div className="p-4 bg-rose-50/60 rounded-xl border border-rose-200 space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-600" />
                  <span className="text-xs font-bold text-rose-900 uppercase">
                    Thông tin y tế đặc biệt & Cảnh báo an toàn
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-rose-900 mb-1">
                      Tiền sử dị ứng (Thuốc, thức ăn, phấn hoa...)
                    </label>
                    <input
                      type="text"
                      value={formData.allergies}
                      onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
                      placeholder="VD: Dị ứng Penicillin, dị ứng tôm cua..."
                      className="w-full text-xs border border-rose-300 rounded-xl px-3 py-2 bg-white focus:ring-2 focus:ring-rose-500 font-medium text-rose-900 placeholder:text-rose-300"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-rose-900 mb-1">
                      Bệnh nền mạn tính (Hen suyễn, tim mạch, dạ dày...)
                    </label>
                    <input
                      type="text"
                      value={formData.chronicConditions}
                      onChange={(e) => setFormData({ ...formData, chronicConditions: e.target.value })}
                      placeholder="VD: Hen phế quản, cận thị nặng..."
                      className="w-full text-xs border border-rose-300 rounded-xl px-3 py-2 bg-white focus:ring-2 focus:ring-rose-500 font-medium text-rose-900 placeholder:text-rose-300"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="chk-special-attention"
                    checked={formData.specialAttention}
                    onChange={(e) => setFormData({ ...formData, specialAttention: e.target.checked })}
                    className="w-4 h-4 text-rose-600 rounded border-rose-300 focus:ring-rose-500"
                  />
                  <label htmlFor="chk-special-attention" className="text-xs font-semibold text-rose-900 cursor-pointer">
                    Đánh dấu học sinh cần theo dõi sức khỏe đặc biệt tại phòng y tế
                  </label>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Ghi chú thêm</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Ghi chú sở thích, thói quen hoặc lưu ý từ giáo viên chủ nhiệm..."
                  className="w-full text-xs border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl shadow-xs transition-colors"
                >
                  {editingStudent ? 'Lưu cập nhật' : 'Xác nhận thêm học sinh'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Import Excel Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Import Danh Sách Học Sinh Từ Excel / CSV</h3>
                  <p className="text-[11px] text-slate-500">Tải lên danh sách học sinh theo khối hoặc theo lớp</p>
                </div>
              </div>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Sample file download banner */}
              <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Info className="w-5 h-5 text-blue-600 shrink-0" />
                  <div className="text-xs text-blue-900">
                    <p className="font-bold">Mẫu định dạng chuẩn Excel/CSV</p>
                    <p className="text-blue-700 text-[11px]">
                      Tệp gồm các cột: Mã học sinh, Họ và tên, Lớp, Giới tính, Ngày sinh, Phụ huynh, SĐT, BHYT, Dị ứng,
                      Bệnh nền.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadSampleExcel}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white text-blue-700 border border-blue-300 hover:bg-blue-50 rounded-lg text-xs font-semibold shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tải tệp mẫu</span>
                </button>
              </div>

              {/* Upload Dropzone */}
              <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-blue-500 transition-colors bg-slate-50/50">
                <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-xs font-semibold text-slate-800">
                  Kéo thả tệp CSV / Excel vào đây hoặc bấm để chọn tệp
                </p>
                <p className="text-[11px] text-slate-400 mt-1">Hỗ trợ định dạng .csv (mã hóa UTF-8)</p>
                <input
                  type="file"
                  accept=".csv,.txt"
                  onChange={handleFileUpload}
                  className="mt-3 text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer"
                />
              </div>

              {importFileName && (
                <p className="text-xs text-slate-600">
                  Tệp đã chọn: <strong>{importFileName}</strong> ({importRows.length} dòng dữ liệu)
                </p>
              )}

              {/* Errors Display */}
              {importErrors.length > 0 && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-1">
                  <p className="text-xs font-bold text-rose-800 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span>Lỗi phát hiện trong quá trình xử lý:</span>
                  </p>
                  <ul className="list-disc pl-5 text-[11px] text-rose-700 max-h-28 overflow-y-auto">
                    {importErrors.map((err, i) => (
                      <li key={i}>{err}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Success summary */}
              {importSuccessCount !== null && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Đã nhập thành công {importSuccessCount} học sinh vào cơ sở dữ liệu!</span>
                </div>
              )}

              {/* Preview Table */}
              {importRows.length > 0 && (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="bg-slate-100 px-3 py-2 text-xs font-bold text-slate-700 flex justify-between">
                    <span>Xem trước dữ liệu ({importRows.length} học sinh)</span>
                    <span className="text-slate-500 text-[11px]">Chỉ hiển thị tối đa 5 dòng đầu</span>
                  </div>
                  <div className="overflow-x-auto max-h-48">
                    <table className="w-full text-left text-[11px]">
                      <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                        <tr>
                          <th className="py-2 px-2.5">Mã HS</th>
                          <th className="py-2 px-2.5">Họ và tên</th>
                          <th className="py-2 px-2">Lớp</th>
                          <th className="py-2 px-2">Giới tính</th>
                          <th className="py-2 px-2">Ngày sinh</th>
                          <th className="py-2 px-2">SĐT PH</th>
                          <th className="py-2 px-2">Dị ứng / Bệnh nền</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {importRows.slice(0, 5).map((r, i) => (
                          <tr key={i} className="hover:bg-slate-50">
                            <td className="py-1.5 px-2.5 font-mono font-bold text-slate-800">
                              {r['Mã học sinh'] || r['studentCode'] || r['MaHS']}
                            </td>
                            <td className="py-1.5 px-2.5 font-medium text-slate-800">
                              {r['Họ và tên'] || r['fullName'] || r['HoTen']}
                            </td>
                            <td className="py-1.5 px-2 font-bold text-emerald-700">
                              {r['Lớp'] || r['className'] || r['Lop']}
                            </td>
                            <td className="py-1.5 px-2 text-slate-600">
                              {r['Giới tính'] || r['gender'] || 'Nam'}
                            </td>
                            <td className="py-1.5 px-2 text-slate-600">
                              {r['Ngày sinh'] || r['birthDate'] || '—'}
                            </td>
                            <td className="py-1.5 px-2 font-mono text-slate-600">
                              {r['SĐT phụ huynh'] || r['parentPhone'] || '—'}
                            </td>
                            <td className="py-1.5 px-2 text-rose-700 font-medium">
                              {r['Dị ứng'] || r['allergies'] || r['Bệnh nền'] || 'Không'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Đóng
                </button>
                <button
                  type="button"
                  disabled={importRows.length === 0}
                  onClick={handleConfirmImport}
                  className="px-5 py-2 text-xs font-semibold bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white rounded-xl shadow-xs transition-colors"
                >
                  Xác nhận Import ({importRows.length} học sinh)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmStudent && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-600 mb-3">
              <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base text-slate-900">Xác Nhận Xóa Học Sinh</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Bạn có chắc chắn muốn xóa học sinh <strong>{deleteConfirmStudent.fullName}</strong> (Mã:{' '}
              {deleteConfirmStudent.studentCode}) khỏi hệ thống?
            </p>
            <p className="text-[11px] text-rose-600 font-medium mt-2 bg-rose-50 p-2.5 rounded-lg border border-rose-200">
              Lưu ý: Nếu học sinh đã có lịch sử khám bệnh tại phòng y tế, hệ thống sẽ ngăn chặn việc xóa để bảo vệ tính
              toàn vẹn y bạ học đường.
            </p>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                onClick={() => setDeleteConfirmStudent(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Hủy bỏ
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="px-4 py-2 text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs"
              >
                Xác nhận xóa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
