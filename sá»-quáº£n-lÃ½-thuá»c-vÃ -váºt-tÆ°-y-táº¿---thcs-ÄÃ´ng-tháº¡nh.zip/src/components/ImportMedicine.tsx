import React, { useState } from 'react';
import {
  ArrowDownLeft,
  Plus,
  Trash2,
  FileText,
  Printer,
  Boxes,
  CheckCircle2,
  AlertCircle,
  Building2,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { db, formatVND, formatDateVN } from '../services/db';
import { Medicine, InventoryTransaction } from '../types';

interface ImportMedicineProps {
  initialMedicine?: Medicine | null;
  onSuccess: (message: string) => void;
  onPrintTransaction: (tx: InventoryTransaction) => void;
}

interface ImportRow {
  medicineId: string;
  batchNumber: string;
  mfgDate: string;
  expDate: string;
  quantity: number;
  unitPrice: number;
  storageLocation: string;
}

export const ImportMedicine: React.FC<ImportMedicineProps> = ({
  initialMedicine,
  onSuccess,
  onPrintTransaction,
}) => {
  const medicines = db.getMedicines();
  const suppliers = db.getSuppliers();
  const importTransactions = db.getTransactions('import');

  // Form State
  const [transactionCode, setTransactionCode] = useState(
    `PN-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`
  );
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [source, setSource] = useState('Ngân sách y tế trường học năm học 2026-2027');
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || '');
  const [deliverer, setDeliverer] = useState('');
  const [receiver, setReceiver] = useState(db.getCurrentUser().fullName);
  const [notes, setNotes] = useState('');

  // Rows of medicines to import
  const [items, setItems] = useState<ImportRow[]>(() => {
    const defaultMed = initialMedicine || medicines[0];
    const nextYear = new Date();
    nextYear.setFullYear(nextYear.getFullYear() + 2);

    return [
      {
        medicineId: defaultMed ? defaultMed.id : '',
        batchNumber: `L${new Date().getFullYear().toString().slice(-2)}${String(
          new Date().getMonth() + 1
        ).padStart(2, '0')}-01`,
        mfgDate: new Date().toISOString().split('T')[0],
        expDate: nextYear.toISOString().split('T')[0],
        quantity: 50,
        unitPrice: defaultMed ? defaultMed.unitPrice : 1000,
        storageLocation: defaultMed ? defaultMed.storageLocation : 'Tủ A',
      },
    ];
  });

  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'create' | 'history'>('create');
  const [selectedTx, setSelectedTx] = useState<InventoryTransaction | null>(null);

  // Grand total calculation
  const grandTotal = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);

  // Handle adding new item row
  const handleAddRow = () => {
    const med = medicines[0];
    const nextYear = new Date();
    nextYear.setFullYear(nextYear.getFullYear() + 2);

    setItems([
      ...items,
      {
        medicineId: med ? med.id : '',
        batchNumber: `L${new Date().getFullYear().toString().slice(-2)}${String(
          new Date().getMonth() + 1
        ).padStart(2, '0')}-0${items.length + 1}`,
        mfgDate: new Date().toISOString().split('T')[0],
        expDate: nextYear.toISOString().split('T')[0],
        quantity: 50,
        unitPrice: med ? med.unitPrice : 1000,
        storageLocation: med ? med.storageLocation : 'Tủ A',
      },
    ]);
  };

  const handleRemoveRow = (index: number) => {
    if (items.length <= 1) {
      alert('Phiếu nhập phải có ít nhất 1 loại thuốc.');
      return;
    }
    setItems(items.filter((_, i) => i !== index));
  };

  const handleMedicineChange = (index: number, medId: string) => {
    const med = medicines.find((m) => m.id === medId);
    if (!med) return;

    const newItems = [...items];
    newItems[index].medicineId = medId;
    newItems[index].unitPrice = med.unitPrice;
    newItems[index].storageLocation = med.storageLocation;
    setItems(newItems);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!transactionCode.trim()) {
      setError('Số phiếu nhập không được để trống.');
      return;
    }
    if (!supplierId) {
      setError('Vui lòng chọn nhà cung cấp hoặc đơn vị cấp thuốc.');
      return;
    }

    for (const item of items) {
      if (!item.medicineId) {
        setError('Vui lòng chọn thuốc cho tất cả các dòng.');
        return;
      }
      if (!item.batchNumber.trim()) {
        setError('Số lô không được để trống.');
        return;
      }
      if (item.quantity <= 0) {
        setError('Số lượng nhập phải lớn hơn 0.');
        return;
      }
      if (item.unitPrice < 0) {
        setError('Đơn giá không được âm.');
        return;
      }
      if (new Date(item.expDate) <= new Date(item.mfgDate)) {
        setError(`Lô "${item.batchNumber}": Hạn sử dụng phải sau ngày sản xuất.`);
        return;
      }
    }

    try {
      const newTx = db.importMedicineTransaction({
        transactionCode: transactionCode.trim().toUpperCase(),
        date,
        source,
        supplierId,
        deliverer,
        receiver,
        performer: db.getCurrentUser().fullName,
        notes,
        items,
      });

      onSuccess(
        `ĐÃ LƯU THÀNH CÔNG! Phiếu nhập ${newTx.transactionCode} đã tự động cộng số lượng vào kho.`
      );

      // Reset form
      setTransactionCode(
        `PN-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`
      );
      setDeliverer('');
      setNotes('');
      setActiveTab('history');
      setSelectedTx(newTx);
    } catch (err: any) {
      setError(err.message || 'Lỗi khi lưu phiếu nhập thuốc.');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-700">
            <ArrowDownLeft className="w-4 h-4" />
            <span>Nghiệp vụ Kho Dược • Trường THCS Đông Thạnh</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
            NHẬP THUỐC VÀO TỦ Y TẾ
          </h2>
          <p className="text-xs text-slate-500">
            Lập phiếu nhập thuốc theo lô, hạn dùng. Hệ thống tự động cập nhật tồn kho an toàn
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('create')}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === 'create'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            + Lập Phiếu Mới
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === 'history'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Lịch Sử Phiếu Nhập ({importTransactions.length})
          </button>
        </div>
      </div>

      {activeTab === 'create' ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          {/* Section 1: General Info */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 border-b border-slate-100 pb-2 flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              <span>I. Thông Tin Chung Phiếu Nhập</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Số phiếu nhập <span className="text-rose-600">*</span>
                </label>
                <input
                  id="input-import-code"
                  type="text"
                  value={transactionCode}
                  onChange={(e) => setTransactionCode(e.target.value.toUpperCase())}
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 font-mono font-bold text-slate-900 bg-slate-50 focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Ngày nhập kho <span className="text-rose-600">*</span>
                </label>
                <input
                  id="input-import-date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 font-bold focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Nhà cung cấp / Đơn vị cấp <span className="text-rose-600">*</span>
                </label>
                <select
                  id="select-import-supplier"
                  value={supplierId}
                  onChange={(e) => setSupplierId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-white font-medium focus:ring-2 focus:ring-blue-500"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nguồn kinh phí / Thuốc</label>
                <input
                  id="input-import-source"
                  type="text"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  placeholder="VD: Ngân sách y tế trường học..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Người giao hàng / Đại diện</label>
                <input
                  id="input-import-deliverer"
                  type="text"
                  value={deliverer}
                  onChange={(e) => setDeliverer(e.target.value)}
                  placeholder="Họ tên người giao từ NCC"
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Người nhận (Cán bộ y tế nhận) <span className="text-rose-600">*</span>
                </label>
                <input
                  id="input-import-receiver"
                  type="text"
                  value={receiver}
                  onChange={(e) => setReceiver(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 font-bold focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="text-xs">
              <label className="block font-bold text-slate-700 mb-1">Ghi chú phiếu nhập</label>
              <input
                id="input-import-notes"
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="VD: Thuốc đợt 1 kiểm kê đầu năm học, bao bì nguyên vẹn..."
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Section 2: Details of Medicines to Import */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                <Boxes className="w-4 h-4 text-blue-600" />
                <span>II. Danh Sách Thuốc Nhập Kho (Quản lý theo Lô & HSD)</span>
              </h3>
              <button
                type="button"
                onClick={handleAddRow}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold hover:bg-blue-100"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Thêm dòng thuốc</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="p-2.5">STT</th>
                    <th className="p-2.5 min-w-[220px]">Tên thuốc & Mã</th>
                    <th className="p-2.5 min-w-[120px]">Số lô *</th>
                    <th className="p-2.5 min-w-[130px]">Ngày SX</th>
                    <th className="p-2.5 min-w-[130px]">Hạn sử dụng *</th>
                    <th className="p-2.5 min-w-[90px] text-right">Số lượng *</th>
                    <th className="p-2.5 min-w-[110px] text-right">Đơn giá (VNĐ)</th>
                    <th className="p-2.5 min-w-[120px] text-right">Thành tiền</th>
                    <th className="p-2.5 text-center">Xóa</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((row, idx) => {
                    const selectedMed = medicines.find((m) => m.id === row.medicineId);
                    const rowTotal = row.quantity * row.unitPrice;

                    return (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2.5 text-slate-400 font-mono">{idx + 1}</td>

                        {/* Medicine Selector */}
                        <td className="p-2.5">
                          <select
                            value={row.medicineId}
                            onChange={(e) => handleMedicineChange(idx, e.target.value)}
                            className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-bold text-slate-900"
                          >
                            {medicines.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name} ({m.code}) - {m.unit}
                              </option>
                            ))}
                          </select>
                          <span className="block text-[10px] text-slate-500 mt-0.5">
                            Đơn vị: <strong>{selectedMed?.unit}</strong> • Vị trí:{' '}
                            {selectedMed?.storageLocation}
                          </span>
                        </td>

                        {/* Batch Number */}
                        <td className="p-2.5">
                          <input
                            type="text"
                            value={row.batchNumber}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[idx].batchNumber = e.target.value.toUpperCase();
                              setItems(newItems);
                            }}
                            placeholder="Số lô"
                            required
                            className="w-full p-1.5 rounded-lg border border-slate-200 font-mono font-bold text-slate-900"
                          />
                        </td>

                        {/* Mfg Date */}
                        <td className="p-2.5">
                          <input
                            type="date"
                            value={row.mfgDate}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[idx].mfgDate = e.target.value;
                              setItems(newItems);
                            }}
                            className="w-full p-1.5 rounded-lg border border-slate-200"
                          />
                        </td>

                        {/* Exp Date */}
                        <td className="p-2.5">
                          <input
                            type="date"
                            value={row.expDate}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[idx].expDate = e.target.value;
                              setItems(newItems);
                            }}
                            required
                            className="w-full p-1.5 rounded-lg border border-slate-200 font-bold text-slate-900"
                          />
                        </td>

                        {/* Quantity */}
                        <td className="p-2.5 text-right">
                          <input
                            type="number"
                            min="1"
                            value={row.quantity}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[idx].quantity = Number(e.target.value);
                              setItems(newItems);
                            }}
                            required
                            className="w-20 p-1.5 rounded-lg border border-slate-200 text-right font-black text-blue-900"
                          />
                        </td>

                        {/* Unit Price */}
                        <td className="p-2.5 text-right">
                          <input
                            type="number"
                            min="0"
                            step="100"
                            value={row.unitPrice}
                            onChange={(e) => {
                              const newItems = [...items];
                              newItems[idx].unitPrice = Number(e.target.value);
                              setItems(newItems);
                            }}
                            className="w-24 p-1.5 rounded-lg border border-slate-200 text-right font-semibold"
                          />
                        </td>

                        {/* Line Total */}
                        <td className="p-2.5 text-right font-black text-slate-900 whitespace-nowrap">
                          {formatVND(rowTotal)}
                        </td>

                        {/* Remove */}
                        <td className="p-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveRow(idx)}
                            className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                            title="Xóa dòng"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Total Footer */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-slate-600">
                <span>Tổng số loại thuốc nhập: </span>
                <strong className="text-slate-900">{items.length} mặt hàng</strong>
                <span className="mx-2">•</span>
                <span>Tổng số lượng: </span>
                <strong className="text-blue-700">
                  {items.reduce((s, i) => s + i.quantity, 0)} đơn vị
                </strong>
              </div>

              <div className="flex items-baseline gap-2">
                <span className="text-xs font-bold text-slate-600">TỔNG CỘNG THÀNH TIỀN:</span>
                <span className="text-xl font-black text-blue-900">{formatVND(grandTotal)}</span>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              id="btn-save-import-transaction"
              type="submit"
              className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-all flex items-center gap-2"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>LƯU PHIẾU NHẬP VÀO KHO</span>
            </button>
          </div>
        </form>
      ) : (
        /* History of Import Transactions */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                LỊCH SỬ CÁC PHIẾU NHẬP THUỐC VÀO TỦ Y TẾ
              </h3>
              <p className="text-xs text-slate-500">
                Toàn bộ dữ liệu nhập thuốc đã tự động ghi nhận vào tồn kho và nhật ký hệ thống
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('create')}
              className="px-3 py-1.5 rounded-lg bg-blue-600 text-white font-bold text-xs hover:bg-blue-700"
            >
              + Lập phiếu mới
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="p-3">Số phiếu</th>
                  <th className="p-3">Ngày nhập</th>
                  <th className="p-3">Nguồn thuốc / NCC</th>
                  <th className="p-3">Người giao - nhận</th>
                  <th className="p-3 text-center">Số mặt hàng</th>
                  <th className="p-3 text-right">Tổng tiền</th>
                  <th className="p-3 text-center">Tình trạng</th>
                  <th className="p-3 text-center">In / Xem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {importTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-slate-400">
                      Chưa có phiếu nhập nào.
                    </td>
                  </tr>
                ) : (
                  importTransactions.map((tx) => {
                    const sup = suppliers.find((s) => s.id === tx.supplierId);
                    return (
                      <tr key={tx.id} className="hover:bg-slate-50">
                        <td className="p-3 font-mono font-bold text-blue-900">
                          {tx.transactionCode}
                        </td>
                        <td className="p-3 text-slate-700 font-medium">
                          {formatDateVN(tx.date)}
                        </td>
                        <td className="p-3">
                          <span className="font-bold text-slate-900">
                            {sup?.name || tx.source || '---'}
                          </span>
                          <span className="block text-[10px] text-slate-500">{tx.source}</span>
                        </td>
                        <td className="p-3 text-slate-700">
                          <span>Giao: {tx.deliverer || 'Đại diện NCC'}</span>
                          <span className="block text-[10px] text-slate-500">
                            Nhận: {tx.receiver || tx.performer}
                          </span>
                        </td>
                        <td className="p-3 text-center font-bold text-slate-800">
                          {tx.items.length} thuốc
                        </td>
                        <td className="p-3 text-right font-black text-slate-900">
                          {formatVND(tx.totalAmount)}
                        </td>
                        <td className="p-3 text-center">
                          {tx.status === 'completed' ? (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                              Đã nhập kho
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-bold">
                              Đã hủy
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setSelectedTx(tx)}
                              className="px-2 py-1 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 font-medium"
                            >
                              Xem
                            </button>
                            <button
                              type="button"
                              onClick={() => onPrintTransaction(tx)}
                              className="p-1 rounded text-slate-500 hover:text-blue-700 hover:bg-blue-50"
                              title="In phiếu nhập A4"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View Detail Modal for Transaction */}
      {selectedTx && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col shadow-xl">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono font-bold text-blue-700">
                  CHI TIẾT PHIẾU NHẬP
                </span>
                <h3 className="text-base font-black text-slate-900">{selectedTx.transactionCode}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTx(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px]">Ngày nhập:</span>
                  <strong className="text-slate-800">{formatDateVN(selectedTx.date)}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Người nhận:</span>
                  <strong className="text-slate-800">{selectedTx.receiver || selectedTx.performer}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Người giao:</span>
                  <strong className="text-slate-800">{selectedTx.deliverer || 'Đại diện NCC'}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Nguồn thuốc:</span>
                  <strong className="text-slate-800">{selectedTx.source}</strong>
                </div>
              </div>

              <table className="w-full text-left border border-slate-200 rounded-xl overflow-hidden">
                <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="p-2">Tên thuốc</th>
                    <th className="p-2">Số lô</th>
                    <th className="p-2">Hạn sử dụng</th>
                    <th className="p-2 text-right">Số lượng</th>
                    <th className="p-2 text-right">Đơn giá</th>
                    <th className="p-2 text-right">Thành tiền</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {selectedTx.items.map((item, i) => (
                    <tr key={i}>
                      <td className="p-2 font-bold text-slate-900">{item.medicineName}</td>
                      <td className="p-2 font-mono">{item.batchNumber}</td>
                      <td className="p-2">{formatDateVN(item.expDate)}</td>
                      <td className="p-2 text-right font-black">
                        {item.quantity} {item.unit}
                      </td>
                      <td className="p-2 text-right">{formatVND(item.unitPrice)}</td>
                      <td className="p-2 text-right font-bold text-blue-900">
                        {formatVND(item.totalAmount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  onPrintTransaction(selectedTx);
                  setSelectedTx(null);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200"
              >
                <Printer className="w-4 h-4" />
                <span>In biểu mẫu phiếu A4</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedTx(null)}
                className="px-4 py-2 bg-slate-800 text-white font-semibold rounded-xl"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
