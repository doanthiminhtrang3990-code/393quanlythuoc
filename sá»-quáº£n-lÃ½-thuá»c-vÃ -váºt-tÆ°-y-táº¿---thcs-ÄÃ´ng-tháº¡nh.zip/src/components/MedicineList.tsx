import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  Edit2,
  Trash2,
  Eye,
  AlertTriangle,
  Pill,
  ClockAlert,
  Flame,
  CheckCircle2,
  Building,
  MapPin,
  FileText,
  Boxes,
  Download,
} from 'lucide-react';
import { db, formatVND, formatDateVN, getStatusText, getDaysRemaining } from '../services/db';
import { Medicine, MedicineStatus, MedicineBatch, Supplier } from '../types';

import { ImportExcelModal, downloadStandardMedicineTemplate } from './ImportExcelModal';

interface MedicineListProps {
  initialFilter?: string;
  onOpenAddModal: () => void;
  onOpenEditModal: (medicine: Medicine) => void;
  onOpenImportForMed: (medicine: Medicine) => void;
}

export const MedicineList: React.FC<MedicineListProps> = ({
  initialFilter = 'all',
  onOpenAddModal,
  onOpenEditModal,
  onOpenImportForMed,
}) => {
  const medicines = db.getMedicines();
  const batches = db.getBatches();
  const suppliers = db.getSuppliers();

  // Search & Filter & Sort state
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(initialFilter);
  const [sortBy, setSortBy] = useState<'name' | 'expDate' | 'stockAsc' | 'stockDesc'>('name');

  // View details modal state
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [showImportExcelModal, setShowImportExcelModal] = useState(false);

  // Filtered & Sorted medicines
  const processedMedicines = useMemo(() => {
    return medicines
      .filter((med) => {
        // Status filter
        if (statusFilter !== 'all') {
          if (statusFilter === 'active' && med.computedStatus !== 'active') return false;
          if (statusFilter === 'low_stock' && med.computedStatus !== 'low_stock') return false;
          if (statusFilter === 'out_of_stock' && med.computedStatus !== 'out_of_stock') return false;
          if (statusFilter === 'expiring_soon' && med.computedStatus !== 'expiring_soon') return false;
          if (statusFilter === 'expired' && med.computedStatus !== 'expired') return false;
        }

        // Search term
        if (!searchTerm.trim()) return true;
        const q = searchTerm.toLowerCase();
        const medBatches = batches.filter((b) => b.medicineId === med.id);
        const matchBatch = medBatches.some((b) => b.batchNumber.toLowerCase().includes(q));

        return (
          med.name.toLowerCase().includes(q) ||
          med.code.toLowerCase().includes(q) ||
          med.activeIngredient.toLowerCase().includes(q) ||
          med.dosageForm.toLowerCase().includes(q) ||
          med.storageLocation.toLowerCase().includes(q) ||
          matchBatch
        );
      })
      .sort((a, b) => {
        if (sortBy === 'name') {
          return a.name.localeCompare(b.name, 'vi');
        }
        if (sortBy === 'stockAsc') {
          return (a.totalStock ?? 0) - (b.totalStock ?? 0);
        }
        if (sortBy === 'stockDesc') {
          return (b.totalStock ?? 0) - (a.totalStock ?? 0);
        }
        if (sortBy === 'expDate') {
          const dateA = a.earliestExpDate ? new Date(a.earliestExpDate).getTime() : 9999999999999;
          const dateB = b.earliestExpDate ? new Date(b.earliestExpDate).getTime() : 9999999999999;
          return dateA - dateB;
        }
        return 0;
      });
  }, [medicines, batches, searchTerm, statusFilter, sortBy]);

  const handleDelete = (med: Medicine) => {
    if (confirm(`Bạn có chắc chắn muốn xóa thuốc "${med.name}" (${med.code}) khỏi danh mục không?`)) {
      try {
        db.deleteMedicine(med.id);
        alert('Đã xóa thuốc thành công khỏi hệ thống.');
      } catch (err: any) {
        alert(err.message || 'Không thể xóa thuốc.');
      }
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700">
            <Pill className="w-4 h-4" />
            <span>Phòng Y Tế • THCS Đông Thạnh</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
            DANH MỤC THUỐC THIẾT YẾU
          </h2>
          <p className="text-xs text-slate-500">
            Quản lý thông tin chi tiết từng loại thuốc, vị trí tủ, định mức tồn và tình trạng các lô
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={downloadStandardMedicineTemplate}
            className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs sm:text-sm font-bold hover:bg-slate-200 border border-slate-300 shadow-2xs transition-colors"
            title="Tải về file Excel mẫu chuẩn 12 cột để nhập dữ liệu"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span className="hidden md:inline">TẢI FILE CHUẨN</span>
          </button>
          <button
            type="button"
            onClick={() => setShowImportExcelModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 text-white text-xs sm:text-sm font-bold hover:bg-blue-700 shadow-xs transition-colors"
          >
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">NHẬP TỪ EXCEL</span>
          </button>
          <button
            id="btn-open-add-medicine"
            type="button"
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs sm:text-sm font-bold hover:bg-emerald-700 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>+ THÊM THUỐC MỚI</span>
          </button>
        </div>
      </div>

      {/* Search, Filter & Sort Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search box */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              id="input-search-medicine"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo tên thuốc, mã thuốc, hoạt chất, số lô, vị trí..."
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter Status */}
          <div className="md:col-span-4 flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              id="select-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="all">Tất cả tình trạng ({medicines.length})</option>
              <option value="active">Đang sử dụng</option>
              <option value="low_stock">Sắp hết (≤ mức tối thiểu)</option>
              <option value="expiring_soon">Sắp hết hạn (≤ 30 ngày)</option>
              <option value="expired">Đã hết hạn</option>
              <option value="out_of_stock">Hết hàng (tồn 0)</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="md:col-span-3 flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              id="select-sort-medicine"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full py-2 px-3 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="name">Sắp xếp: Tên thuốc (A-Z)</option>
              <option value="expDate">Sắp xếp: Hạn dùng gần nhất</option>
              <option value="stockAsc">Sắp xếp: Số lượng tồn tăng dần</option>
              <option value="stockDesc">Sắp xếp: Số lượng tồn giảm dần</option>
            </select>
          </div>
        </div>

        {/* Status quick tabs */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-500 mr-1 text-[11px] font-semibold">Lọc nhanh:</span>
          {[
            { id: 'all', label: 'Tất cả' },
            { id: 'active', label: 'Đang dùng' },
            { id: 'low_stock', label: '🟡 Sắp hết' },
            { id: 'expiring_soon', label: '🟠 Sắp hết hạn' },
            { id: 'expired', label: '🔴 Đã hết hạn' },
            { id: 'out_of_stock', label: 'Hết hàng' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setStatusFilter(tab.id)}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                statusFilter === tab.id
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
          <span className="ml-auto text-slate-400 text-[11px]">
            Hiển thị <strong>{processedMedicines.length}</strong> / {medicines.length} thuốc
          </span>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-50 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-3">Mã & Tên thuốc</th>
                <th className="py-3 px-3">Hoạt chất / Nồng độ</th>
                <th className="py-3 px-3">Dạng & Quy cách</th>
                <th className="py-3 px-3 text-center">Số lô & HSD gần</th>
                <th className="py-3 px-3 text-right">Tồn kho / Tối thiểu</th>
                <th className="py-3 px-3 text-right">Đơn giá</th>
                <th className="py-3 px-3">Vị trí tủ</th>
                <th className="py-3 px-3 text-center">Tình trạng</th>
                <th className="py-3 px-3 text-center">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {processedMedicines.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Pill className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold">Không tìm thấy thuốc nào phù hợp điều kiện lọc.</p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Thử xóa từ khóa tìm kiếm hoặc chọn lọc &ldquo;Tất cả&rdquo;.
                    </p>
                  </td>
                </tr>
              ) : (
                processedMedicines.map((med) => {
                  const statusStyle = getStatusText(med.computedStatus);
                  const medBatches = batches.filter((b) => b.medicineId === med.id);
                  const daysLeft = med.earliestExpDate ? getDaysRemaining(med.earliestExpDate) : null;

                  return (
                    <tr
                      key={med.id}
                      className="hover:bg-slate-50/80 transition-colors group"
                    >
                      {/* Name & Code */}
                      <td className="py-3 px-3">
                        <div className="flex items-start gap-2">
                          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 font-bold text-xs mt-0.5">
                            {med.name.charAt(0)}
                          </div>
                          <div>
                            <button
                              type="button"
                              onClick={() => setSelectedMedicine(med)}
                              className="font-bold text-slate-900 hover:text-emerald-700 text-left text-xs sm:text-sm"
                            >
                              {med.name}
                            </button>
                            <span className="block font-mono text-[10px] text-slate-500">
                              {med.code} • NSX: {med.manufacturer || 'Việt Nam'}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Active Ingredient & Strength */}
                      <td className="py-3 px-3">
                        <span className="font-medium text-slate-800">{med.activeIngredient}</span>
                        <span className="block text-[10px] text-slate-500 font-semibold">
                          Hàm lượng: {med.strength}
                        </span>
                      </td>

                      {/* Dosage Form & Packing */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="text-slate-800 font-medium">{med.dosageForm}</span>
                        <span className="block text-[10px] text-slate-500">
                          ĐVT: <strong className="text-slate-700">{med.unit}</strong> ({med.packing})
                        </span>
                      </td>

                      {/* Batches count & Earliest Expiry */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <span className="inline-block px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[10px] font-bold">
                          {medBatches.length} Lô
                        </span>
                        {med.earliestExpDate ? (
                          <div className="mt-1 text-[11px]">
                            <span className="font-medium text-slate-800">
                              {formatDateVN(med.earliestExpDate)}
                            </span>
                            {daysLeft !== null && (
                              <span
                                className={`block text-[10px] font-bold ${
                                  daysLeft < 0
                                    ? 'text-rose-600'
                                    : daysLeft <= 30
                                    ? 'text-orange-600'
                                    : 'text-emerald-600'
                                }`}
                              >
                                {daysLeft < 0
                                  ? `Quá hạn ${Math.abs(daysLeft)} ngày`
                                  : `Còn ${daysLeft} ngày`}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="block text-[10px] text-slate-400 mt-0.5">Chưa có HSD</span>
                        )}
                      </td>

                      {/* Stock vs MinStock */}
                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-baseline justify-end gap-1">
                          <span
                            className={`text-sm font-black ${
                              med.totalStock === 0
                                ? 'text-slate-400'
                                : med.totalStock <= med.minStock
                                ? 'text-amber-700'
                                : 'text-emerald-800'
                            }`}
                          >
                            {med.totalStock}
                          </span>
                          <span className="text-slate-500 text-[11px]">{med.unit}</span>
                        </div>
                        <span className="block text-[10px] text-slate-400">
                          Tối thiểu: {med.minStock} {med.unit}
                        </span>
                      </td>

                      {/* Unit Price */}
                      <td className="py-3 px-3 text-right font-semibold text-slate-800 whitespace-nowrap">
                        {formatVND(med.unitPrice)}
                        <span className="block text-[10px] text-slate-400 font-normal">
                          / {med.unit}
                        </span>
                      </td>

                      {/* Storage location */}
                      <td className="py-3 px-3 text-slate-700">
                        <span className="inline-flex items-center gap-1 text-[11px]">
                          <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate max-w-[140px]">{med.storageLocation}</span>
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-black border ${statusStyle.bg} ${statusStyle.color} ${statusStyle.border}`}
                        >
                          {statusStyle.label}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => setSelectedMedicine(med)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                            title="Xem chi tiết và danh sách lô"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onOpenEditModal(med)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-blue-700 hover:bg-blue-50 transition-colors"
                            title="Sửa thông tin thuốc"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(med)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-700 hover:bg-rose-50 transition-colors"
                            title="Xóa thuốc khỏi danh mục"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* View Detail Modal with FEFO Batches breakdown */}
      {selectedMedicine && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-start justify-between">
              <div>
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 mb-1">
                  MÃ THUỐC: {selectedMedicine.code}
                </span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900">
                  {selectedMedicine.name}
                </h3>
                <p className="text-xs text-slate-500">
                  Hoạt chất: {selectedMedicine.activeIngredient} • Hàm lượng: {selectedMedicine.strength}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedMedicine(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold px-2 py-1"
              >
                ✕ Đóng
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto flex-1 space-y-5 text-xs">
              {/* Detailed Specs Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px]">Dạng bào chế:</span>
                  <strong className="text-slate-800">{selectedMedicine.dosageForm}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Đơn vị tính:</span>
                  <strong className="text-slate-800">{selectedMedicine.unit}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Quy cách đóng gói:</span>
                  <strong className="text-slate-800">{selectedMedicine.packing}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Nhà sản xuất:</span>
                  <strong className="text-slate-800">{selectedMedicine.manufacturer || '---'}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Nước sản xuất:</span>
                  <strong className="text-slate-800">{selectedMedicine.country || 'Việt Nam'}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Vị trí tủ thuốc:</span>
                  <strong className="text-emerald-800">{selectedMedicine.storageLocation}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Mức tồn tối thiểu:</span>
                  <strong className="text-slate-800">
                    {selectedMedicine.minStock} {selectedMedicine.unit}
                  </strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Đơn giá tham khảo:</span>
                  <strong className="text-slate-800">{formatVND(selectedMedicine.unitPrice)}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Tổng tồn kho hiện tại:</span>
                  <strong className="text-emerald-700 text-sm">
                    {selectedMedicine.totalStock} {selectedMedicine.unit}
                  </strong>
                </div>
              </div>

              {selectedMedicine.notes && (
                <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200 text-blue-900">
                  <p className="font-bold text-[11px] mb-0.5">Ghi chú & Chỉ định sơ cứu trường học:</p>
                  <p>{selectedMedicine.notes}</p>
                </div>
              )}

              {/* Batches Table (Section XIV - Quản lý lô riêng biệt) */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm flex items-center gap-1.5">
                    <Boxes className="w-4 h-4 text-emerald-600" />
                    <span>Danh Sách Các Lô Thuốc Hiện Có (Ưu tiên xuất FEFO)</span>
                  </h4>
                  <span className="text-[11px] text-slate-500">
                    Sắp xếp: Hạn sử dụng gần nhất xếp trước
                  </span>
                </div>

                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="p-2.5">Số lô</th>
                        <th className="p-2.5">Ngày SX</th>
                        <th className="p-2.5">Hạn sử dụng</th>
                        <th className="p-2.5 text-right">Tồn hiện tại</th>
                        <th className="p-2.5 text-right">Đơn giá nhập</th>
                        <th className="p-2.5 text-center">Tình trạng lô</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {batches
                        .filter((b) => b.medicineId === selectedMedicine.id)
                        .sort((a, b) => new Date(a.expDate).getTime() - new Date(b.expDate).getTime())
                        .map((b) => {
                          const daysLeft = getDaysRemaining(b.expDate);
                          return (
                            <tr key={b.id} className="hover:bg-slate-50">
                              <td className="p-2.5 font-mono font-bold text-slate-900">
                                {b.batchNumber}
                              </td>
                              <td className="p-2.5 text-slate-600">{formatDateVN(b.mfgDate)}</td>
                              <td className="p-2.5">
                                <span className="font-bold text-slate-800">
                                  {formatDateVN(b.expDate)}
                                </span>
                                <span
                                  className={`block text-[10px] font-bold ${
                                    daysLeft < 0
                                      ? 'text-rose-600'
                                      : daysLeft <= 30
                                      ? 'text-orange-600'
                                      : 'text-emerald-600'
                                  }`}
                                >
                                  {daysLeft < 0
                                    ? `Quá hạn ${Math.abs(daysLeft)} ngày`
                                    : `Còn ${daysLeft} ngày`}
                                </span>
                              </td>
                              <td className="p-2.5 text-right font-black text-slate-900">
                                {b.quantity} {selectedMedicine.unit}
                              </td>
                              <td className="p-2.5 text-right font-medium text-slate-700">
                                {formatVND(b.unitPrice)}
                              </td>
                              <td className="p-2.5 text-center">
                                {daysLeft < 0 ? (
                                  <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-bold">
                                    ĐÃ HẾT HẠN
                                  </span>
                                ) : daysLeft <= 30 ? (
                                  <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-800 text-[10px] font-bold">
                                    SẮP HẾT HẠN (Ưu tiên FEFO)
                                  </span>
                                ) : b.quantity === 0 ? (
                                  <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px]">
                                    Đã xuất hết
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                                    Đang sử dụng
                                  </span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  const med = selectedMedicine;
                  setSelectedMedicine(null);
                  onOpenImportForMed(med);
                }}
                className="px-3 py-2 rounded-xl bg-blue-50 text-blue-700 border border-blue-200 font-bold hover:bg-blue-100"
              >
                + Lập Phiếu Nhập Thêm Lô
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const med = selectedMedicine;
                    setSelectedMedicine(null);
                    onOpenEditModal(med);
                  }}
                  className="px-3 py-2 rounded-xl bg-slate-200 text-slate-800 font-bold hover:bg-slate-300"
                >
                  Sửa thông tin
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedMedicine(null)}
                  className="px-4 py-2 bg-slate-800 text-white font-semibold rounded-xl"
                >
                  Đóng
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showImportExcelModal && (
        <ImportExcelModal
          onClose={() => setShowImportExcelModal(false)}
          onSuccess={() => {
            setSearchTerm((s) => s);
          }}
        />
      )}
    </div>
  );
};
