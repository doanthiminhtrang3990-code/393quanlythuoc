import React, { useState } from 'react';
import {
  Settings,
  Database,
  Download,
  Upload,
  RefreshCw,
  Check,
  AlertTriangle,
  FileJson,
  ShieldCheck,
  Building,
} from 'lucide-react';
import { db } from '../services/db';

export const BackupAndSettings: React.FC = () => {
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [restoreConfirmData, setRestoreConfirmData] = useState<string | null>(null);

  // Settings state
  const [schoolName, setSchoolName] = useState('TRƯỜNG THCS ĐÔNG THẠNH');
  const [schoolYear, setSchoolYear] = useState('2026-2027');
  const [medicName, setMedicName] = useState('Y sĩ Trần Thị Bích Thảo');
  const [expiryWarningDays, setExpiryWarningDays] = useState(90);

  // Export JSON Backup
  const handleExportBackup = () => {
    const jsonStr = db.exportBackupJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Sao_Luu_Y_Te_THCS_Dong_Thanh_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setSuccessMessage('Đã tải xuống tệp sao lưu dữ liệu toàn diện JSON!');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  // Upload JSON for Restore
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        JSON.parse(text); // validate JSON syntax
        setRestoreConfirmData(text);
      } catch (err: any) {
        setErrorMessage('Tệp không đúng định dạng JSON hợp lệ.');
      }
    };
    reader.readAsText(file);
  };

  // Confirm Restore
  const handleConfirmRestore = () => {
    if (!restoreConfirmData) return;
    try {
      db.restoreBackupJson(restoreConfirmData);
      setRestoreConfirmData(null);
      setSuccessMessage('Đã khôi phục dữ liệu hệ thống thành công!');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setErrorMessage(`Lỗi khi khôi phục: ${err.message}`);
    }
  };

  // Factory Reset
  const handleResetSeedData = () => {
    const ok = window.confirm(
      'CẢNH BÁO: Thao tác này sẽ nạp lại toàn bộ dữ liệu mẫu chuẩn THCS Đông Thạnh cho tất cả các mô-đun (Thuốc, Kho, Học sinh, Lượt khám, Sự kiện). Bạn có chắc chắn muốn tiếp tục?'
    );
    if (!ok) return;

    db.seedDemoData();
    setSuccessMessage('Đã khôi phục dữ liệu mẫu ban đầu thành công!');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">
            HỆ THỐNG
          </span>
          <h1 className="text-xl font-bold text-slate-900">Cài Đặt Hệ Thống & Sao Lưu / Phục Hồi Dữ Liệu</h1>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Trường THCS Đông Thạnh • Quản lý thông tin trường, ngưỡng cảnh báo an toàn y tế và sao lưu dữ liệu
        </p>
      </div>

      {/* Notifications */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-300 text-rose-800 rounded-xl text-xs font-semibold flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Box 1: Cài đặt thông tin trường học & Cán bộ */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h2 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Building className="w-4 h-4 text-emerald-700" />
            <span>Thông Tin Đơn Vị & Cấu Hình Y Tế</span>
          </h2>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Tên trường học</label>
              <input
                type="text"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2 font-bold text-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Năm học áp dụng</label>
                <input
                  type="text"
                  value={schoolYear}
                  onChange={(e) => setSchoolYear(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ngưỡng cảnh báo HSD (ngày)</label>
                <input
                  type="number"
                  value={expiryWarningDays}
                  onChange={(e) => setExpiryWarningDays(parseInt(e.target.value, 10) || 90)}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 font-bold text-amber-700"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Cán bộ y tế phụ trách</label>
              <input
                type="text"
                value={medicName}
                onChange={(e) => setMedicName(e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>

            <button
              onClick={() => {
                setSuccessMessage('Đã lưu cấu hình hệ thống!');
                setTimeout(() => setSuccessMessage(null), 3000);
              }}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold shadow-xs"
            >
              Lưu cấu hình
            </button>
          </div>
        </div>

        {/* Box 2: Sao lưu & Khôi phục dữ liệu */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h2 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Database className="w-4 h-4 text-blue-700" />
            <span>Sao Lưu & Phục Hồi Dữ Liệu (Backup JSON)</span>
          </h2>

          <p className="text-xs text-slate-500 leading-relaxed">
            Hệ thống hỗ trợ xuất và nhập bản sao lưu toàn diện chứa đầy đủ danh mục thuốc, các lô thuốc FEFO, lịch sử giao
            dịch, hồ sơ học sinh, sổ khám bệnh và nhật ký audit log.
          </p>

          <div className="space-y-3 pt-2">
            <button
              onClick={handleExportBackup}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Tải tệp sao lưu dữ liệu (.json)</span>
            </button>

            <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center">
              <label className="block text-xs font-semibold text-slate-700 mb-1 cursor-pointer">
                Nạp tệp khôi phục (.json)
              </label>
              <input
                type="file"
                accept=".json"
                onChange={handleFileChange}
                className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-slate-700 cursor-pointer"
              />
            </div>

            <div className="pt-2 border-t border-slate-100">
              <button
                onClick={handleResetSeedData}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-semibold transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Nạp lại dữ liệu mẫu ban đầu</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Restore Confirmation Modal */}
      {restoreConfirmData && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-amber-600 mb-3">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="font-bold text-base text-slate-900">Xác Nhận Khôi Phục Dữ Liệu</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Bạn có chắc chắn muốn ghi đè toàn bộ dữ liệu hiện tại bằng tệp sao lưu đã chọn? Dữ liệu hiện tại chưa được
              sao lưu sẽ bị thay thế.
            </p>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                onClick={() => setRestoreConfirmData(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Hủy bỏ
              </button>
              <button
                onClick={handleConfirmRestore}
                className="px-4 py-2 text-xs font-semibold bg-blue-700 hover:bg-blue-800 text-white rounded-xl shadow-xs"
              >
                Đồng ý khôi phục
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
