import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  Shield,
  ShieldCheck,
  User,
  UserPlus,
  UserCog,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Edit3,
  Trash2,
  Lock,
  Check,
  X,
  Info,
  Stethoscope,
  Sliders,
  Sparkles,
  Phone,
  Mail,
  Building,
  ArrowRightLeft,
  GraduationCap,
  Building2,
  Award,
  ChevronDown,
} from 'lucide-react';
import { db, getRoleLabel } from '../services/db';
import { getUsers as getFirebaseUsers, updateUserRole as updateFirebaseUserRole, saveUserToFirebase } from '../services/firebase';
import { User as UserType, UserRole, UserPermission } from '../types';

// Danh sách các quyền hạn hệ thống chi tiết cho 3 nhóm
export interface PermissionConfigItem {
  key: keyof UserPermission;
  label: string;
  description: string;
  group: string;
  bghDefault: boolean;
  adminDefault: boolean;
  medicDefault: boolean;
  bghNote: string;
  adminNote: string;
  medicNote: string;
}

const PERMISSION_CONFIG: PermissionConfigItem[] = [
  {
    key: 'canManageMedicine',
    label: '1. Quản lý Danh mục Thuốc & Vật tư y tế',
    description: 'Thêm mới, cập nhật danh mục thuốc, quy cách, nồng độ, hàm lượng và định mức tồn kho tối thiểu',
    group: 'Dược phẩm & Vật tư',
    bghDefault: true,
    adminDefault: true,
    medicDefault: true,
    bghNote: 'Xem & giám sát danh mục',
    adminNote: 'Toàn quyền cấu hình',
    medicNote: 'Thực hiện cập nhật kho',
  },
  {
    key: 'canManageTransactions',
    label: '2. Quản lý Nhập - Xuất kho thuốc & Biên bản hủy',
    description: 'Lập phiếu nhập kho từ nhà cung cấp, xuất cấp phát theo FEFO, lập biên bản hủy thuốc hết hạn',
    group: 'Kho dược & Cấp phát',
    bghDefault: true,
    adminDefault: true,
    medicDefault: true,
    bghNote: 'Xem & giám sát xuất nhập',
    adminNote: 'Toàn quyền quản trị',
    medicNote: 'Lập phiếu nhập xuất FEFO',
  },
  {
    key: 'canManageClinicVisits',
    label: '3. Tiếp nhận khám & Cấp phát thuốc học sinh',
    description: 'Ghi nhận lượt khám sơ cứu học sinh, chẩn đoán, cấp phát thuốc theo liều, chuyển viện và liên hệ phụ huynh',
    group: 'Khám chữa bệnh & Sơ cứu',
    bghDefault: true,
    adminDefault: true,
    medicDefault: true,
    bghNote: 'Xem lịch sử khám sơ cứu',
    adminNote: 'Toàn quyền giám sát',
    medicNote: 'Trực tiếp khám & xử trí',
  },
  {
    key: 'canManageStudents',
    label: '4. Hồ sơ sức khỏe & Khám định kỳ học sinh',
    description: 'Quản lý tiền sử bệnh tật, dị ứng thuốc, đợt khám sức khỏe đầu năm và in sổ theo dõi A4 chuẩn',
    group: 'Hồ sơ học sinh',
    bghDefault: true,
    adminDefault: true,
    medicDefault: true,
    bghNote: 'Xem hồ sơ sức khỏe toàn trường',
    adminNote: 'Toàn quyền đồng bộ dữ liệu',
    medicNote: 'Cập nhật tiền sử & khám định kỳ',
  },
  {
    key: 'canManageInventoryCheck',
    label: '5. Kiểm kê & Cân đối kho thuốc định kỳ',
    description: 'Khởi tạo đợt kiểm kê, đối soát số liệu sổ sách với thực tế trong tủ y tế, xử lý chênh lệch tồn',
    group: 'Kho dược & Cấp phát',
    bghDefault: true,
    adminDefault: true,
    medicDefault: true,
    bghNote: 'Phê duyệt kết quả kiểm kê',
    adminNote: 'Toàn quyền điều chỉnh số liệu',
    medicNote: 'Kiểm đếm thực tế tủ thuốc',
  },
  {
    key: 'canViewReports',
    label: '6. Báo cáo thống kê y tế & In mẫu chuẩn A4',
    description: 'Báo cáo xuất nhập tồn, sổ theo dõi cấp phát thuốc, tổng hợp bệnh tật theo mẫu Bộ GD&ĐT/BYT',
    group: 'Báo cáo & Thống kê',
    bghDefault: true,
    adminDefault: true,
    medicDefault: true,
    bghNote: 'Xem & ký duyệt báo cáo',
    adminNote: 'Xuất in & kết xuất số liệu',
    medicNote: 'Lập & in báo cáo nghiệp vụ',
  },
  {
    key: 'canManageSettings',
    label: '7. Quản trị hệ thống & Cấu hình phân quyền',
    description: 'Tạo tài khoản cán bộ, điều chỉnh ma trận phân quyền, sao lưu/khôi phục dữ liệu và cấu hình trường',
    group: 'Quản trị hệ thống',
    bghDefault: false,
    adminDefault: true,
    medicDefault: false,
    bghNote: 'Không can thiệp kỹ thuật',
    adminNote: 'Toàn quyền quản trị',
    medicNote: 'Không có quyền',
  },
  {
    key: 'canApproveAudits',
    label: '8. Phê duyệt kiểm kê & Quyết định xuất hủy thuốc',
    description: 'Thẩm quyền cao nhất để ký duyệt biên bản đối chiếu tồn kho và phê duyệt xuất hủy dược phẩm hết hạn',
    group: 'Lãnh đạo & Giám sát',
    bghDefault: true,
    adminDefault: true,
    medicDefault: false,
    bghNote: 'Thẩm quyền ký duyệt cao nhất',
    adminNote: 'Quyền quản trị dự phòng',
    medicNote: 'Lập biên bản chờ duyệt',
  },
];

export const RoleManagement: React.FC = () => {
  const [users, setUsers] = useState<UserType[]>(() => db.getUsers());
  const [currentUser, setCurrentUser] = useState<UserType>(() => db.getCurrentUser());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [activeSubTab, setActiveSubTab] = useState<'users' | 'matrix'>('users');

  // Modals
  const [editingUser, setEditingUser] = useState<UserType | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [confirmRoleChange, setConfirmRoleChange] = useState<{
    user: UserType;
    newRole: UserRole;
  } | null>(null);
  const [confirmDeleteUser, setConfirmDeleteUser] = useState<UserType | null>(null);

  // Form states for Add Modal
  const [newUserForm, setNewUserForm] = useState<{
    fullName: string;
    username: string;
    email: string;
    phone: string;
    title: string;
    department: string;
    role: UserRole;
  }>({
    fullName: '',
    username: '',
    email: '',
    phone: '',
    title: 'Nhân viên Y tế học đường',
    department: 'Phòng Y tế Học đường',
    role: 'medic',
  });

  // Subscribe to db changes
  useEffect(() => {
    const unsubscribe = db.subscribe(() => {
      setUsers(db.getUsers());
      setCurrentUser(db.getCurrentUser());
    });
    return () => unsubscribe();
  }, []);

  // Sync users from Firebase
  const handleSyncFirebase = async () => {
    setLoading(true);
    setError(null);
    try {
      const fbUsers = await getFirebaseUsers();
      if (fbUsers && fbUsers.length > 0) {
        db.syncUsers(fbUsers);
        setSuccessMsg(`Đã đồng bộ thành công ${fbUsers.length} tài khoản từ Firebase Firestore!`);
      } else {
        setSuccessMsg('Danh sách tài khoản nội bộ đã sẵn sàng và được đồng bộ an toàn.');
      }
      setTimeout(() => setSuccessMsg(null), 3500);
    } catch (err: any) {
      console.warn('Sync warning:', err);
      setUsers(db.getUsers());
    } finally {
      setLoading(false);
    }
  };

  // Quick switch active role for live preview
  const handleSwitchCurrentRole = (targetRole: UserRole) => {
    db.setCurrentUserRole(targetRole);
    setCurrentUser(db.getCurrentUser());
    setSuccessMsg(`Đã chuyển chế độ trải nghiệm sang: ${getRoleLabel(targetRole)}`);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  // Execute quick role change
  const handleExecuteRoleChange = async () => {
    if (!confirmRoleChange) return;
    const { user, newRole } = confirmRoleChange;
    setLoading(true);
    try {
      const defaultPerms: UserPermission = {
        canManageMedicine: true,
        canManageTransactions: true,
        canManageClinicVisits: true,
        canManageStudents: true,
        canManageInventoryCheck: true,
        canViewReports: true,
        canManageSettings: newRole === 'admin',
        canApproveAudits: newRole === 'bgh' || newRole === 'admin',
      };

      const updated = db.updateUser(user.id, {
        role: newRole,
        permissions: defaultPerms,
      });

      try {
        await updateFirebaseUserRole(user.id, newRole, updated);
      } catch (fbErr) {
        console.warn('Firebase role update fallback to local db:', fbErr);
      }

      setUsers(db.getUsers());
      setSuccessMsg(`Đã đổi vai trò của "${user.fullName}" thành "${getRoleLabel(newRole)}" thành công!`);
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Không thể cập nhật quyền người dùng.');
    } finally {
      setLoading(false);
      setConfirmRoleChange(null);
    }
  };

  // Toggle user active / inactive status
  const handleToggleStatus = (user: UserType) => {
    try {
      const updated = db.toggleUserStatus(user.id);
      setUsers(db.getUsers());
      setSuccessMsg(`Đã ${updated.status === 'active' ? 'kích hoạt' : 'tạm khóa'} tài khoản "${user.fullName}".`);
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Thao tác không thành công.');
    }
  };

  // Delete user
  const handleExecuteDeleteUser = () => {
    if (!confirmDeleteUser) return;
    try {
      db.deleteUser(confirmDeleteUser.id);
      setUsers(db.getUsers());
      setSuccessMsg(`Đã xóa tài khoản "${confirmDeleteUser.fullName}" khỏi hệ thống.`);
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Không thể xóa tài khoản này.');
    } finally {
      setConfirmDeleteUser(null);
    }
  };

  // Save edit user modal
  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    setLoading(true);
    try {
      const updated = db.updateUser(editingUser.id, {
        fullName: editingUser.fullName.trim(),
        username: editingUser.username.trim().toLowerCase(),
        email: editingUser.email?.trim(),
        phone: editingUser.phone?.trim(),
        title: editingUser.title?.trim(),
        department: editingUser.department?.trim(),
        role: editingUser.role,
        status: editingUser.status || 'active',
        permissions: editingUser.permissions,
      });

      try {
        await updateFirebaseUserRole(editingUser.id, editingUser.role, updated);
      } catch (fbErr) {
        console.warn('Firebase role update fallback:', fbErr);
      }

      setUsers(db.getUsers());
      setSuccessMsg(`Đã cập nhật thông tin và phân quyền cho cán bộ "${updated.fullName}"!`);
      setTimeout(() => setSuccessMsg(null), 3000);
      setEditingUser(null);
    } catch (err: any) {
      setError(err.message || 'Không thể lưu thay đổi.');
    } finally {
      setLoading(false);
    }
  };

  // Create new user
  const handleCreateNewUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserForm.fullName.trim()) {
      setError('Vui lòng nhập họ và tên cán bộ.');
      return;
    }
    if (!newUserForm.username.trim()) {
      setError('Vui lòng nhập tên đăng nhập.');
      return;
    }

    setLoading(true);
    try {
      const defaultPerms: UserPermission = {
        canManageMedicine: true,
        canManageTransactions: true,
        canManageClinicVisits: true,
        canManageStudents: true,
        canManageInventoryCheck: true,
        canViewReports: true,
        canManageSettings: newUserForm.role === 'admin',
        canApproveAudits: newUserForm.role === 'bgh' || newUserForm.role === 'admin',
      };

      const newUser = db.addUser({
        fullName: newUserForm.fullName.trim(),
        username: newUserForm.username.trim().toLowerCase(),
        email: newUserForm.email.trim(),
        phone: newUserForm.phone.trim(),
        title: newUserForm.title.trim(),
        department: newUserForm.department.trim(),
        role: newUserForm.role,
        status: 'active',
        permissions: defaultPerms,
      });

      try {
        await saveUserToFirebase(newUser);
      } catch (fbErr) {
        console.warn('Firebase save warning:', fbErr);
      }

      setUsers(db.getUsers());
      setSuccessMsg(`Đã thêm mới cán bộ "${newUser.fullName}" với vai trò ${getRoleLabel(newUser.role)}!`);
      setTimeout(() => setSuccessMsg(null), 3000);
      setIsAddModalOpen(false);
      setNewUserForm({
        fullName: '',
        username: '',
        email: '',
        phone: '',
        title: 'Nhân viên Y tế học đường',
        department: 'Phòng Y tế Học đường',
        role: 'medic',
      });
    } catch (err: any) {
      setError(err.message || 'Không thể tạo mới cán bộ.');
    } finally {
      setLoading(false);
    }
  };

  // Filtered Users list
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        u.fullName?.toLowerCase().includes(q) ||
        u.email?.toLowerCase().includes(q) ||
        u.username?.toLowerCase().includes(q) ||
        u.title?.toLowerCase().includes(q) ||
        u.department?.toLowerCase().includes(q);

      const matchesRole = roleFilter === 'all' || u.role === roleFilter;
      const matchesStatus = statusFilter === 'all' || (u.status || 'active') === statusFilter;

      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [users, searchQuery, roleFilter, statusFilter]);

  // Statistics across the 3 groups
  const stats = useMemo(() => {
    const total = users.length;
    const bghCount = users.filter((u) => u.role === 'bgh').length;
    const adminCount = users.filter((u) => u.role === 'admin').length;
    const medicCount = users.filter((u) => u.role === 'medic').length;
    const active = users.filter((u) => (u.status || 'active') === 'active').length;
    return { total, bghCount, adminCount, medicCount, active };
  }, [users]);

  // Role Badge Helper
  const renderRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'bgh':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-purple-100 text-purple-800 border border-purple-300 shadow-2xs">
            <GraduationCap className="w-3.5 h-3.5 text-purple-700" />
            <span>Ban Giám Hiệu</span>
          </span>
        );
      case 'admin':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-indigo-100 text-indigo-800 border border-indigo-300 shadow-2xs">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-700" />
            <span>Quản Trị Viên</span>
          </span>
        );
      case 'medic':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
            <Stethoscope className="w-3.5 h-3.5 text-emerald-700" />
            <span>Nhân Viên Y Tế</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Notifications */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl flex items-center justify-between text-xs font-medium">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={() => setError(null)} className="p-1 hover:bg-rose-100 rounded text-rose-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl flex items-center justify-between text-xs font-medium shadow-xs">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="p-1 hover:bg-emerald-100 rounded text-emerald-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Banner: 3-Role Fast Experience Switcher */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 sm:p-5 rounded-2xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 border border-slate-800">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center shrink-0">
            {currentUser?.role === 'bgh' ? (
              <GraduationCap className="w-6 h-6 text-purple-300" />
            ) : currentUser?.role === 'admin' ? (
              <ShieldCheck className="w-6 h-6 text-indigo-300" />
            ) : (
              <Stethoscope className="w-6 h-6 text-emerald-300" />
            )}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-300 font-medium">Tài khoản đang đăng nhập:</span>
              <span className="font-bold text-sm text-white">{currentUser?.fullName}</span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide border ${
                  currentUser?.role === 'bgh'
                    ? 'bg-purple-500/20 text-purple-300 border-purple-400/40'
                    : currentUser?.role === 'admin'
                    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                }`}
              >
                {getRoleLabel(currentUser?.role || 'medic')}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 flex flex-wrap items-center gap-2">
              <span>{currentUser?.email || 'Chưa liên kết email'}</span>
              <span>•</span>
              <span>Chức vụ: {currentUser?.title || 'Phụ trách y tế'}</span>
            </p>
          </div>
        </div>

        {/* 3 Role Quick Switch Buttons */}
        <div className="flex items-center gap-1.5 bg-white/10 p-1.5 rounded-xl border border-white/15 self-start md:self-auto flex-wrap">
          <span className="text-[11px] font-semibold text-slate-300 px-2 hidden lg:inline">Trải nghiệm vai trò:</span>
          
          {/* BGH Switch */}
          <button
            type="button"
            onClick={() => handleSwitchCurrentRole('bgh')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              currentUser?.role === 'bgh'
                ? 'bg-purple-600 text-white shadow-xs scale-102'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="Chuyển sang góc nhìn Ban Giám Hiệu: Giám sát, phê duyệt kiểm kê & biên bản hủy thuốc"
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>1. Ban Giám Hiệu</span>
          </button>

          {/* Admin Switch */}
          <button
            type="button"
            onClick={() => handleSwitchCurrentRole('admin')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              currentUser?.role === 'admin'
                ? 'bg-indigo-600 text-white shadow-xs scale-102'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="Chuyển sang góc nhìn Quản Trị Viên: Toàn quyền cấu hình hệ thống, phân quyền và sao lưu"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>2. Quản Trị Viên</span>
          </button>

          {/* Medic Switch */}
          <button
            type="button"
            onClick={() => handleSwitchCurrentRole('medic')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              currentUser?.role === 'medic'
                ? 'bg-emerald-600 text-white shadow-xs scale-102'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="Chuyển sang góc nhìn Nhân Viên Y Tế: Khám sơ cứu, cấp phát thuốc, lập phiếu nhập xuất FEFO"
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>3. Nhân Viên Y Tế</span>
          </button>
        </div>
      </div>

      {/* 3 Core Groups Showcase Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Group 1: Ban Giám Hiệu */}
        <div 
          onClick={() => setRoleFilter(roleFilter === 'bgh' ? 'all' : 'bgh')}
          className={`p-4 rounded-2xl border-2 transition-all cursor-pointer bg-white relative overflow-hidden ${
            roleFilter === 'bgh'
              ? 'border-purple-500 shadow-md ring-2 ring-purple-200'
              : 'border-purple-200 hover:border-purple-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-start justify-between">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold">
              <GraduationCap className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-purple-900 bg-purple-50 px-2.5 py-0.5 rounded-lg border border-purple-200">
              {stats.bghCount} cán bộ
            </span>
          </div>
          <h3 className="text-sm font-bold text-slate-900 mt-3 flex items-center gap-1.5">
            <span>NHÓM 1: BAN GIÁM HIỆU</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">Hiệu trưởng, Phó Hiệu trưởng phụ trách CSVC & Y tế</p>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-600 space-y-1">
            <p className="flex items-center gap-1.5 text-purple-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-purple-600" />
              <span>Giám sát toàn diện công tác y tế học đường</span>
            </p>
            <p className="flex items-center gap-1.5 text-purple-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-purple-600" />
              <span>Phê duyệt kiểm kê & biên bản xuất hủy thuốc</span>
            </p>
            <p className="flex items-center gap-1.5 text-purple-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-purple-600" />
              <span>Xem báo cáo tổng hợp & hồ sơ sức khỏe</span>
            </p>
          </div>
        </div>

        {/* Group 2: Quản Trị Viên */}
        <div 
          onClick={() => setRoleFilter(roleFilter === 'admin' ? 'all' : 'admin')}
          className={`p-4 rounded-2xl border-2 transition-all cursor-pointer bg-white relative overflow-hidden ${
            roleFilter === 'admin'
              ? 'border-indigo-500 shadow-md ring-2 ring-indigo-200'
              : 'border-indigo-200 hover:border-indigo-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-start justify-between">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-indigo-900 bg-indigo-50 px-2.5 py-0.5 rounded-lg border border-indigo-200">
              {stats.adminCount} cán bộ
            </span>
          </div>
          <h3 className="text-sm font-bold text-slate-900 mt-3 flex items-center gap-1.5">
            <span>NHÓM 2: QUẢN TRỊ VIÊN (ADMIN / IT)</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">Tổ CNTT, Cán bộ phụ trách quản trị kỹ thuật</p>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-600 space-y-1">
            <p className="flex items-center gap-1.5 text-indigo-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-indigo-600" />
              <span>Quản lý tài khoản & ma trận phân quyền</span>
            </p>
            <p className="flex items-center gap-1.5 text-indigo-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-indigo-600" />
              <span>Cấu hình thông số trường học & hệ thống</span>
            </p>
            <p className="flex items-center gap-1.5 text-indigo-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-indigo-600" />
              <span>Sao lưu, phục hồi dữ liệu & nhật ký kiểm toán</span>
            </p>
          </div>
        </div>

        {/* Group 3: Nhân Viên Y Tế */}
        <div 
          onClick={() => setRoleFilter(roleFilter === 'medic' ? 'all' : 'medic')}
          className={`p-4 rounded-2xl border-2 transition-all cursor-pointer bg-white relative overflow-hidden ${
            roleFilter === 'medic'
              ? 'border-emerald-500 shadow-md ring-2 ring-emerald-200'
              : 'border-emerald-200 hover:border-emerald-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-start justify-between">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Stethoscope className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-emerald-900 bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-200">
              {stats.medicCount} cán bộ
            </span>
          </div>
          <h3 className="text-sm font-bold text-slate-900 mt-3 flex items-center gap-1.5">
            <span>NHÓM 3: NHÂN VIÊN Y TẾ (MEDIC)</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">Cán bộ chuyên trách y tế học đường, điều dưỡng</p>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-600 space-y-1">
            <p className="flex items-center gap-1.5 text-emerald-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>Tiếp nhận khám, sơ cứu & cấp thuốc theo liều</span>
            </p>
            <p className="flex items-center gap-1.5 text-emerald-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>Lập phiếu nhập xuất kho theo nguyên tắc FEFO</span>
            </p>
            <p className="flex items-center gap-1.5 text-emerald-800 font-semibold">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>Theo dõi hồ sơ sức khỏe & khám định kỳ A4</span>
            </p>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Navigation Tabs Header */}
        <div className="border-b border-slate-200 bg-slate-50/70 px-4 pt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveSubTab('users')}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-colors ${
                activeSubTab === 'users'
                  ? 'border-indigo-600 text-indigo-700 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserCog className="w-4 h-4" />
              <span>Danh Sách Cán Bộ & Phân Quyền ({users.length})</span>
            </button>
            <button
              onClick={() => setActiveSubTab('matrix')}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-colors ${
                activeSubTab === 'matrix'
                  ? 'border-indigo-600 text-indigo-700 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>Ma Trận So Sánh Quyền Hạn 3 Nhóm</span>
            </button>
          </div>

          <div className="flex items-center gap-2 pb-2 sm:pb-0">
            <button
              type="button"
              onClick={handleSyncFirebase}
              disabled={loading}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors"
              title="Đồng bộ lại danh sách từ Firebase"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Đồng bộ</span>
            </button>

            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-xs"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>+ Thêm Cán Bộ Mới</span>
            </button>
          </div>
        </div>

        {/* TAB 1: DANH SÁCH CÁN BỘ & PHÂN QUYỀN */}
        {activeSubTab === 'users' && (
          <div className="p-4 sm:p-5 space-y-4">
            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Tìm theo tên cán bộ, email, chức danh..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <span className="font-semibold">Lọc nhóm:</span>
                  <select
                    value={roleFilter}
                    onChange={(e) => setRoleFilter(e.target.value as any)}
                    className="text-xs border border-slate-200 rounded-xl px-2.5 py-1.5 bg-white text-slate-700 font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option value="all">Tất cả các nhóm ({users.length})</option>
                    <option value="bgh">👑 Ban Giám Hiệu ({stats.bghCount})</option>
                    <option value="admin">🛡️ Quản Trị Viên ({stats.adminCount})</option>
                    <option value="medic">🩺 Nhân Viên Y Tế ({stats.medicCount})</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <span className="font-semibold">Trạng thái:</span>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as any)}
                    className="text-xs border border-slate-200 rounded-xl px-2.5 py-1.5 bg-white text-slate-700 font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option value="all">Tất cả</option>
                    <option value="active">Đang hoạt động ({stats.active})</option>
                    <option value="inactive">Đang tạm khóa ({users.length - stats.active})</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Users Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Cán bộ / Tài khoản</th>
                    <th className="py-3 px-4">Đơn vị & Chức danh</th>
                    <th className="py-3 px-4">Nhóm vai trò</th>
                    <th className="py-3 px-4">Phân quyền chi tiết</th>
                    <th className="py-3 px-4 text-center">Trạng thái</th>
                    <th className="py-3 px-4 text-right">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-10 text-center text-slate-500">
                        <UserCog className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                        <p className="font-semibold">Không tìm thấy cán bộ phù hợp</p>
                        <p className="text-[11px] text-slate-400 mt-1">
                          Vui lòng kiểm tra lại từ khóa tìm kiếm hoặc bỏ chọn bộ lọc nhóm.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((user) => {
                      const isCurrent = currentUser?.id === user.id;
                      const isActive = (user.status || 'active') === 'active';

                      return (
                        <tr key={user.id} className={`hover:bg-slate-50/80 transition-colors ${!isActive ? 'opacity-60 bg-slate-50/40' : ''}`}>
                          {/* Col 1: Cán bộ */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-3">
                              <div
                                className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs ${
                                  user.role === 'bgh'
                                    ? 'bg-purple-100 text-purple-700 border border-purple-300'
                                    : user.role === 'admin'
                                    ? 'bg-indigo-100 text-indigo-700 border border-indigo-300'
                                    : 'bg-emerald-100 text-emerald-700 border border-emerald-300'
                                }`}
                              >
                                {user.fullName ? user.fullName.charAt(0).toUpperCase() : <User className="w-4 h-4" />}
                              </div>
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-slate-900 text-xs">{user.fullName}</span>
                                  {isCurrent && (
                                    <span className="px-1.5 py-0.2 rounded text-[9px] font-extrabold bg-blue-100 text-blue-800">
                                      Bạn
                                    </span>
                                  )}
                                </div>
                                <div className="text-slate-500 text-[11px] flex items-center gap-2 mt-0.5">
                                  <span className="font-mono text-slate-400">@{user.username || 'user'}</span>
                                  {user.email && (
                                    <span className="flex items-center gap-1 text-slate-500 truncate max-w-[170px]" title={user.email}>
                                      <Mail className="w-3 h-3 text-slate-400" />
                                      {user.email}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Col 2: Đơn vị & Chức danh */}
                          <td className="py-3.5 px-4">
                            <p className="font-medium text-slate-800 text-xs">{user.title || 'Cán bộ trường'}</p>
                            <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                              <Building className="w-3 h-3 text-slate-400" />
                              {user.department || 'Đơn vị công tác'}
                            </p>
                          </td>

                          {/* Col 3: Nhóm vai trò với chuyển đổi 1 chạm */}
                          <td className="py-3.5 px-4">
                            <div className="space-y-1.5">
                              {renderRoleBadge(user.role)}
                              
                              {/* Quick Switch Dropdown */}
                              <div className="flex items-center gap-1">
                                <select
                                  value={user.role}
                                  onChange={(e) => {
                                    const targetR = e.target.value as UserRole;
                                    if (targetR !== user.role) {
                                      setConfirmRoleChange({ user, newRole: targetR });
                                    }
                                  }}
                                  className="text-[10px] font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg px-2 py-0.5 outline-none cursor-pointer transition-colors"
                                  title="Đổi nhanh nhóm vai trò"
                                >
                                  <option value="bgh">Đổi sang: Ban Giám Hiệu</option>
                                  <option value="admin">Đổi sang: Quản Trị Viên</option>
                                  <option value="medic">Đổi sang: Nhân Viên Y Tế</option>
                                </select>
                              </div>
                            </div>
                          </td>

                          {/* Col 4: Quyền hạn chi tiết */}
                          <td className="py-3.5 px-4">
                            {user.role === 'bgh' ? (
                              <div className="space-y-0.5">
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-800 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                                  <Award className="w-3 h-3 text-purple-600" />
                                  Lãnh đạo & Phê duyệt cao nhất
                                </span>
                                <p className="text-[10px] text-slate-500">Giám sát toàn trường, ký duyệt kiểm kê & hủy thuốc</p>
                              </div>
                            ) : user.role === 'admin' ? (
                              <div className="space-y-0.5">
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                                  <Sparkles className="w-3 h-3 text-indigo-500" />
                                  Toàn quyền quản trị kỹ thuật
                                </span>
                                <p className="text-[10px] text-slate-500">Cấu hình, phân quyền, sao lưu & audit logs</p>
                              </div>
                            ) : (
                              <div className="flex flex-wrap gap-1 max-w-xs">
                                <span className="inline-block px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-semibold border border-emerald-100">
                                  Khám sơ cứu
                                </span>
                                <span className="inline-block px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-semibold border border-blue-100">
                                  Nhập/Xuất FEFO
                                </span>
                                <span className="inline-block px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 text-[10px] font-semibold border border-teal-100">
                                  Hồ sơ sức khỏe
                                </span>
                                <span className="inline-block px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-semibold">
                                  Kiểm kê tủ thuốc
                                </span>
                              </div>
                            )}
                          </td>

                          {/* Col 5: Trạng thái */}
                          <td className="py-3.5 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => handleToggleStatus(user)}
                              title={isActive ? 'Nhấn để tạm khóa tài khoản' : 'Nhấn để mở khóa tài khoản'}
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold transition-all ${
                                isActive
                                  ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border border-emerald-300'
                                  : 'bg-slate-200 text-slate-700 hover:bg-slate-300 border border-slate-300'
                              }`}
                            >
                              {isActive ? <CheckCircle2 className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                              <span>{isActive ? 'Hoạt động' : 'Tạm khóa'}</span>
                            </button>
                          </td>

                          {/* Col 6: Thao tác */}
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setEditingUser(user)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors"
                                title="Chỉnh sửa thông tin và tinh chỉnh phân quyền"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                                <span>Chỉnh sửa</span>
                              </button>

                              {!isCurrent && (
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteUser(user)}
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                  title="Xóa tài khoản cán bộ"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Bottom Guideline */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-700 space-y-2">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Info className="w-4 h-4 text-indigo-600" />
                <span>Quy chuẩn phân cấp 3 nhóm tại Trường THCS Đông Thạnh:</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                <div className="p-3 bg-purple-50/70 border border-purple-200 rounded-xl">
                  <p className="font-bold text-purple-900 flex items-center gap-1.5">
                    <GraduationCap className="w-4 h-4 text-purple-700" />
                    <span>1. Ban Giám Hiệu</span>
                  </p>
                  <p className="text-purple-800 text-[11px] mt-1 leading-relaxed">
                    Theo dõi toàn trường, xem lịch sử khám, ký duyệt biên bản kiểm kê kho thuốc định kỳ và phê duyệt xuất hủy thuốc hết hạn.
                  </p>
                </div>

                <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl">
                  <p className="font-bold text-indigo-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-indigo-700" />
                    <span>2. Quản Trị Viên</span>
                  </p>
                  <p className="text-indigo-800 text-[11px] mt-1 leading-relaxed">
                    Phụ trách hạ tầng kỹ thuật, phân quyền người dùng, cấu hình trường học, sao lưu khôi phục và kiểm soát an toàn dữ liệu.
                  </p>
                </div>

                <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl">
                  <p className="font-bold text-emerald-900 flex items-center gap-1.5">
                    <Stethoscope className="w-4 h-4 text-emerald-700" />
                    <span>3. Nhân Viên Y Tế</span>
                  </p>
                  <p className="text-emerald-800 text-[11px] mt-1 leading-relaxed">
                    Trực tiếp phụ trách phòng y tế học đường, khám sơ cứu, cấp thuốc theo liều, quản lý tủ thuốc & vật tư theo chuẩn FEFO.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: BẢNG MA TRẬN PHÂN QUYỀN SO SÁNH 3 NHÓM */}
        {activeSubTab === 'matrix' && (
          <div className="p-4 sm:p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-indigo-600" />
                  <span>Bảng Ma Trận So Sánh Quyền Hạn Chi Tiết Giữa 3 Nhóm</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Quy chuẩn thẩm quyền phân cấp theo mô hình trường học chuẩn quốc gia.
                </p>
              </div>

              <div className="flex items-center gap-3 text-xs flex-wrap">
                <span className="flex items-center gap-1 font-bold text-purple-700">
                  <GraduationCap className="w-4 h-4" /> Ban Giám Hiệu
                </span>
                <span className="flex items-center gap-1 font-bold text-indigo-700">
                  <ShieldCheck className="w-4 h-4" /> Quản Trị Viên
                </span>
                <span className="flex items-center gap-1 font-bold text-emerald-700">
                  <Stethoscope className="w-4 h-4" /> Nhân Viên Y Tế
                </span>
              </div>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-4 w-2/5">Nghiệp vụ / Chức năng hệ thống</th>
                    <th className="py-3 px-3 text-center bg-purple-50/60 text-purple-900 border-x border-slate-200 w-1/5">
                      1. Ban Giám Hiệu (BGH)
                    </th>
                    <th className="py-3 px-3 text-center bg-indigo-50/60 text-indigo-900 border-r border-slate-200 w-1/5">
                      2. Quản Trị Viên (Admin)
                    </th>
                    <th className="py-3 px-3 text-center bg-emerald-50/60 text-emerald-900 w-1/5">
                      3. Nhân Viên Y Tế (Medic)
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {PERMISSION_CONFIG.map((perm, idx) => (
                    <tr key={perm.key} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'}>
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-xs">{perm.label}</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">
                              {perm.group}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500">{perm.description}</p>
                        </div>
                      </td>

                      {/* Col 1: BGH */}
                      <td className="py-3.5 px-3 text-center border-x border-slate-200 bg-purple-50/20">
                        <div className="inline-flex flex-col items-center">
                          {perm.bghDefault ? (
                            <>
                              <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center">
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </span>
                              <span className="text-[10px] font-bold text-purple-800 mt-1">{perm.bghNote}</span>
                            </>
                          ) : (
                            <>
                              <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
                                <X className="w-3.5 h-3.5 stroke-[2.5]" />
                              </span>
                              <span className="text-[10px] font-medium text-slate-400 mt-1">{perm.bghNote}</span>
                            </>
                          )}
                        </div>
                      </td>

                      {/* Col 2: Admin */}
                      <td className="py-3.5 px-3 text-center border-r border-slate-200 bg-indigo-50/20">
                        <div className="inline-flex flex-col items-center">
                          <span className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                          <span className="text-[10px] font-bold text-indigo-800 mt-1">{perm.adminNote}</span>
                        </div>
                      </td>

                      {/* Col 3: Medic */}
                      <td className="py-3.5 px-3 text-center bg-emerald-50/20">
                        <div className="inline-flex flex-col items-center">
                          {perm.medicDefault ? (
                            <>
                              <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </span>
                              <span className="text-[10px] font-bold text-emerald-800 mt-1">{perm.medicNote}</span>
                            </>
                          ) : (
                            <>
                              <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
                                <X className="w-3.5 h-3.5 stroke-[2.5]" />
                              </span>
                              <span className="text-[10px] font-medium text-slate-400 mt-1">{perm.medicNote}</span>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* ================= MODAL: CHỈNH SỬA CÁN BỘ & PHÂN QUYỀN ================= */}
      {editingUser && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                  <Edit3 className="w-5 h-5 text-indigo-300" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Chỉnh Sửa Cán Bộ & Phân Quyền</h3>
                  <p className="text-xs text-slate-300">
                    Cập nhật nhóm vai trò và tùy chỉnh quyền hạn chi tiết cho từng cán bộ
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSaveEditUser} className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1 text-xs">
              {/* 1. Basic Information */}
              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider border-b border-slate-100 pb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                  <span>1. Thông tin cán bộ</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Họ và tên cán bộ <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={editingUser.fullName}
                      onChange={(e) => setEditingUser({ ...editingUser, fullName: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Tên đăng nhập / Mã <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={editingUser.username}
                      onChange={(e) => setEditingUser({ ...editingUser, username: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Email liên hệ</label>
                    <input
                      type="email"
                      value={editingUser.email || ''}
                      onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                      placeholder="vidu@thcsdongthanh.edu.vn"
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Số điện thoại</label>
                    <input
                      type="tel"
                      value={editingUser.phone || ''}
                      onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                      placeholder="0908 xxx xxx"
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Chức vụ / Vị trí</label>
                    <input
                      type="text"
                      value={editingUser.title || ''}
                      onChange={(e) => setEditingUser({ ...editingUser, title: e.target.value })}
                      placeholder="Hiệu trưởng / Cán bộ Y tế học đường / Tổ trưởng CNTT"
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Phòng ban / Đơn vị</label>
                    <input
                      type="text"
                      value={editingUser.department || ''}
                      onChange={(e) => setEditingUser({ ...editingUser, department: e.target.value })}
                      placeholder="Ban Giám Hiệu / Phòng Y tế Học đường / Tổ CNTT"
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* 2. Three Distinct Roles Selection */}
              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider border-b border-slate-100 pb-1.5 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-indigo-600" />
                  <span>2. Chọn nhóm vai trò (3 nhóm chính thức)</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Option 1: BGH */}
                  <label
                    className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between gap-2 ${
                      editingUser.role === 'bgh'
                        ? 'border-purple-500 bg-purple-50/70 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="edit-role"
                        checked={editingUser.role === 'bgh'}
                        onChange={() => {
                          const defaultBghPerms: UserPermission = {
                            canManageMedicine: true,
                            canManageTransactions: true,
                            canManageClinicVisits: true,
                            canManageStudents: true,
                            canManageInventoryCheck: true,
                            canViewReports: true,
                            canManageSettings: false,
                            canApproveAudits: true,
                          };
                          setEditingUser({
                            ...editingUser,
                            role: 'bgh',
                            permissions: defaultBghPerms,
                          });
                        }}
                        className="text-purple-600 focus:ring-purple-500"
                      />
                      <span className="font-bold text-purple-950 text-xs">Ban Giám Hiệu</span>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-snug">
                      Giám sát toàn trường, phê duyệt kiểm kê & biên bản xuất hủy thuốc.
                    </p>
                  </label>

                  {/* Option 2: Admin */}
                  <label
                    className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between gap-2 ${
                      editingUser.role === 'admin'
                        ? 'border-indigo-500 bg-indigo-50/70 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="edit-role"
                        checked={editingUser.role === 'admin'}
                        onChange={() => {
                          const defaultAdminPerms: UserPermission = {
                            canManageMedicine: true,
                            canManageTransactions: true,
                            canManageClinicVisits: true,
                            canManageStudents: true,
                            canManageInventoryCheck: true,
                            canViewReports: true,
                            canManageSettings: true,
                            canApproveAudits: true,
                          };
                          setEditingUser({
                            ...editingUser,
                            role: 'admin',
                            permissions: defaultAdminPerms,
                          });
                        }}
                        className="text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="font-bold text-indigo-950 text-xs">Quản Trị Viên</span>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-snug">
                      Toàn quyền quản trị tài khoản, phân quyền, cấu hình hệ thống & sao lưu.
                    </p>
                  </label>

                  {/* Option 3: Medic */}
                  <label
                    className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between gap-2 ${
                      editingUser.role === 'medic'
                        ? 'border-emerald-500 bg-emerald-50/70 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="edit-role"
                        checked={editingUser.role === 'medic'}
                        onChange={() => {
                          const defaultMedicPerms: UserPermission = {
                            canManageMedicine: true,
                            canManageTransactions: true,
                            canManageClinicVisits: true,
                            canManageStudents: true,
                            canManageInventoryCheck: true,
                            canViewReports: true,
                            canManageSettings: false,
                            canApproveAudits: false,
                          };
                          setEditingUser({
                            ...editingUser,
                            role: 'medic',
                            permissions: defaultMedicPerms,
                          });
                        }}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="font-bold text-emerald-950 text-xs">Nhân Viên Y Tế</span>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-snug">
                      Khám sơ cứu học sinh, cấp phát thuốc theo liều, quản lý tủ thuốc & FEFO.
                    </p>
                  </label>
                </div>

                {/* Status Toggle */}
                <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <div>
                    <p className="font-bold text-slate-800">Trạng thái tài khoản</p>
                    <p className="text-[11px] text-slate-500">
                      Tài khoản bị khóa sẽ không thể truy cập hoặc thao tác trên hệ thống
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingUser({
                        ...editingUser,
                        status: (editingUser.status || 'active') === 'active' ? 'inactive' : 'active',
                      })
                    }
                    className={`px-3 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all ${
                      (editingUser.status || 'active') === 'active'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-rose-600 text-white'
                    }`}
                  >
                    {(editingUser.status || 'active') === 'active' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Đang hoạt động</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        <span>Đang tạm khóa</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* 3. Granular Permissions Checklist */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                  <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                    <span>3. Phân quyền chi tiết (Có thể chỉnh sửa theo yêu cầu)</span>
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      const r = editingUser.role;
                      const defaultP: UserPermission = {
                        canManageMedicine: true,
                        canManageTransactions: true,
                        canManageClinicVisits: true,
                        canManageStudents: true,
                        canManageInventoryCheck: true,
                        canViewReports: true,
                        canManageSettings: r === 'admin',
                        canApproveAudits: r === 'bgh' || r === 'admin',
                      };
                      setEditingUser({ ...editingUser, permissions: defaultP });
                    }}
                    className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold"
                  >
                    Khôi phục chuẩn nhóm {getRoleLabel(editingUser.role)}
                  </button>
                </div>

                <div className="space-y-2 border border-slate-200 rounded-xl p-3 bg-slate-50/50">
                  {PERMISSION_CONFIG.map((perm) => {
                    const currentPerms = editingUser.permissions || {
                      canManageMedicine: true,
                      canManageTransactions: true,
                      canManageClinicVisits: true,
                      canManageStudents: true,
                      canManageInventoryCheck: true,
                      canViewReports: true,
                      canManageSettings: editingUser.role === 'admin',
                      canApproveAudits: editingUser.role === 'bgh' || editingUser.role === 'admin',
                    };
                    const isChecked = !!currentPerms[perm.key];

                    return (
                      <label
                        key={perm.key}
                        className="flex items-start gap-3 p-2.5 rounded-lg bg-white border border-slate-200 hover:border-indigo-200 transition-colors cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            setEditingUser({
                              ...editingUser,
                              permissions: {
                                ...currentPerms,
                                [perm.key]: e.target.checked,
                              },
                            });
                          }}
                          className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                        />
                        <div className="flex-1">
                          <p className="font-bold text-slate-900 text-xs">{perm.label}</p>
                          <p className="text-[11px] text-slate-500 mt-0.5">{perm.description}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  <span>Lưu Thay Đổi Phân Quyền</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: THÊM CÁN BỘ / NGƯỜI DÙNG MỚI ================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                  <UserPlus className="w-5 h-5 text-indigo-300" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Thêm Cán Bộ / Người Dùng Mới</h3>
                  <p className="text-xs text-slate-300">Khởi tạo tài khoản và chỉ định 1 trong 3 nhóm vai trò</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateNewUser} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Họ và tên cán bộ <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Nguyễn Văn A"
                  value={newUserForm.fullName}
                  onChange={(e) => setNewUserForm({ ...newUserForm, fullName: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Tên đăng nhập / Mã <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="nguyenvana"
                    value={newUserForm.username}
                    onChange={(e) => setNewUserForm({ ...newUserForm, username: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Số điện thoại</label>
                  <input
                    type="tel"
                    placeholder="0908 xxx xxx"
                    value={newUserForm.phone}
                    onChange={(e) => setNewUserForm({ ...newUserForm, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Email</label>
                <input
                  type="email"
                  placeholder="cbnv@thcsdongthanh.edu.vn"
                  value={newUserForm.email}
                  onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Chức vụ</label>
                  <input
                    type="text"
                    value={newUserForm.title}
                    onChange={(e) => setNewUserForm({ ...newUserForm, title: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Phòng ban</label>
                  <input
                    type="text"
                    value={newUserForm.department}
                    onChange={(e) => setNewUserForm({ ...newUserForm, department: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>

              {/* 3 Role Selection */}
              <div>
                <label className="block text-slate-700 font-semibold mb-2">Chỉ định nhóm vai trò</label>
                <div className="grid grid-cols-3 gap-2">
                  <label
                    className={`p-2.5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between gap-1 text-center ${
                      newUserForm.role === 'bgh'
                        ? 'border-purple-500 bg-purple-50/70'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="new-role"
                      checked={newUserForm.role === 'bgh'}
                      onChange={() => setNewUserForm({ ...newUserForm, role: 'bgh', title: 'Phó Hiệu Trưởng' })}
                      className="text-purple-600 focus:ring-purple-500 mx-auto"
                    />
                    <span className="font-bold text-slate-900 block text-xs">Ban Giám Hiệu</span>
                    <span className="text-[10px] text-purple-700 font-medium">Giám sát & Duyệt</span>
                  </label>

                  <label
                    className={`p-2.5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between gap-1 text-center ${
                      newUserForm.role === 'admin'
                        ? 'border-indigo-500 bg-indigo-50/70'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="new-role"
                      checked={newUserForm.role === 'admin'}
                      onChange={() => setNewUserForm({ ...newUserForm, role: 'admin', title: 'Quản trị viên CNTT' })}
                      className="text-indigo-600 focus:ring-indigo-500 mx-auto"
                    />
                    <span className="font-bold text-slate-900 block text-xs">Quản Trị Viên</span>
                    <span className="text-[10px] text-indigo-700 font-medium">Cấu hình & IT</span>
                  </label>

                  <label
                    className={`p-2.5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between gap-1 text-center ${
                      newUserForm.role === 'medic'
                        ? 'border-emerald-500 bg-emerald-50/70'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="new-role"
                      checked={newUserForm.role === 'medic'}
                      onChange={() => setNewUserForm({ ...newUserForm, role: 'medic', title: 'Nhân viên Y tế' })}
                      className="text-emerald-600 focus:ring-emerald-500 mx-auto"
                    />
                    <span className="font-bold text-slate-900 block text-xs">Nhân Viên Y Tế</span>
                    <span className="text-[10px] text-emerald-700 font-medium">Khám & Kho Dược</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  <span>Tạo Tài Khoản & Phân Quyền</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: XÁC NHẬN CHUYỂN VAI TRÒ NHANH ================= */}
      {confirmRoleChange && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                  confirmRoleChange.newRole === 'bgh'
                    ? 'bg-purple-100 text-purple-700'
                    : confirmRoleChange.newRole === 'admin'
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'bg-emerald-100 text-emerald-700'
                }`}
              >
                {confirmRoleChange.newRole === 'bgh' ? (
                  <GraduationCap className="w-6 h-6" />
                ) : confirmRoleChange.newRole === 'admin' ? (
                  <ShieldCheck className="w-6 h-6" />
                ) : (
                  <Stethoscope className="w-6 h-6" />
                )}
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900">Xác Nhận Đổi Nhóm Vai Trò</h3>
                <p className="text-xs text-slate-500">Cán bộ: {confirmRoleChange.user.fullName}</p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
              <div className="flex items-center justify-between text-slate-700">
                <span>Vai trò hiện tại:</span>
                <span className="font-bold">{getRoleLabel(confirmRoleChange.user.role)}</span>
              </div>
              <div className="flex items-center justify-between text-indigo-700">
                <span>Vai trò mới sau chuyển:</span>
                <span className="font-bold text-indigo-900">{getRoleLabel(confirmRoleChange.newRole)}</span>
              </div>
              <p className="text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                {confirmRoleChange.newRole === 'bgh'
                  ? '• Cán bộ này sẽ được cấp quyền Giám sát y tế toàn trường và quyền phê duyệt biên bản kiểm kê, xuất hủy thuốc.'
                  : confirmRoleChange.newRole === 'admin'
                  ? '• Cán bộ này sẽ có toàn quyền quản trị tài khoản, cấu hình hệ thống và kiểm tra nhật ký kiểm toán.'
                  : '• Cán bộ này sẽ tập trung vào chuyên môn phòng y tế học đường (khám sơ cứu, cấp phát thuốc, quản lý tủ thuốc).'}
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setConfirmRoleChange(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleExecuteRoleChange}
                disabled={loading}
                className={`px-5 py-2 text-xs font-bold text-white rounded-xl shadow-xs transition-colors flex items-center gap-1.5 ${
                  confirmRoleChange.newRole === 'bgh'
                    ? 'bg-purple-600 hover:bg-purple-700'
                    : confirmRoleChange.newRole === 'admin'
                    ? 'bg-indigo-600 hover:bg-indigo-700'
                    : 'bg-emerald-600 hover:bg-emerald-700'
                }`}
              >
                {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                <span>Xác Nhận Đổi Nhóm</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: XÁC NHẬN XÓA TÀI KHOẢN ================= */}
      {confirmDeleteUser && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900">Xóa Tài Khoản Cán Bộ</h3>
                <p className="text-xs text-slate-500">Thao tác này sẽ ghi nhận vào nhật ký kiểm toán</p>
              </div>
            </div>

            <p className="text-xs text-slate-600">
              Bạn có chắc chắn muốn xóa tài khoản <strong>"{confirmDeleteUser.fullName}"</strong> (
              {confirmDeleteUser.email || confirmDeleteUser.username}) khỏi hệ thống?
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setConfirmDeleteUser(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleExecuteDeleteUser}
                className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition-colors"
              >
                Xóa Tài Khoản
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
