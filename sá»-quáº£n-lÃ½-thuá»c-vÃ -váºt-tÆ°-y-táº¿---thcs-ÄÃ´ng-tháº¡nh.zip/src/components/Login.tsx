import React, { useState } from 'react';
import { Stethoscope, LogIn, AlertTriangle, ShieldCheck, GraduationCap, Users } from 'lucide-react';
import { loginWithGoogle } from '../services/firebase';
import { db } from '../services/db';
import { UserRole } from '../types';

interface LoginProps {
  onLoginSuccess: (user: any) => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const userData = await loginWithGoogle();
      localStorage.setItem('school_health_auth_session', 'true');
      onLoginSuccess(userData);
    } catch (err: any) {
      console.error(err);
      setError('Đăng nhập Google không khả dụng trong khung xem trước. Quý Thầy/Cô có thể bấm vào một trong các vai trò trải nghiệm nhanh bên dưới.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = (role: UserRole) => {
    try {
      db.switchCurrentUserRole(role);
      const user = db.getCurrentUser();
      localStorage.setItem('school_health_auth_session', 'true');
      onLoginSuccess(user);
    } catch (err: any) {
      setError(err.message || 'Lỗi đăng nhập nhanh');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-6 sm:p-8 border border-slate-100">
        <div className="flex flex-col items-center justify-center text-center space-y-3 mb-6">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center shadow-inner ring-4 ring-emerald-50">
            <Stethoscope className="w-8 h-8" />
          </div>
          <div>
            <div className="inline-block px-3 py-1 bg-emerald-50 text-emerald-800 rounded-full text-xs font-bold border border-emerald-200 mb-1">
              TRƯỜNG THCS ĐÔNG THẠNH
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">Sổ Quản Lý Y Tế Học Đường</h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">Khám sơ cứu • Quản lý kho dược FEFO • Báo cáo chuẩn Bộ</p>
          </div>
        </div>

        {error && (
          <div className="mb-5 p-3.5 bg-amber-50 text-amber-900 rounded-xl flex items-start gap-2.5 border border-amber-200 text-xs">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
            <span className="font-medium leading-relaxed">{error}</span>
          </div>
        )}

        <button
          type="button"
          onClick={handleLogin}
          disabled={loading}
          className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-white text-slate-700 font-bold rounded-xl border border-slate-200 hover:bg-slate-50 hover:border-slate-300 transition-all shadow-xs disabled:opacity-50 text-sm"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin"></div>
          ) : (
            <>
              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              <span>Đăng nhập tài khoản Google</span>
            </>
          )}
        </button>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white px-3 text-slate-400 font-bold tracking-wider">
              Hoặc chọn vai trò thử nghiệm nhanh
            </span>
          </div>
        </div>

        {/* Quick Demo Login Roles */}
        <div className="space-y-2.5">
          {/* Medic */}
          <button
            type="button"
            onClick={() => handleQuickDemoLogin('medic')}
            className="w-full flex items-center gap-3 p-3 rounded-xl border border-emerald-200 bg-emerald-50/70 hover:bg-emerald-100/80 transition-all text-left group shadow-2xs"
          >
            <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-emerald-950">1. Cán Bộ Y Tế Học Đường</span>
                <span className="text-[10px] bg-emerald-200 text-emerald-800 font-bold px-1.5 py-0.5 rounded">Thao tác</span>
              </div>
              <p className="text-[11px] text-emerald-800 truncate">Khám sơ cứu học sinh, cấp thuốc theo liều, kho dược FEFO</p>
            </div>
          </button>

          {/* BGH */}
          <button
            type="button"
            onClick={() => handleQuickDemoLogin('bgh')}
            className="w-full flex items-center gap-3 p-3 rounded-xl border border-purple-200 bg-purple-50/70 hover:bg-purple-100/80 transition-all text-left group shadow-2xs"
          >
            <div className="w-9 h-9 rounded-lg bg-purple-600 text-white flex items-center justify-center shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-purple-950">2. Ban Giám Hiệu (BGH)</span>
                <span className="text-[10px] bg-purple-200 text-purple-800 font-bold px-1.5 py-0.5 rounded">Giám sát</span>
              </div>
              <p className="text-[11px] text-purple-800 truncate">Giám sát toàn trường, phê duyệt kiểm kê & xuất hủy thuốc</p>
            </div>
          </button>

          {/* Admin */}
          <button
            type="button"
            onClick={() => handleQuickDemoLogin('admin')}
            className="w-full flex items-center gap-3 p-3 rounded-xl border border-indigo-200 bg-indigo-50/70 hover:bg-indigo-100/80 transition-all text-left group shadow-2xs"
          >
            <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-indigo-950">3. Quản Trị Viên (Admin)</span>
                <span className="text-[10px] bg-indigo-200 text-indigo-800 font-bold px-1.5 py-0.5 rounded">Toàn quyền</span>
              </div>
              <p className="text-[11px] text-indigo-800 truncate">Phân quyền RBAC, sao lưu/khôi phục và audit log</p>
            </div>
          </button>
        </div>

        <p className="text-center text-[11px] text-slate-400 mt-6 leading-normal">
          Hệ thống bảo mật cục bộ kết hợp đồng bộ đám mây Firebase. Dành cho công tác y tế trường THCS Đông Thạnh.
        </p>
      </div>
    </div>
  );
};
