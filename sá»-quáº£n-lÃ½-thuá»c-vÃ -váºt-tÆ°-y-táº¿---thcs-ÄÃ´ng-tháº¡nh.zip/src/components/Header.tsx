import React, { useState, useRef, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  Building2,
  Plus,
  ArrowDownLeft,
  ArrowUpRight,
  Printer,
  Sparkles,
  Menu,
  LogOut,
  GraduationCap,
  Stethoscope,
  ChevronDown,
} from 'lucide-react';
import { User, UserRole } from '../types';
import { db, getRoleLabel } from '../services/db';
import { logout } from '../services/firebase';

interface HeaderProps {
  currentUser?: User;
  onRoleSwitch?: (role: UserRole) => void;
  onQuickAction?: (action: 'add_medicine' | 'import' | 'export' | 'stock' | 'print') => void;
  isSidebarOpen?: boolean;
  setIsSidebarOpen?: (open: boolean | ((prev: boolean) => boolean)) => void;
  onToggleSidebar?: () => void;
  onOpenAddMedicine?: () => void;
  onOpenImport?: () => void;
  onOpenExport?: () => void;
  schoolName?: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser: propUser,
  onRoleSwitch: propRoleSwitch,
  onQuickAction: propQuickAction,
  isSidebarOpen,
  setIsSidebarOpen,
  onToggleSidebar,
  onOpenAddMedicine,
  onOpenImport,
  onOpenExport,
  schoolName: propSchoolName,
}) => {
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const roleMenuRef = useRef<HTMLDivElement>(null);

  const currentUser: User = propUser || db.getCurrentUser() || {
    id: 'usr-medic',
    username: 'yte_maitrang',
    fullName: 'Đỗ Thị Mai Trang',
    role: 'medic',
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (roleMenuRef.current && !roleMenuRef.current.contains(event.target as Node)) {
        setRoleMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleToggleSidebar = () => {
    if (onToggleSidebar) {
      onToggleSidebar();
    } else if (setIsSidebarOpen) {
      setIsSidebarOpen((prev) => !prev);
    }
  };

  const handleRoleSwitch = (role: UserRole) => {
    if (propRoleSwitch) {
      propRoleSwitch(role);
    } else {
      db.setCurrentUserRole(role);
    }
    setRoleMenuOpen(false);
  };

  const handleQuickAction = (action: 'add_medicine' | 'import' | 'export' | 'stock' | 'print') => {
    if (propQuickAction) {
      propQuickAction(action);
    } else if (action === 'add_medicine' && onOpenAddMedicine) {
      onOpenAddMedicine();
    } else if (action === 'import' && onOpenImport) {
      onOpenImport();
    } else if (action === 'export' && onOpenExport) {
      onOpenExport();
    }
  };

  const schoolName = propSchoolName || db.getSettings()?.schoolName || 'TRƯỜNG THCS ĐÔNG THẠNH';

  const getRoleIcon = (role?: UserRole) => {
    switch (role) {
      case 'bgh':
        return <GraduationCap className="w-4 h-4 text-purple-700" />;
      case 'admin':
        return <ShieldCheck className="w-4 h-4 text-indigo-700" />;
      case 'medic':
      default:
        return <Stethoscope className="w-4 h-4 text-emerald-700" />;
    }
  };

  const getRoleBadgeClasses = (role?: UserRole) => {
    switch (role) {
      case 'bgh':
        return 'bg-purple-100 text-purple-900 border-purple-300 hover:bg-purple-200';
      case 'admin':
        return 'bg-indigo-100 text-indigo-900 border-indigo-300 hover:bg-indigo-200';
      case 'medic':
      default:
        return 'bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200';
    }
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* Demo Banner */}
      <div className="bg-amber-50 border-b border-amber-200 px-4 py-1.5 text-xs text-amber-900 flex items-center justify-between">
        <div className="flex items-center gap-2 font-medium">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-200 text-amber-900">
            DỮ LIỆU DEMO
          </span>
          <span>
            Hệ thống đang hiển thị dữ liệu mẫu phục vụ kiểm tra & đánh giá nghiệp vụ Y tế học đường.
          </span>
        </div>
        <span className="hidden md:inline-block text-amber-700 font-normal">
          Phòng Y tế Trường THCS Đông Thạnh • Niên khóa 2026 - 2027
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand & School info */}
          <div className="flex items-center gap-3">
            <button
              id="btn-toggle-sidebar"
              type="button"
              onClick={handleToggleSidebar}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              title="Mở thanh điều hướng"
            >
              <Menu className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                  {schoolName}
                </h1>
                <p className="text-base sm:text-lg font-extrabold text-slate-900 leading-tight">
                  SỔ QUẢN LÝ THUỐC VÀ VẬT TƯ Y TẾ
                </p>
              </div>
            </div>
          </div>

          {/* Quick Actions & Role switch */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Action Buttons */}
            <div className="hidden sm:flex items-center gap-2">
              <button
                id="btn-quick-add-medicine"
                type="button"
                onClick={() => handleQuickAction('add_medicine')}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>+ Thêm thuốc</span>
              </button>

              <button
                id="btn-quick-import"
                type="button"
                onClick={() => handleQuickAction('import')}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 transition-colors"
              >
                <ArrowDownLeft className="w-4 h-4" />
                <span>Nhập thuốc</span>
              </button>

              <button
                id="btn-quick-export"
                type="button"
                onClick={() => handleQuickAction('export')}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-teal-600 text-white hover:bg-teal-700 shadow-xs transition-colors"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>Xuất thuốc</span>
              </button>
            </div>

            {/* Role indicator with 3-role Quick Switch Dropdown */}
            <div className="relative" ref={roleMenuRef}>
              <button
                type="button"
                onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all shadow-2xs ${getRoleBadgeClasses(
                  currentUser?.role
                )}`}
                title="Nhấn để đổi vai trò kiểm tra giữa 3 nhóm: Ban Giám Hiệu, Quản Trị Viên, Nhân Viên Y Tế"
              >
                {getRoleIcon(currentUser?.role)}
                <div className="text-left">
                  <span className="block text-[10px] uppercase tracking-wider font-extrabold opacity-80">
                    {getRoleLabel(currentUser?.role || 'medic')}
                  </span>
                  <span className="hidden sm:inline font-semibold text-slate-900 truncate max-w-[130px]">
                    {currentUser?.fullName?.split('(')[0]?.trim() || 'Người dùng'}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 opacity-70 ml-0.5" />
              </button>

              {/* 3-Tier Role Menu */}
              {roleMenuOpen && (
                <div className="absolute right-0 mt-1.5 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="font-bold text-slate-900 text-xs">Chuyển Đổi Nhóm Vai Trò</p>
                    <p className="text-[11px] text-slate-500">Thử nghiệm 3 nhóm phân quyền chuẩn:</p>
                  </div>

                  {/* 1. BGH */}
                  <button
                    type="button"
                    onClick={() => handleRoleSwitch('bgh')}
                    className={`w-full flex items-start gap-2.5 p-2 rounded-xl transition-colors text-left ${
                      currentUser?.role === 'bgh'
                        ? 'bg-purple-50 text-purple-950 font-bold border border-purple-200'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 mt-0.5">
                      <GraduationCap className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-xs block text-purple-900">1. Ban Giám Hiệu (BGH)</span>
                      <span className="text-[10px] text-slate-500 block leading-tight">
                        Giám sát toàn trường, phê duyệt kiểm kê & xuất hủy thuốc
                      </span>
                    </div>
                  </button>

                  {/* 2. Admin */}
                  <button
                    type="button"
                    onClick={() => handleRoleSwitch('admin')}
                    className={`w-full flex items-start gap-2.5 p-2 rounded-xl transition-colors text-left ${
                      currentUser?.role === 'admin'
                        ? 'bg-indigo-50 text-indigo-950 font-bold border border-indigo-200'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 mt-0.5">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-xs block text-indigo-900">2. Quản Trị Viên (Admin)</span>
                      <span className="text-[10px] text-slate-500 block leading-tight">
                        Quản lý tài khoản, ma trận phân quyền, cấu hình & sao lưu
                      </span>
                    </div>
                  </button>

                  {/* 3. Medic */}
                  <button
                    type="button"
                    onClick={() => handleRoleSwitch('medic')}
                    className={`w-full flex items-start gap-2.5 p-2 rounded-xl transition-colors text-left ${
                      currentUser?.role === 'medic'
                        ? 'bg-emerald-50 text-emerald-950 font-bold border border-emerald-200'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                      <Stethoscope className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-xs block text-emerald-900">3. Nhân Viên Y Tế (Medic)</span>
                      <span className="text-[10px] text-slate-500 block leading-tight">
                        Khám sơ cứu học sinh, cấp thuốc theo liều, kho dược FEFO
                      </span>
                    </div>
                  </button>
                </div>
              )}
            </div>
            
            <button
              onClick={() => logout()}
              className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors border border-transparent hover:border-rose-100"
              title="Đăng xuất"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
