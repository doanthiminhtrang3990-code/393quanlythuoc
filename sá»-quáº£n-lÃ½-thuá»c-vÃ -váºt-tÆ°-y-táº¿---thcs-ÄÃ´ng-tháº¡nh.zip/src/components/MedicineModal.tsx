import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { Medicine } from '../types';

interface MedicineModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicineToEdit?: Medicine | null;
  onSuccess: (message: string) => void;
}

export const MedicineModal: React.FC<MedicineModalProps> = ({
  isOpen,
  onClose,
  medicineToEdit,
  onSuccess,
}) => {
  const suppliers = db.getSuppliers();

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [activeIngredient, setActiveIngredient] = useState('');
  const [dosageForm, setDosageForm] = useState('Viên nén');
  const [strength, setStrength] = useState('500mg');
  const [unit, setUnit] = useState('Viên');
  const [packing, setPacking] = useState('Hộp 10 vỉ x 10 viên');
  const [manufacturer, setManufacturer] = useState('');
  const [country, setCountry] = useState('Việt Nam');
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || 'sup-01');
  const [minStock, setMinStock] = useState<number>(20);
  const [unitPrice, setUnitPrice] = useState<number>(1000);
  const [storageLocation, setStorageLocation] = useState('Tủ A - Ngăn 1');
  const [notes, setNotes] = useState('');

  // Initial batch fields (for adding brand new medicine)
  const [createInitialBatch, setCreateInitialBatch] = useState(false);
  const [initialBatchNumber, setInitialBatchNumber] = useState('');
  const [initialMfgDate, setInitialMfgDate] = useState('2025-01-01');
  const [initialExpDate, setInitialExpDate] = useState('2027-12-31');
  const [initialQuantity, setInitialQuantity] = useState<number>(100);

  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (medicineToEdit) {
      setCode(medicineToEdit.code);
      setName(medicineToEdit.name);
      setActiveIngredient(medicineToEdit.activeIngredient);
      setDosageForm(medicineToEdit.dosageForm);
      setStrength(medicineToEdit.strength);
      setUnit(medicineToEdit.unit);
      setPacking(medicineToEdit.packing);
      setManufacturer(medicineToEdit.manufacturer || '');
      setCountry(medicineToEdit.country || 'Việt Nam');
      setSupplierId(medicineToEdit.supplierId || suppliers[0]?.id || '');
      setMinStock(medicineToEdit.minStock);
      setUnitPrice(medicineToEdit.unitPrice);
      setStorageLocation(medicineToEdit.storageLocation);
      setNotes(medicineToEdit.notes || '');
      setCreateInitialBatch(false);
    } else {
      // Auto-generate code
      const randNum = Math.floor(1000 + Math.random() * 9000);
      setCode(`TH-${randNum}`);
      setName('');
      setActiveIngredient('');
      setDosageForm('Viên nén');
      setStrength('500mg');
      setUnit('Viên');
      setPacking('Hộp 10 vỉ x 10 viên');
      setManufacturer('Dược phẩm Việt Nam');
      setCountry('Việt Nam');
      setSupplierId(suppliers[0]?.id || 'sup-01');
      setMinStock(20);
      setUnitPrice(1500);
      setStorageLocation('Tủ A - Ngăn 1');
      setNotes('');
      setCreateInitialBatch(true);
      setInitialBatchNumber(`LO-${new Date().getFullYear()}-01`);
      setInitialMfgDate(new Date().toISOString().split('T')[0]);
      const future = new Date();
      future.setFullYear(future.getFullYear() + 2);
      setInitialExpDate(future.toISOString().split('T')[0]);
      setInitialQuantity(50);
    }
    setError(null);
  }, [medicineToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!code.trim()) {
      setError('Mã thuốc không được để trống.');
      return;
    }
    if (!name.trim()) {
      setError('Tên thuốc không được để trống.');
      return;
    }
    if (!activeIngredient.trim()) {
      setError('Hoạt chất của thuốc không được để trống.');
      return;
    }
    if (minStock < 0) {
      setError('Mức tồn tối thiểu không được là số âm.');
      return;
    }
    if (unitPrice < 0) {
      setError('Đơn giá không được là số âm.');
      return;
    }

    if (!medicineToEdit && createInitialBatch) {
      if (!initialBatchNumber.trim()) {
        setError('Số lô ban đầu không được để trống.');
        return;
      }
      if (initialQuantity <= 0) {
        setError('Số lượng lô ban đầu phải lớn hơn 0.');
        return;
      }
      if (new Date(initialExpDate) <= new Date(initialMfgDate)) {
        setError('Hạn sử dụng phải sau ngày sản xuất.');
        return;
      }
    }

    try {
      if (medicineToEdit) {
        db.updateMedicine(medicineToEdit.id, {
          code: code.trim().toUpperCase(),
          name: name.trim(),
          activeIngredient: activeIngredient.trim(),
          dosageForm,
          strength,
          unit,
          packing,
          manufacturer,
          country,
          supplierId,
          minStock: Number(minStock),
          unitPrice: Number(unitPrice),
          storageLocation,
          notes,
        });
        onSuccess(`Đã cập nhật thông tin thuốc "${name}" thành công.`);
      } else {
        db.addMedicine(
          {
            code: code.trim().toUpperCase(),
            name: name.trim(),
            activeIngredient: activeIngredient.trim(),
            dosageForm,
            strength,
            unit,
            packing,
            manufacturer,
            country,
            supplierId,
            minStock: Number(minStock),
            unitPrice: Number(unitPrice),
            storageLocation,
            notes,
            isDemo: false,
          },
          createInitialBatch
            ? {
                batchNumber: initialBatchNumber.trim().toUpperCase(),
                mfgDate: initialMfgDate,
                expDate: initialExpDate,
                quantity: Number(initialQuantity),
                unitPrice: Number(unitPrice),
              }
            : undefined
        );
        onSuccess(`Đã thêm mới thuốc "${name}" vào danh mục thành công.`);
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Lỗi lưu thông tin thuốc.');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-black text-slate-900">
              {medicineToEdit ? 'SỬA THÔNG TIN THUỐC' : '+ THÊM THUỐC MỚI VÀO DANH MỤC'}
            </h3>
            <p className="text-xs text-slate-500">
              Cán bộ y tế phụ trách nhập đầy đủ thông số dược học theo quy định
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 text-sm font-bold px-2 py-1"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto flex-1 space-y-4 text-xs">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 font-medium">
              ⚠️ {error}
            </div>
          )}

          {/* Row 1: Code & Name */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Mã thuốc <span className="text-rose-600">*</span>
              </label>
              <input
                id="input-med-code"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="VD: TH-PARA500"
                required
                className="w-full p-2 rounded-xl border border-slate-200 font-mono font-bold focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1">
                Tên thuốc biệt dược <span className="text-rose-600">*</span>
              </label>
              <input
                id="input-med-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="VD: Paracetamol 500mg (Hapacol)"
                required
                className="w-full p-2 rounded-xl border border-slate-200 font-bold focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Row 2: Active ingredient & Strength */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Hoạt chất chính <span className="text-rose-600">*</span>
              </label>
              <input
                id="input-med-active"
                type="text"
                value={activeIngredient}
                onChange={(e) => setActiveIngredient(e.target.value)}
                placeholder="VD: Paracetamol"
                required
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Hàm lượng / Nồng độ</label>
              <input
                id="input-med-strength"
                type="text"
                value={strength}
                onChange={(e) => setStrength(e.target.value)}
                placeholder="VD: 500mg hoặc 10%"
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Row 3: Dosage form, Unit, Packing */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Dạng bào chế</label>
              <select
                id="input-med-form"
                value={dosageForm}
                onChange={(e) => setDosageForm(e.target.value)}
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="Viên nén">Viên nén</option>
                <option value="Viên nén bao phim">Viên nén bao phim</option>
                <option value="Viên nang mềm">Viên nang mềm</option>
                <option value="Viên sủi bọt">Viên sủi bọt</option>
                <option value="Bột pha dung dịch">Bột pha dung dịch</option>
                <option value="Dung dịch sát khuẩn">Dung dịch sát khuẩn</option>
                <option value="Dung dịch nhỏ mắt mũi">Dung dịch nhỏ mắt mũi</option>
                <option value="Siro thuốc">Siro thuốc</option>
                <option value="Dầu xoa ngoài da">Dầu xoa ngoài da</option>
                <option value="Dạng khác">Dạng khác</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Đơn vị tính <span className="text-rose-600">*</span>
              </label>
              <input
                id="input-med-unit"
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="Viên, Gói, Chai, Lọ, Tuýp..."
                required
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Quy cách đóng gói</label>
              <input
                id="input-med-packing"
                type="text"
                value={packing}
                onChange={(e) => setPacking(e.target.value)}
                placeholder="VD: Hộp 10 vỉ x 10 viên"
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Row 4: Manufacturer & Country */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Nhà sản xuất</label>
              <input
                id="input-med-manufacturer"
                type="text"
                value={manufacturer}
                onChange={(e) => setManufacturer(e.target.value)}
                placeholder="VD: Dược Hậu Giang (DHG Pharma)"
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Nước sản xuất</label>
              <input
                id="input-med-country"
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Row 5: Min Stock, Unit Price, Storage Location */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Mức tồn tối thiểu <span className="text-amber-600">*</span>
              </label>
              <input
                id="input-med-minstock"
                type="number"
                min="0"
                value={minStock}
                onChange={(e) => setMinStock(Number(e.target.value))}
                required
                className="w-full p-2 rounded-xl border border-slate-200 font-bold focus:ring-2 focus:ring-emerald-500"
              />
              <span className="text-[10px] text-slate-400">Cảnh báo nếu tồn kho ≤ mức này</span>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Đơn giá tham khảo (VNĐ)</label>
              <input
                id="input-med-price"
                type="number"
                min="0"
                step="100"
                value={unitPrice}
                onChange={(e) => setUnitPrice(Number(e.target.value))}
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Vị trí bảo quản <span className="text-emerald-700">*</span>
              </label>
              <input
                id="input-med-location"
                type="text"
                value={storageLocation}
                onChange={(e) => setStorageLocation(e.target.value)}
                placeholder="VD: Tủ A - Ngăn 1"
                required
                className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Supplier */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">Nhà cung cấp / Nguồn thuốc</label>
            <select
              id="input-med-supplier"
              value={supplierId}
              onChange={(e) => setSupplierId(e.target.value)}
              className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          {/* Initial Batch section when creating new medicine */}
          {!medicineToEdit && (
            <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2.5">
              <label className="flex items-center gap-2 font-bold text-emerald-900 cursor-pointer">
                <input
                  type="checkbox"
                  checked={createInitialBatch}
                  onChange={(e) => setCreateInitialBatch(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                />
                <span>Tạo lô nhập kho ban đầu ngay cho thuốc này</span>
              </label>

              {createInitialBatch && (
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-1 text-xs">
                  <div>
                    <span className="block font-bold text-slate-700">Số lô *</span>
                    <input
                      type="text"
                      value={initialBatchNumber}
                      onChange={(e) => setInitialBatchNumber(e.target.value)}
                      placeholder="VD: LO-2026-01"
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-mono font-bold"
                    />
                  </div>
                  <div>
                    <span className="block font-bold text-slate-700">Ngày SX</span>
                    <input
                      type="date"
                      value={initialMfgDate}
                      onChange={(e) => setInitialMfgDate(e.target.value)}
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white"
                    />
                  </div>
                  <div>
                    <span className="block font-bold text-slate-700">Hạn sử dụng *</span>
                    <input
                      type="date"
                      value={initialExpDate}
                      onChange={(e) => setInitialExpDate(e.target.value)}
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <span className="block font-bold text-slate-700">Số lượng ({unit}) *</span>
                    <input
                      type="number"
                      min="1"
                      value={initialQuantity}
                      onChange={(e) => setInitialQuantity(Number(e.target.value))}
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-black text-emerald-800"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">Ghi chú & Chỉ định sơ cứu</label>
            <textarea
              id="input-med-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="VD: Dùng khi học sinh sốt trên 38.5 độ hoặc đau đầu nhẹ..."
              className="w-full p-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2 -mx-5 -mb-5 px-5 py-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200"
            >
              Hủy bỏ
            </button>
            <button
              id="btn-save-medicine"
              type="submit"
              className="px-5 py-2 text-xs font-bold rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs"
            >
              {medicineToEdit ? 'Cập Nhật Thay Đổi' : 'Lưu Thuốc Vào Hệ Thống'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
