import React, { useState, useMemo } from 'react';
import {
  Stethoscope,
  Search,
  AlertTriangle,
  Pill,
  BriefcaseMedical,
  Activity,
  CheckCircle2,
  Clock,
  User,
  Phone,
  ShieldAlert,
  Printer,
  Plus,
  Trash2,
  Calendar,
  Layers,
  Sparkles,
  ArrowRight,
  Info,
} from 'lucide-react';
import { db, formatDateVN } from '../services/db';
import { CLINIC_REASONS, CLINIC_TREATMENTS } from '../services/studentData';
import { Student, Medicine, MedicalSupply, ClinicVisit } from '../types';

interface ClinicReceptionProps {
  preselectedStudentId?: string;
  onSuccess?: (visit: ClinicVisit) => void;
  onNavigateToVisitsLog?: () => void;
}

export const ClinicReception: React.FC<ClinicReceptionProps> = ({
  preselectedStudentId,
  onSuccess,
  onNavigateToVisitsLog,
}) => {
  const students = db.getStudents();
  const allMedicines = db.getMedicines();
  const allSupplies = db.getSupplies();
  const currentUser = db.getCurrentUser();

  // Search & Selected Student
  const [searchStudentTerm, setSearchStudentTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(() => {
    if (preselectedStudentId) {
      return students.find((s) => s.id === preselectedStudentId) || null;
    }
    return null;
  });

  // Time & Escort
  const now = new Date();
  const currentDateStr = now.toISOString().split('T')[0];
  const currentTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  
  const [visitDate, setVisitDate] = useState(currentDateStr);
  const [timeIn, setTimeIn] = useState(currentTimeStr);
  const [timeOut, setTimeOut] = useState('');
  const [broughtBy, setBroughtBy] = useState('Tự đến');

  // Reason & Symptoms
  const [selectedReason, setSelectedReason] = useState<string>('Đau bụng');
  const [customReason, setCustomReason] = useState('');
  const [initialCondition, setInitialCondition] = useState('');

  // Vital Signs
  const [temperature, setTemperature] = useState<number | ''>(37.0);
  const [pulse, setPulse] = useState<number | ''>('');
  const [bloodPressure, setBloodPressure] = useState('');
  const [respiratoryRate, setRespiratoryRate] = useState<number | ''>('');
  const [spO2, setSpO2] = useState<number | ''>('');

  // Treatment & Performer
  const [treatment, setTreatment] = useState('Nghỉ ngơi, theo dõi');
  const [performer, setPerformer] = useState(currentUser.fullName || currentUser.name || 'Y sĩ Trần Thị Bích Thảo');

  // Medicines Dispensed state
  const [medicinesToDispense, setMedicinesToDispense] = useState<
    Array<{
      medicineId: string;
      quantity: number;
      dosageInstructions: string;
    }>
  >([]);

  // Supplies Used state
  const [suppliesToUse, setSuppliesToUse] = useState<
    Array<{
      supplyId: string;
      quantity: number;
    }>
  >([]);

  // Outcome & Parent Notification
  const [outcome, setOutcome] = useState<'Đã ổn định cho về lớp' | 'Nghỉ tại phòng y tế' | 'Bàn giao phụ huynh đón về' | 'Chuyển cơ sở y tế tuyến trên'>('Đã ổn định cho về lớp');
  const [parentNotified, setParentNotified] = useState(false);
  const [parentContactNotes, setParentContactNotes] = useState('');
  const [transferHospital, setTransferHospital] = useState('Bệnh viện Đa khoa Khu vực Hóc Môn');
  const [notes, setNotes] = useState('');

  // Status & Success state
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedVisit, setSavedVisit] = useState<ClinicVisit | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Student search filtering
  const matchingStudents = useMemo(() => {
    if (!searchStudentTerm.trim()) return [];
    const q = searchStudentTerm.toLowerCase().trim();
    return students
      .filter(
        (s) =>
          s.fullName.toLowerCase().includes(q) ||
          s.studentCode.toLowerCase().includes(q) ||
          s.className.toLowerCase().includes(q)
      )
      .slice(0, 6);
  }, [students, searchStudentTerm]);

  // Allergy Check for Selected Student against selected medicines
  const allergyWarning = useMemo(() => {
    if (!selectedStudent || !selectedStudent.allergies || selectedStudent.allergies === 'Không') return null;
    const studentAllergyText = selectedStudent.allergies.toLowerCase();

    // Check if any selected medicine matches
    for (const medItem of medicinesToDispense) {
      const med = allMedicines.find((m) => m.id === medItem.medicineId);
      if (!med) continue;
      if (
        studentAllergyText.includes(med.name.toLowerCase()) ||
        studentAllergyText.includes(med.activeIngredient.toLowerCase())
      ) {
        return `CẢNH BÁO NGUY HIỂM: Học sinh có tiền sử dị ứng với "${selectedStudent.allergies}". Thuốc "${med.name}" (${med.activeIngredient}) có nguy cơ gây sốc hoặc phản ứng dị ứng!`;
      }
    }
    return null;
  }, [selectedStudent, medicinesToDispense, allMedicines]);

  // Handle Add Medicine row
  const handleAddMedicineRow = () => {
    // Pick the first available medicine with stock > 0
    const availableMed = allMedicines.find((m) => (m.totalStock ?? m.stock ?? 0) > 0) || allMedicines[0];
    if (availableMed) {
      setMedicinesToDispense((prev) => [
        ...prev,
        {
          medicineId: availableMed.id,
          quantity: 1,
          dosageInstructions: 'Uống 1 viên sau ăn',
        },
      ]);
    }
  };

  const handleRemoveMedicineRow = (index: number) => {
    setMedicinesToDispense((prev) => prev.filter((_, i) => i !== index));
  };

  // Handle Add Supply row
  const handleAddSupplyRow = () => {
    const availableSup = allSupplies.find((s) => s.quantity > 0) || allSupplies[0];
    if (availableSup) {
      setSuppliesToUse((prev) => [
        ...prev,
        {
          supplyId: availableSup.id,
          quantity: 1,
        },
      ]);
    }
  };

  const handleRemoveSupplyRow = (index: number) => {
    setSuppliesToUse((prev) => prev.filter((_, i) => i !== index));
  };

  // Form Submission
  const handleSubmitVisit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!selectedStudent) {
      setErrorMessage('Vui lòng chọn học sinh tiếp nhận.');
      return;
    }

    if (allergyWarning) {
      const confirmAllergy = window.confirm(
        `${allergyWarning}\n\nBạn có chắc chắn muốn tiếp tục xuất thuốc này không? Hãy kiểm tra thật kỹ trước khi xác nhận!`
      );
      if (!confirmAllergy) return;
    }

    setIsSubmitting(true);
    try {
      const fullDateTime = `${visitDate}T${timeIn}:00`;
      const finalReason = selectedReason === 'Khác' && customReason ? customReason : selectedReason;
      const isTransfer = outcome === 'Chuyển cơ sở y tế tuyến trên' || outcome === 'Chuyển viện';

      const newVisit = db.addClinicVisit({
        studentId: selectedStudent.id,
        studentCode: selectedStudent.studentCode,
        studentName: selectedStudent.fullName,
        className: selectedStudent.className,
        visitDate,
        timeIn,
        dateTime: fullDateTime,
        broughtBy,
        reasons: [finalReason],
        customReason: selectedReason === 'Khác' ? customReason : undefined,
        initialCondition: initialCondition || 'Học sinh báo mệt mỏi, khó chịu',
        vitals: {
          temperature: temperature !== '' ? Number(temperature) : undefined,
          pulse: pulse !== '' ? Number(pulse) : undefined,
          bloodPressure: bloodPressure || undefined,
          respiratoryRate: respiratoryRate !== '' ? Number(respiratoryRate) : undefined,
          spO2: spO2 !== '' ? Number(spO2) : undefined,
        },
        treatmentType: treatment,
        treatmentDetails: treatment,
        medicinesUsed: medicinesToDispense.map((m) => {
          const medObj = allMedicines.find((x) => x.id === m.medicineId);
          return {
            medicineId: m.medicineId,
            medicineCode: medObj?.code || '',
            medicineName: medObj?.name || '',
            batchId: '',
            batchNumber: '',
            expDate: '',
            quantity: Number(m.quantity),
            unit: medObj?.unit || 'viên',
            unitPrice: medObj?.unitPrice || 0,
            dosageInstructions: m.dosageInstructions,
          };
        }),
        suppliesUsed: suppliesToUse.map((s) => {
          const supObj = allSupplies.find((x) => x.id === s.supplyId);
          return {
            supplyId: s.supplyId,
            supplyCode: supObj?.code || '',
            supplyName: supObj?.name || '',
            quantity: Number(s.quantity),
            unit: supObj?.unit || 'cái',
          };
        }),
        outcome,
        parentContacted: parentNotified,
        parentContactNotes: parentContactNotes || undefined,
        isTransferred: isTransfer,
        transferHospital: isTransfer ? transferHospital : undefined,
        performer,
        notes: notes || undefined,
      });

      setSavedVisit(newVisit);
      onSuccess?.(newVisit);
    } catch (err: any) {
      setErrorMessage(err.message || 'Lỗi khi lưu lượt khám.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Reset form for next student
  const handleResetForNext = () => {
    setSelectedStudent(null);
    setSearchStudentTerm('');
    setSelectedReason('Đau bụng');
    setCustomReason('');
    setInitialCondition('');
    setTemperature(37.0);
    setPulse('');
    setBloodPressure('');
    setRespiratoryRate('');
    setSpO2('');
    setTreatment('Nghỉ ngơi, theo dõi');
    setMedicinesToDispense([]);
    setSuppliesToUse([]);
    setOutcome('Đã ổn định cho về lớp');
    setParentNotified(false);
    setParentContactNotes('');
    setNotes('');
    setSavedVisit(null);
    setErrorMessage(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
              QUY TRÌNH 10 BƯỚC CHUẨN
            </span>
            <h1 className="text-xl font-bold text-slate-900">Tiếp Nhận Học Sinh Vào Phòng Y Tế</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Trường THCS Đông Thạnh • Tự động liên kết hồ sơ sức khỏe & Trừ kho thuốc theo nguyên tắc FEFO
          </p>
        </div>

        {onNavigateToVisitsLog && (
          <button
            onClick={onNavigateToVisitsLog}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition-colors self-start md:self-auto"
          >
            <span>Xem sổ phòng y tế</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Success Modal / Printable Card after submission */}
      {savedVisit && (
        <div className="bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-6 shadow-md space-y-4 animate-in fade-in">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-700 text-white flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-emerald-200" />
              </div>
              <div>
                <h3 className="font-bold text-emerald-900 text-base">
                  Tiếp Nhận & Xử Trí Thành Công: {savedVisit.visitCode}
                </h3>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Đã ghi nhận ca khám cho học sinh <strong>{savedVisit.studentName}</strong> (Lớp {savedVisit.className}).
                  Kho thuốc và vật tư đã được tự động cập nhật theo lô FEFO!
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold border border-emerald-300 shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>In phiếu chăm sóc (A4)</span>
              </button>
              <button
                onClick={handleResetForNext}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Tiếp nhận ca tiếp theo</span>
              </button>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-emerald-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[11px]">Lý do đến:</span>
              <span className="font-semibold text-slate-800">{savedVisit.reason}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Xử trí:</span>
              <span className="font-semibold text-slate-800">{savedVisit.treatment}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Kết quả:</span>
              <span className="font-semibold text-emerald-800">{savedVisit.outcome}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Thuốc cấp (FEFO):</span>
              <span className="font-bold text-slate-800">
                {savedVisit.medicinesDispensed && savedVisit.medicinesDispensed.length > 0
                  ? savedVisit.medicinesDispensed.map((m) => `${m.medicineName} (${m.quantity} ${m.unit})`).join(', ')
                  : 'Không cấp thuốc'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Main Intake Form */}
      <form onSubmit={handleSubmitVisit} className="space-y-6">
        {/* Error alert */}
        {errorMessage && (
          <div className="p-4 bg-rose-50 border border-rose-300 rounded-xl text-xs text-rose-800 font-medium flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* BƯỚC 1: CHỌN HỌC SINH & XEM THẺ TÓM TẮT AN TOÀN */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
                1
              </span>
              <h2 className="font-bold text-slate-900 text-sm">Chọn Học Sinh Tiếp Nhận</h2>
            </div>
            {selectedStudent && (
              <button
                type="button"
                onClick={() => setSelectedStudent(null)}
                className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold"
              >
                Đổi học sinh khác
              </button>
            )}
          </div>

          {!selectedStudent ? (
            <div className="space-y-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Gõ họ tên học sinh, mã số (VD: HS0001, An, Hưng...) hoặc lớp (6/1, 7/2)..."
                  value={searchStudentTerm}
                  onChange={(e) => setSearchStudentTerm(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
                />
              </div>

              {matchingStudents.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 border border-slate-200 p-2 rounded-xl bg-slate-50/50">
                  {matchingStudents.map((stu) => (
                    <button
                      key={stu.id}
                      type="button"
                      onClick={() => {
                        setSelectedStudent(stu);
                        setSearchStudentTerm('');
                      }}
                      className="p-2.5 text-left bg-white hover:bg-emerald-50 rounded-lg border border-slate-200 hover:border-emerald-300 transition-colors flex items-center justify-between group"
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs text-slate-900 group-hover:text-emerald-900">
                            {stu.fullName}
                          </span>
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {stu.className}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono">{stu.studentCode}</p>
                      </div>
                      {stu.specialAttention && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-700">
                          ⚠️ Cần chú ý
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-lg">
                    {selectedStudent.fullName.charAt(selectedStudent.fullName.lastIndexOf(' ') + 1) || 'H'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-slate-900 text-sm">{selectedStudent.fullName}</h3>
                      <span className="font-mono text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                        {selectedStudent.studentCode}
                      </span>
                      {selectedStudent.bloodType && (
                        <span className="text-xs font-bold text-red-700 bg-red-100 px-1.5 py-0.5 rounded">
                          Nhóm {selectedStudent.bloodType}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Lớp <strong>{selectedStudent.className}</strong> • Khối {selectedStudent.grade} • Ngày sinh:{' '}
                      {formatDateVN(selectedStudent.birthDate)} ({selectedStudent.gender})
                    </p>
                  </div>
                </div>

                <div className="text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200">
                  <p className="font-semibold text-slate-800">Phụ huynh: {selectedStudent.parentName || '—'}</p>
                  <p className="text-slate-500 font-mono">SĐT: {selectedStudent.parentPhone || '—'}</p>
                </div>
              </div>

              {/* Prominent Allergy / Chronic Alert */}
              {(selectedStudent.allergies || selectedStudent.chronicConditions) && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-900 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    {selectedStudent.allergies && selectedStudent.allergies !== 'Không' && (
                      <p>
                        <strong>Tiền sử dị ứng:</strong> <span className="font-bold text-rose-800 underline">{selectedStudent.allergies}</span>
                      </p>
                    )}
                    {selectedStudent.chronicConditions && selectedStudent.chronicConditions !== 'Không' && (
                      <p>
                        <strong>Bệnh nền:</strong> {selectedStudent.chronicConditions}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* BƯỚC 2 & 3: THỜI GIAN & NGƯỜI ĐƯA ĐẾN */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
              2
            </span>
            <h2 className="font-bold text-slate-900 text-sm">Thời Gian & Người Đưa Đến</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Ngày tiếp nhận</label>
              <input
                type="date"
                required
                value={visitDate}
                onChange={(e) => setVisitDate(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Giờ vào</label>
              <input
                type="time"
                required
                value={timeIn}
                onChange={(e) => setTimeIn(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Giờ ra (dự kiến)</label>
              <input
                type="time"
                value={timeOut}
                onChange={(e) => setTimeOut(e.target.value)}
                placeholder="Để trống nếu chưa ra"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Người đưa đến</label>
              <select
                value={broughtBy}
                onChange={(e) => setBroughtBy(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white"
              >
                <option value="Tự đến">Tự đến</option>
                <option value="Bạn cùng lớp">Bạn cùng lớp</option>
                <option value="Giáo viên bộ môn">Giáo viên bộ môn</option>
                <option value="Giáo viên chủ nhiệm">Giáo viên chủ nhiệm</option>
                <option value="Giám thị">Giám thị</option>
                <option value="Nhân viên bảo vệ">Nhân viên bảo vệ</option>
                <option value="Khác">Khác</option>
              </select>
            </div>
          </div>
        </div>

        {/* BƯỚC 4 & 5: LÝ DO ĐẾN PHÒNG Y TẾ & TRIỆU CHỨNG */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
              3
            </span>
            <h2 className="font-bold text-slate-900 text-sm">Lý Do Khám & Tình Trạng Ban Đầu</h2>
          </div>

          {/* Quick chips for reasons */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">Chọn nhanh lý do chính:</label>
            <div className="flex flex-wrap gap-1.5">
              {CLINIC_REASONS.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setSelectedReason(r)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    selectedReason === r
                      ? 'bg-emerald-700 text-white shadow-xs font-bold'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {selectedReason === 'Khác' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Ghi rõ lý do khác:</label>
              <input
                type="text"
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                placeholder="Nhập lý do cụ thể..."
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Mô tả triệu chứng & Tình trạng ban đầu <span className="text-rose-600">*</span>
            </label>
            <textarea
              required
              rows={2}
              value={initialCondition}
              onChange={(e) => setInitialCondition(e.target.value)}
              placeholder="VD: Học sinh kêu đau bụng âm ỉ vùng quanh rốn sau giờ ra chơi, buồn nôn, không sốt..."
              className="w-full text-xs border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-emerald-600"
            />
          </div>
        </div>

        {/* BƯỚC 6: DẤU HIỆU SINH TỒN */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
              4
            </span>
            <h2 className="font-bold text-slate-900 text-sm">Dấu Hiệu Sinh Tồn (Sinh Hiệu)</h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nhiệt độ (°C)</label>
              <input
                type="number"
                step="0.1"
                value={temperature}
                onChange={(e) => setTemperature(e.target.value === '' ? '' : parseFloat(e.target.value))}
                placeholder="37.0"
                className={`w-full text-xs border rounded-xl px-3 py-2 font-bold ${
                  typeof temperature === 'number' && temperature >= 38.0
                    ? 'border-rose-400 bg-rose-50 text-rose-800'
                    : 'border-slate-200'
                }`}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Mạch (lần/phút)</label>
              <input
                type="number"
                value={pulse}
                onChange={(e) => setPulse(e.target.value === '' ? '' : parseInt(e.target.value, 10))}
                placeholder="80"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Huyết áp (mmHg)</label>
              <input
                type="text"
                value={bloodPressure}
                onChange={(e) => setBloodPressure(e.target.value)}
                placeholder="100/70"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nhịp thở (lần/phút)</label>
              <input
                type="number"
                value={respiratoryRate}
                onChange={(e) => setRespiratoryRate(e.target.value === '' ? '' : parseInt(e.target.value, 10))}
                placeholder="20"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">SpO2 (%)</label>
              <input
                type="number"
                value={spO2}
                onChange={(e) => setSpO2(e.target.value === '' ? '' : parseInt(e.target.value, 10))}
                placeholder="98"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
              />
            </div>
          </div>
        </div>

        {/* BƯỚC 7: PHÂN LOẠI XỬ TRÍ */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
              5
            </span>
            <h2 className="font-bold text-slate-900 text-sm">Biện Pháp Xử Trí Chăm Sóc</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Biện pháp xử trí</label>
              <select
                value={treatment}
                onChange={(e) => setTreatment(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white font-medium"
              >
                {CLINIC_TREATMENTS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Cán bộ y tế thực hiện</label>
              <input
                type="text"
                required
                value={performer}
                onChange={(e) => setPerformer(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 font-medium"
              />
            </div>
          </div>
        </div>

        {/* BƯỚC 8: CẤP PHÁT THUỐC TỰ ĐỘNG THEO NGUYÊN TẮC FEFO */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
                6
              </span>
              <div>
                <h2 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <Pill className="w-4 h-4 text-emerald-700" />
                  <span>Cấp Phát Thuốc Điều Trị (Tự động trừ kho theo FEFO)</span>
                </h2>
                <p className="text-[11px] text-slate-500">
                  Chỉ định thuốc điều trị theo thẩm quyền y tế học đường. Tự động xuất lô có hạn dùng gần nhất trước.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAddMedicineRow}
              className="flex items-center gap-1 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold border border-emerald-200 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Thêm thuốc</span>
            </button>
          </div>

          {/* Allergy warning box if matches */}
          {allergyWarning && (
            <div className="p-3.5 bg-rose-100 border-2 border-rose-300 rounded-xl text-xs text-rose-900 font-bold flex items-start gap-2 animate-pulse">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{allergyWarning}</span>
            </div>
          )}

          {medicinesToDispense.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-2">
              Không cấp thuốc trong ca này (Học sinh chỉ cần nghỉ ngơi, theo dõi sinh hiệu hoặc chuyển tuyến).
            </p>
          ) : (
            <div className="space-y-3">
              {medicinesToDispense.map((item, idx) => {
                const med = allMedicines.find((m) => m.id === item.medicineId);
                return (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center"
                  >
                    <div className="sm:col-span-5">
                      <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">Tên thuốc</label>
                      <select
                        value={item.medicineId}
                        onChange={(e) => {
                          const newId = e.target.value;
                          setMedicinesToDispense((prev) =>
                            prev.map((row, i) => (i === idx ? { ...row, medicineId: newId } : row))
                          );
                        }}
                        className="w-full text-xs font-bold text-slate-800 border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white"
                      >
                        {allMedicines.map((m) => (
                          <option key={m.id} value={m.id}>
                            {m.name} ({m.activeIngredient}) - Tồn: {m.totalStock ?? m.stock ?? 0} {m.unit}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">
                        Số lượng ({med?.unit || 'viên'})
                      </label>
                      <input
                        type="number"
                        min="1"
                        max={med ? (med.totalStock ?? med.stock ?? 10) : 10}
                        value={item.quantity}
                        onChange={(e) => {
                          const qty = parseInt(e.target.value, 10) || 1;
                          setMedicinesToDispense((prev) =>
                            prev.map((row, i) => (i === idx ? { ...row, quantity: qty } : row))
                          );
                        }}
                        className="w-full text-xs font-bold text-center border border-slate-200 rounded-lg px-2 py-1.5 bg-white"
                      />
                    </div>

                    <div className="sm:col-span-4">
                      <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">
                        Cách dùng & Liều lượng
                      </label>
                      <input
                        type="text"
                        value={item.dosageInstructions}
                        onChange={(e) => {
                          const val = e.target.value;
                          setMedicinesToDispense((prev) =>
                            prev.map((row, i) => (i === idx ? { ...row, dosageInstructions: val } : row))
                          );
                        }}
                        placeholder="Uống 1 viên sau ăn với nước ấm"
                        className="w-full text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white"
                      />
                    </div>

                    <div className="sm:col-span-1 text-right">
                      <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">&nbsp;</label>
                      <button
                        type="button"
                        onClick={() => handleRemoveMedicineRow(idx)}
                        className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg"
                        title="Xóa thuốc này"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* BƯỚC 9: VẬT TƯ Y TẾ SỬ DỤNG */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
                7
              </span>
              <div>
                <h2 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <BriefcaseMedical className="w-4 h-4 text-blue-700" />
                  <span>Vật Tư Y Tế Sử Dụng (Trừ tồn kho vật tư)</span>
                </h2>
                <p className="text-[11px] text-slate-500">Bông băng, gạc, nước muối sinh lý, cồn sát khuẩn...</p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAddSupplyRow}
              className="flex items-center gap-1 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg text-xs font-bold border border-blue-200 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Thêm vật tư</span>
            </button>
          </div>

          {suppliesToUse.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-2">Không sử dụng vật tư tiêu hao trong ca này.</p>
          ) : (
            <div className="space-y-3">
              {suppliesToUse.map((item, idx) => {
                const sup = allSupplies.find((s) => s.id === item.supplyId);
                return (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center"
                  >
                    <div className="sm:col-span-8">
                      <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">Tên vật tư</label>
                      <select
                        value={item.supplyId}
                        onChange={(e) => {
                          const newId = e.target.value;
                          setSuppliesToUse((prev) =>
                            prev.map((row, i) => (i === idx ? { ...row, supplyId: newId } : row))
                          );
                        }}
                        className="w-full text-xs font-bold text-slate-800 border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white"
                      >
                        {allSupplies.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} ({s.category}) - Còn tồn: {s.quantity} {s.unit}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">
                        Số lượng ({sup?.unit || 'cái'})
                      </label>
                      <input
                        type="number"
                        min="1"
                        max={sup ? sup.quantity : 50}
                        value={item.quantity}
                        onChange={(e) => {
                          const qty = parseInt(e.target.value, 10) || 1;
                          setSuppliesToUse((prev) =>
                            prev.map((row, i) => (i === idx ? { ...row, quantity: qty } : row))
                          );
                        }}
                        className="w-full text-xs font-bold text-center border border-slate-200 rounded-lg px-2 py-1.5 bg-white"
                      />
                    </div>

                    <div className="sm:col-span-1 text-right">
                      <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">&nbsp;</label>
                      <button
                        type="button"
                        onClick={() => handleRemoveSupplyRow(idx)}
                        className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg"
                        title="Xóa vật tư này"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* BƯỚC 10: ĐÁNH GIÁ KẾT QUẢ & THÔNG BÁO PHỤ HUYNH */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
              8
            </span>
            <h2 className="font-bold text-slate-900 text-sm">Đánh Giá Kết Quả & Bàn Giao Học Sinh</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Kết quả sau xử trí</label>
              <select
                value={outcome}
                onChange={(e) => setOutcome(e.target.value as any)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white font-bold text-slate-800"
              >
                <option value="Đã ổn định cho về lớp">Đã ổn định cho về lớp</option>
                <option value="Nghỉ tại phòng y tế">Nghỉ tại phòng y tế tiếp tục theo dõi</option>
                <option value="Bàn giao phụ huynh đón về">Bàn giao phụ huynh đón về</option>
                <option value="Chuyển cơ sở y tế tuyến trên">Chuyển cơ sở y tế tuyến trên</option>
              </select>
            </div>

            {outcome === 'Chuyển cơ sở y tế tuyến trên' && (
              <div>
                <label className="block text-xs font-semibold text-rose-800 mb-1">Cơ sở y tế chuyển đến</label>
                <input
                  type="text"
                  value={transferHospital}
                  onChange={(e) => setTransferHospital(e.target.value)}
                  className="w-full text-xs border border-rose-300 rounded-xl px-3 py-2 bg-rose-50 font-semibold text-rose-900"
                />
              </div>
            )}
          </div>

          {/* Parent notification status */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="chk-parent-notified"
                checked={parentNotified}
                onChange={(e) => setParentNotified(e.target.checked)}
                className="w-4 h-4 text-emerald-700 rounded border-slate-300 focus:ring-emerald-600"
              />
              <label htmlFor="chk-parent-notified" className="text-xs font-bold text-slate-800 cursor-pointer">
                Đã gọi điện / liên hệ thông báo cho phụ huynh học sinh
              </label>
            </div>

            {parentNotified && (
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Nội dung trao đổi với phụ huynh:
                </label>
                <input
                  type="text"
                  value={parentContactNotes}
                  onChange={(e) => setParentContactNotes(e.target.value)}
                  placeholder="VD: Phụ huynh đồng ý cho con uống 1 viên Paracetamol và sẽ đón con lúc 11h..."
                  className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white"
                />
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Ghi chú thêm của cán bộ y tế</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ghi chú thêm về diễn biến hoặc dặn dò học sinh..."
              className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2"
            />
          </div>
        </div>

        {/* Action Button: Confirm and Submit */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={handleResetForNext}
            className="px-5 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Làm mới biểu mẫu
          </button>

          <button
            type="submit"
            disabled={isSubmitting || !selectedStudent}
            className="flex items-center gap-2 px-6 py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Xác nhận & Tự động xuất kho (FEFO)</span>
          </button>
        </div>
      </form>
    </div>
  );
};
