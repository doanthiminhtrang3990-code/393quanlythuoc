import React, { useState } from 'react';
import {
  Printer,
  FileText,
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Download,
  Building2,
} from 'lucide-react';
import { db, formatDateVN, formatDateTimeVN } from '../services/db';

export const PrintA4Templates: React.FC = () => {
  const [activeTemplate, setActiveTemplate] = useState<
    'mau1_so_phong_y_te' | 'mau2_thuoc_vat_tu' | 'mau3_bao_cao_thang' | 'mau4_hoc_sinh_dac_biet'
  >('mau1_so_phong_y_te');

  const visits = db.getClinicVisits();
  const students = db.getStudents();
  const specialStudents = students.filter((s) => s.specialAttention || (s.allergies && s.allergies !== 'Không'));
  const monthlyReport = db.getMonthlyClinicReport('2026-03');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">
              MẪU IN A4 CHUẨN
            </span>
            <h1 className="text-xl font-bold text-slate-900">Mẫu Sổ Và Báo Cáo In A4 Chuẩn Y Tế Học Đường</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Trường THCS Đông Thạnh • Định dạng chuẩn quy định y tế học đường, sẵn sàng in hoặc xuất PDF
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
        >
          <Printer className="w-4 h-4" />
          <span>In mẫu này ngay (Ctrl + P)</span>
        </button>
      </div>

      {/* Template Selector Tabs */}
      <div className="flex flex-wrap gap-2 bg-white p-3 rounded-xl border border-slate-200">
        <button
          onClick={() => setActiveTemplate('mau1_so_phong_y_te')}
          className={`px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
            activeTemplate === 'mau1_so_phong_y_te'
              ? 'bg-emerald-700 text-white'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          Mẫu 1: Sổ theo dõi học sinh đến phòng y tế
        </button>

        <button
          onClick={() => setActiveTemplate('mau2_thuoc_vat_tu')}
          className={`px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
            activeTemplate === 'mau2_thuoc_vat_tu'
              ? 'bg-emerald-700 text-white'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          Mẫu 2: Sổ theo dõi thuốc & vật tư sử dụng
        </button>

        <button
          onClick={() => setActiveTemplate('mau3_bao_cao_thang')}
          className={`px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
            activeTemplate === 'mau3_bao_cao_thang'
              ? 'bg-emerald-700 text-white'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          Mẫu 3: Báo cáo công tác y tế tháng A4
        </button>

        <button
          onClick={() => setActiveTemplate('mau4_hoc_sinh_dac_biet')}
          className={`px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
            activeTemplate === 'mau4_hoc_sinh_dac_biet'
              ? 'bg-emerald-700 text-white'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          Mẫu 4: Danh sách HS cần theo dõi sức khỏe đặc biệt
        </button>
      </div>

      {/* Printable Sheet View - Styled like Real A4 Paper */}
      <div className="bg-white p-8 sm:p-12 rounded-2xl border border-slate-300 shadow-md max-w-4xl mx-auto text-slate-900 printable-sheet">
        {/* Official Header */}
        <div className="flex justify-between items-start text-xs border-b-2 border-slate-900 pb-4 mb-6">
          <div className="text-center">
            <p className="uppercase font-medium">PHÒNG GD&ĐT HUYỆN HÓC MÔN</p>
            <p className="uppercase font-bold text-sm">TRƯỜNG THCS ĐÔNG THẠNH</p>
            <p className="text-[11px] text-slate-600">Bộ phận: Phòng Y Tế Học Đường</p>
          </div>
          <div className="text-center">
            <p className="font-bold uppercase text-xs">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p>
            <p className="font-medium text-xs">Độc lập - Tự do - Hạnh phúc</p>
            <p className="text-[11px] text-slate-500 italic mt-0.5">Đông Thạnh, ngày {new Date().getDate()} tháng {new Date().getMonth() + 1} năm {new Date().getFullYear()}</p>
          </div>
        </div>

        {/* TEMPLATE 1: SỔ THEO DÕI HỌC SINH ĐẾN PHÒNG Y TẾ */}
        {activeTemplate === 'mau1_so_phong_y_te' && (
          <div className="space-y-4">
            <div className="text-center">
              <h2 className="text-base font-bold uppercase">SỔ THEO DÕI HỌC SINH ĐẾN PHÒNG Y TẾ</h2>
              <p className="text-xs italic text-slate-600">Năm học: 2026 - 2027</p>
            </div>

            <table className="w-full text-[11px] border-collapse border border-slate-900 mt-4">
              <thead>
                <tr className="bg-slate-100 text-center font-bold">
                  <th className="border border-slate-900 p-1.5 w-8">STT</th>
                  <th className="border border-slate-900 p-1.5 w-24">Thời gian</th>
                  <th className="border border-slate-900 p-1.5">Họ và tên học sinh</th>
                  <th className="border border-slate-900 p-1.5 w-12">Lớp</th>
                  <th className="border border-slate-900 p-1.5">Lý do & Sinh hiệu</th>
                  <th className="border border-slate-900 p-1.5">Xử trí & Cấp thuốc</th>
                  <th className="border border-slate-900 p-1.5 w-28">Kết quả</th>
                  <th className="border border-slate-900 p-1.5 w-20">Ký nhận</th>
                </tr>
              </thead>
              <tbody>
                {visits.map((v, idx) => {
                  const visitDateTime = v.dateTime || `${v.timeIn ? v.timeIn + ' ' : ''}${formatDateVN(v.visitDate)}`;
                  const visitReason = (v.reasons && v.reasons.length > 0 ? v.reasons.join(', ') : v.customReason) || v.reason || '';
                  const visitTemp = v.vitals?.temperature || v.temperature;
                  const visitTreatment = v.treatmentDetails || v.treatmentType || v.treatment || '';
                  const meds = v.medicinesUsed || v.medicinesDispensed || [];

                  return (
                    <tr key={v.id}>
                      <td className="border border-slate-900 p-1.5 text-center">{idx + 1}</td>
                      <td className="border border-slate-900 p-1.5 whitespace-nowrap">{visitDateTime}</td>
                      <td className="border border-slate-900 p-1.5 font-bold">
                        {v.studentName}
                        <span className="block font-mono text-[10px] text-slate-500 font-normal">{v.studentCode}</span>
                      </td>
                      <td className="border border-slate-900 p-1.5 text-center font-semibold">{v.className}</td>
                      <td className="border border-slate-900 p-1.5">
                        <strong>{visitReason}</strong>
                        {visitTemp ? ` (${visitTemp}°C)` : ''}
                      </td>
                      <td className="border border-slate-900 p-1.5">
                        {visitTreatment}
                        {meds.length > 0 && (
                          <div className="font-semibold text-emerald-900 text-[10px] mt-0.5">
                            Thuốc: {meds.map((m) => `${m.medicineName} (${m.quantity})`).join(', ')}
                          </div>
                        )}
                      </td>
                      <td className="border border-slate-900 p-1.5">{v.outcome}</td>
                      <td className="border border-slate-900 p-1.5 text-center italic">{(v.performer || 'Y sĩ').split(' ').pop() || ''}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* TEMPLATE 2: SỔ THEO DÕI THUỐC VÀ VẬT TƯ SỬ DỤNG */}
        {activeTemplate === 'mau2_thuoc_vat_tu' && (
          <div className="space-y-4">
            <div className="text-center">
              <h2 className="text-base font-bold uppercase">SỔ THEO DÕI THUỐC & VẬT TƯ Y TẾ ĐÃ SỬ DỤNG</h2>
              <p className="text-xs italic text-slate-600">Liên kết cấp phát theo lô và quy tắc FEFO</p>
            </div>

            <table className="w-full text-[11px] border-collapse border border-slate-900 mt-4">
              <thead>
                <tr className="bg-slate-100 text-center font-bold">
                  <th className="border border-slate-900 p-1.5 w-8">STT</th>
                  <th className="border border-slate-900 p-1.5 w-24">Ngày cấp</th>
                  <th className="border border-slate-900 p-1.5">Tên học sinh (Lớp)</th>
                  <th className="border border-slate-900 p-1.5">Tên thuốc / Vật tư</th>
                  <th className="border border-slate-900 p-1.5 w-16">Số lượng</th>
                  <th className="border border-slate-900 p-1.5 w-20">Số lô</th>
                  <th className="border border-slate-900 p-1.5 w-20">Hạn dùng</th>
                  <th className="border border-slate-900 p-1.5">Lý do chỉ định</th>
                </tr>
              </thead>
              <tbody>
                {visits
                  .flatMap((v) => {
                    const dateDisplay = v.dateTime || `${v.timeIn ? v.timeIn + ' ' : ''}${formatDateVN(v.visitDate)}`;
                    const rText = (v.reasons && v.reasons.length > 0 ? v.reasons.join(', ') : v.customReason) || v.reason || '';
                    const meds = v.medicinesUsed || v.medicinesDispensed || [];
                    return meds.map((m) => ({
                      date: dateDisplay,
                      student: `${v.studentName} (${v.className})`,
                      item: m.medicineName,
                      qty: `${m.quantity} ${m.unit}`,
                      batch: m.batchNumber || '—',
                      exp: m.expDate ? formatDateVN(m.expDate) : '—',
                      reason: rText,
                    }));
                  })
                  .map((row, idx) => (
                    <tr key={idx}>
                      <td className="border border-slate-900 p-1.5 text-center">{idx + 1}</td>
                      <td className="border border-slate-900 p-1.5 whitespace-nowrap">{row.date}</td>
                      <td className="border border-slate-900 p-1.5 font-bold">{row.student}</td>
                      <td className="border border-slate-900 p-1.5 font-semibold">{row.item}</td>
                      <td className="border border-slate-900 p-1.5 text-center font-bold">{row.qty}</td>
                      <td className="border border-slate-900 p-1.5 text-center font-mono">{row.batch}</td>
                      <td className="border border-slate-900 p-1.5 text-center font-mono">{row.exp}</td>
                      <td className="border border-slate-900 p-1.5">{row.reason}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}

        {/* TEMPLATE 3: BÁO CÁO THÁNG A4 */}
        {activeTemplate === 'mau3_bao_cao_thang' && (
          <div className="space-y-4">
            <div className="text-center">
              <h2 className="text-base font-bold uppercase">BÁO CÁO CÔNG TÁC Y TẾ TRƯỜNG HỌC</h2>
              <p className="text-xs italic text-slate-600">Tháng {monthlyReport.month}</p>
            </div>

            <div className="text-xs space-y-3 leading-relaxed">
              <p>
                <strong>I. TÌNH HÌNH CHUNG:</strong>
              </p>
              <p>
                - Tổng số học sinh toàn trường: <strong>{students.length}</strong> học sinh (Khối 6, 7, 8, 9).
              </p>
              <p>
                - Tổng số lượt học sinh đến phòng y tế trong tháng: <strong>{monthlyReport.totalVisits}</strong> lượt.
              </p>

              <p className="pt-2">
                <strong>II. KẾT QUẢ XỬ TRÍ BAN ĐẦU:</strong>
              </p>
              <p>- Số ca đã ổn định cho về lớp / phòng y tế: {Math.max(0, monthlyReport.totalVisits - monthlyReport.emergencyTransfersCount)} ca.</p>
              <p>- Số ca liên hệ phụ huynh bàn giao đón về nghỉ ngơi: {monthlyReport.parentContactedCount} ca.</p>
              <p>- Số ca sơ cứu chuyển cơ sở y tế tuyến trên: {monthlyReport.emergencyTransfersCount} ca.</p>
              <p>- Số sự cố tai nạn thương tích tại trường: {monthlyReport.events.length} ca.</p>

              <p className="pt-2">
                <strong>III. THUỐC VÀ VẬT TƯ TIÊU THỤ:</strong>
              </p>
              <ul className="list-disc pl-5">
                {monthlyReport.medicinesUsedSummary.map((m, i) => (
                  <li key={i}>
                    {m.medicineName} (Lô {m.batchNumber}): {m.quantity} {m.unit}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* TEMPLATE 4: DANH SÁCH HỌC SINH CẦN THEO DÕI ĐẶC BIỆT */}
        {activeTemplate === 'mau4_hoc_sinh_dac_biet' && (
          <div className="space-y-4">
            <div className="text-center">
              <h2 className="text-base font-bold uppercase">DANH SÁCH HỌC SINH CẦN THEO DÕI SỨC KHỎE ĐẶC BIỆT</h2>
              <p className="text-xs italic text-slate-600">Phục vụ công tác sơ cứu và lưu ý cho giáo viên chủ nhiệm</p>
            </div>

            <table className="w-full text-[11px] border-collapse border border-slate-900 mt-4">
              <thead>
                <tr className="bg-slate-100 text-center font-bold">
                  <th className="border border-slate-900 p-1.5 w-8">STT</th>
                  <th className="border border-slate-900 p-1.5 w-20">Mã HS</th>
                  <th className="border border-slate-900 p-1.5">Họ và tên</th>
                  <th className="border border-slate-900 p-1.5 w-12">Lớp</th>
                  <th className="border border-slate-900 p-1.5">Tiền sử dị ứng</th>
                  <th className="border border-slate-900 p-1.5">Bệnh nền mạn tính</th>
                  <th className="border border-slate-900 p-1.5">SĐT Phụ huynh</th>
                </tr>
              </thead>
              <tbody>
                {specialStudents.map((s, idx) => (
                  <tr key={s.id}>
                    <td className="border border-slate-900 p-1.5 text-center">{idx + 1}</td>
                    <td className="border border-slate-900 p-1.5 text-center font-mono">{s.studentCode}</td>
                    <td className="border border-slate-900 p-1.5 font-bold">{s.fullName}</td>
                    <td className="border border-slate-900 p-1.5 text-center font-semibold">{s.className}</td>
                    <td className="border border-slate-900 p-1.5 text-rose-800 font-bold">{s.allergies || 'Không'}</td>
                    <td className="border border-slate-900 p-1.5">{s.chronicConditions || 'Không'}</td>
                    <td className="border border-slate-900 p-1.5 font-mono">{s.parentPhone || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Signature Blocks */}
        <div className="grid grid-cols-2 text-center text-xs mt-12 pt-6 border-t border-slate-200">
          <div>
            <p className="font-bold uppercase">CÁN BỘ Y TẾ TRƯỜNG HỌC</p>
            <p className="text-slate-400 italic text-[10px] mt-0.5">(Ký và ghi rõ họ tên)</p>
            <div className="h-16" />
            <p className="font-bold">Y sĩ Trần Thị Bích Thảo</p>
          </div>
          <div>
            <p className="font-bold uppercase">HIỆU TRƯỞNG PHÊ DUYỆT</p>
            <p className="text-slate-400 italic text-[10px] mt-0.5">(Ký, đóng dấu)</p>
            <div className="h-16" />
            <p className="font-bold">Ban Giám Hiệu</p>
          </div>
        </div>
      </div>
    </div>
  );
};
