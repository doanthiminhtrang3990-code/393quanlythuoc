import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Search,
  Filter,
  Calendar,
  Download,
  Printer,
  ChevronDown,
  ChevronUp,
  Stethoscope,
  Pill,
  BriefcaseMedical,
  CheckCircle2,
  AlertTriangle,
  Phone,
  Clock,
  User,
  Trash2,
  Plus,
  FileText,
} from 'lucide-react';
import { db, formatDateVN, formatDateTimeVN } from '../services/db';
import { ClinicVisit } from '../types';

interface ClinicVisitsLogProps {
  onNavigateToIntake?: () => void;
  onSelectStudentProfile?: (studentId: string) => void;
}

export const ClinicVisitsLog: React.FC<ClinicVisitsLogProps> = ({
  onNavigateToIntake,
  onSelectStudentProfile,
}) => {
  const [visits, setVisits] = useState<ClinicVisit[]>(() => db.getClinicVisits());
  const classes = db.getSchoolClasses();

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [selectedReason, setSelectedReason] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'this_month'>('all');
  const [expandedVisitId, setExpandedVisitId] = useState<string | null>(null);

  const refreshList = () => {
    setVisits(db.getClinicVisits());
  };

  // Filtered visits
  const filteredVisits = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const currentMonthStr = todayStr.substring(0, 7);

    return visits.filter((v) => {
      if (selectedClass !== 'all' && v.className !== selectedClass) return false;

      const visitReason = v.reason || (v.reasons && v.reasons.length > 0 ? v.reasons.join(', ') : v.customReason || '');
      if (selectedReason !== 'all' && !visitReason.toLowerCase().includes(selectedReason.toLowerCase())) return false;

      const visitDate = (v.dateTime ? v.dateTime.split('T')[0] : '') || v.visitDate || '';
      if (dateFilter === 'today' && visitDate !== todayStr) return false;
      if (dateFilter === 'this_month' && !visitDate.startsWith(currentMonthStr)) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = (v.studentName || '').toLowerCase().includes(q);
        const matchCode = (v.studentCode || '').toLowerCase().includes(q);
        const matchVisit = (v.visitCode || '').toLowerCase().includes(q);
        const matchReason = visitReason.toLowerCase().includes(q);
        if (!matchName && !matchCode && !matchVisit && !matchReason) return false;
      }
      return true;
    });
  }, [visits, selectedClass, selectedReason, dateFilter, searchQuery]);

  // Delete visit
  const handleDeleteVisit = (id: string, visitCode: string) => {
    const ok = window.confirm(`Bạn có chắc chắn muốn xóa lượt khám ${visitCode}?`);
    if (!ok) return;
    try {
      db.deleteClinicVisit(id);
      refreshList();
    } catch (err: any) {
      alert(`Lỗi: ${err.message}`);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Mã phiếu',
      'Thời gian',
      'Mã học sinh',
      'Họ và tên',
      'Lớp',
      'Người đưa đến',
      'Lý do khám',
      'Tình trạng ban đầu',
      'Nhiệt độ (°C)',
      'Huyết áp',
      'Mạch',
      'Biện pháp xử trí',
      'Thuốc đã cấp',
      'Vật tư đã dùng',
      'Kết quả',
      'Đã báo phụ huynh',
      'Cán bộ y tế',
      'Ghi chú',
    ];

    const rows = filteredVisits.map((v) => [
      v.visitCode,
      v.dateTime ? formatDateTimeVN(v.dateTime) : (v.visitDate ? `${v.timeIn ? v.timeIn + ' ' : ''}${formatDateVN(v.visitDate)}` : ''),
      v.studentCode,
      v.studentName,
      v.className,
      v.broughtBy || '',
      v.reason || (v.reasons && v.reasons.length > 0 ? v.reasons.join(', ') : v.customReason || ''),
      v.initialCondition || '',
      v.temperature || '',
      v.bloodPressure || '',
      v.pulse || '',
      v.treatment || v.treatmentDetails || v.treatmentType || '',
      (v.medicinesDispensed || v.medicinesUsed)?.map((m) => `${m.medicineName} (${m.quantity} ${m.unit})`).join('; ') || '',
      v.suppliesUsed?.map((s) => `${s.supplyName} (${s.quantity} ${s.unit})`).join('; ') || '',
      v.outcome || '',
      (v.parentContacted || v.parentNotified) ? 'Có' : 'Không',
      v.performer || '',
      v.notes || '',
    ]);

    const csvContent =
      '\uFEFF' +
      [
        `"SỔ THEO DÕI HỌC SINH ĐẾN PHÒNG Y TẾ - TRƯỜNG THCS ĐÔNG THẠNH"`,
        `"Ngày xuất: ${new Date().toLocaleDateString('vi-VN')} | Tổng số ca: ${filteredVisits.length}"`,
        '',
        headers.join(','),
        ...rows.map((r) => r.map((f) => `"${f}"`).join(',')),
      ].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `So_Phong_Y_Te_THCS_Dong_Thanh_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800">
              SỔ PHÒNG Y TẾ
            </span>
            <h1 className="text-xl font-bold text-slate-900">Sổ Theo Dõi Học Sinh Đến Phòng Y Tế</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Trường THCS Đông Thạnh • Sổ điện tử ghi nhận tiếp nhận, sơ cứu, xử trí và cấp phát thuốc học sinh
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToIntake && (
            <button
              onClick={onNavigateToIntake}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tiếp nhận mới</span>
            </button>
          )}

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>In sổ (A4)</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Xuất Excel</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Tìm theo tên học sinh, mã số (HS0001), mã phiếu (YT-2026-0001), lý do..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
            />
          </div>

          {/* Date filter */}
          <div className="flex items-center gap-1">
            <span className="text-xs font-semibold text-slate-600 whitespace-nowrap">Thời gian:</span>
            {(['all', 'today', 'this_month'] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDateFilter(d)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  dateFilter === d
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {d === 'all' ? 'Tất cả' : d === 'today' ? 'Hôm nay' : 'Tháng này'}
              </button>
            ))}
          </div>

          {/* Class filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-600 whitespace-nowrap">Lớp:</span>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium"
            >
              <option value="all">Tất cả lớp</option>
              {classes.map((c) => (
                <option key={c.id} value={c.name}>
                  Lớp {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Reason filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-600 whitespace-nowrap">Lý do:</span>
            <select
              value={selectedReason}
              onChange={(e) => setSelectedReason(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium"
            >
              <option value="all">Tất cả lý do</option>
              <option value="Đau bụng">Đau bụng</option>
              <option value="Đau đầu">Đau đầu</option>
              <option value="Sốt">Sốt</option>
              <option value="Chấn thương">Chấn thương / Ngã</option>
              <option value="Trầy xước">Trầy xước</option>
              <option value="Chảy máu cam">Chảy máu cam</option>
              <option value="Chóng mặt">Chóng mặt / Buồn nôn</option>
            </select>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-100 flex justify-between">
          <span>
            Tổng số: <strong>{filteredVisits.length}</strong> lượt khám
          </span>
          {(selectedClass !== 'all' || selectedReason !== 'all' || dateFilter !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setSelectedClass('all');
                setSelectedReason('all');
                setDateFilter('all');
                setSearchQuery('');
              }}
              className="text-emerald-700 hover:text-emerald-800 font-medium underline"
            >
              Xóa bộ lọc
            </button>
          )}
        </div>
      </div>

      {/* Visits Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-3">Mã phiếu</th>
                <th className="py-3 px-3">Thời gian</th>
                <th className="py-3 px-3">Học sinh</th>
                <th className="py-3 px-3">Lớp</th>
                <th className="py-3 px-3">Lý do khám</th>
                <th className="py-3 px-3">Sinh hiệu</th>
                <th className="py-3 px-3">Xử trí & Cấp thuốc</th>
                <th className="py-3 px-3">Kết quả</th>
                <th className="py-3 px-3 text-right">Chi tiết</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredVisits.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Stethoscope className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-sm text-slate-600">Chưa có lượt tiếp nhận y tế nào</p>
                    <p className="text-xs text-slate-400 mt-1">Bấm "Tiếp nhận mới" để tạo ca tiếp nhận học sinh.</p>
                  </td>
                </tr>
              ) : (
                filteredVisits.map((v) => {
                  const isExpanded = expandedVisitId === v.id;
                  const hasMeds = v.medicinesDispensed && v.medicinesDispensed.length > 0;
                  const hasSupplies = v.suppliesUsed && v.suppliesUsed.length > 0;

                  return (
                    <React.Fragment key={v.id}>
                      <tr
                        className={`hover:bg-slate-50/80 transition-colors cursor-pointer ${
                          isExpanded ? 'bg-purple-50/40' : ''
                        }`}
                        onClick={() => setExpandedVisitId(isExpanded ? null : v.id)}
                      >
                        <td className="py-3 px-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                          <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">{v.visitCode}</span>
                        </td>

                        <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                          {v.dateTime
                            ? formatDateTimeVN(v.dateTime)
                            : v.visitDate
                            ? `${v.timeIn ? v.timeIn + ' ' : ''}${formatDateVN(v.visitDate)}`
                            : '—'}
                        </td>

                        <td className="py-3 px-3 font-semibold text-slate-900">
                          <div className="flex items-center gap-1.5">
                            <span>{v.studentName}</span>
                            <span className="font-mono text-[10px] text-slate-400">({v.studentCode})</span>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span className="font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200/60">
                            {v.className}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-slate-800 font-medium">
                          <span>{v.reason || (v.reasons && v.reasons.length > 0 ? v.reasons.join(', ') : v.customReason || '—')}</span>
                        </td>

                        <td className="py-3 px-3 whitespace-nowrap text-slate-600">
                          {v.temperature ? (
                            <span
                              className={`font-bold ${
                                v.temperature >= 38 ? 'text-rose-600 bg-rose-50 px-1 rounded' : 'text-slate-800'
                              }`}
                            >
                              {v.temperature}°C
                            </span>
                          ) : (
                            '—'
                          )}
                          {v.bloodPressure ? ` | ${v.bloodPressure}` : ''}
                        </td>

                        <td className="py-3 px-3 max-w-xs">
                          <p className="truncate text-slate-700">{v.treatment || v.treatmentDetails || v.treatmentType || '—'}</p>
                          {hasMeds && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700">
                              <Pill className="w-3 h-3" />
                              <span>{(v.medicinesDispensed || v.medicinesUsed || []).map((m) => m.medicineName).join(', ')}</span>
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-3 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              v.outcome.includes('về lớp')
                                ? 'bg-emerald-100 text-emerald-800'
                                : v.outcome.includes('Phụ huynh')
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {v.outcome}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-right whitespace-nowrap">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setExpandedVisitId(isExpanded ? null : v.id);
                            }}
                            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        </td>
                      </tr>

                      {/* Expanded Details Row */}
                      {isExpanded && (
                        <tr className="bg-slate-50 border-y border-purple-100">
                          <td colSpan={9} className="p-4">
                            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3 text-xs">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-900">Chi tiết ca khám {v.visitCode}</span>
                                  <span className="text-slate-400">•</span>
                                  <span className="text-slate-600">Người đưa đến: {v.broughtBy}</span>
                                  <span className="text-slate-400">•</span>
                                  <span className="text-slate-600">Cán bộ y tế: <strong>{v.performer}</strong></span>
                                </div>

                                <div className="flex items-center gap-2">
                                  {onSelectStudentProfile && (
                                    <button
                                      onClick={() => onSelectStudentProfile(v.studentId)}
                                      className="text-blue-700 hover:underline font-semibold"
                                    >
                                      Xem hồ sơ học sinh
                                    </button>
                                  )}
                                  <button
                                    onClick={() => handleDeleteVisit(v.id, v.visitCode)}
                                    className="text-rose-600 hover:text-rose-800 font-semibold ml-3"
                                  >
                                    Xóa ca này
                                  </button>
                                </div>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <div>
                                  <p className="text-slate-400 text-[11px]">Tình trạng ban đầu:</p>
                                  <p className="font-semibold text-slate-800">{v.initialCondition}</p>
                                </div>

                                <div>
                                  <p className="text-slate-400 text-[11px]">Dấu hiệu sinh tồn:</p>
                                  <p className="text-slate-700">
                                    Nhiệt độ: <strong>{v.temperature ? `${v.temperature}°C` : '—'}</strong> | Mạch:{' '}
                                    <strong>{v.pulse ? `${v.pulse} l/p` : '—'}</strong> | Huyết áp:{' '}
                                    <strong>{v.bloodPressure || '—'}</strong> | SpO2:{' '}
                                    <strong>{v.spO2 ? `${v.spO2}%` : '—'}</strong>
                                  </p>
                                </div>

                                <div>
                                  <p className="text-slate-400 text-[11px]">Thông báo phụ huynh:</p>
                                  <p className="text-slate-700">
                                    {v.parentNotified ? (
                                      <span className="text-emerald-700 font-bold">
                                        ✓ Đã liên hệ: {v.parentContactNotes || 'Đồng ý hướng xử trí'}
                                      </span>
                                    ) : (
                                      <span className="text-slate-400">Chưa cần thông báo phụ huynh</span>
                                    )}
                                  </p>
                                </div>
                              </div>

                              {/* Medicines dispensed breakdown */}
                              {hasMeds && (
                                <div className="p-3 bg-emerald-50/70 rounded-lg border border-emerald-200 space-y-1.5">
                                  <p className="font-bold text-emerald-900 flex items-center gap-1.5">
                                    <Pill className="w-3.5 h-3.5" />
                                    <span>Thuốc đã cấp (Tự động trừ kho theo lô FEFO):</span>
                                  </p>
                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                                    {v.medicinesDispensed!.map((m, idx) => (
                                      <div key={idx} className="bg-white p-2 rounded border border-emerald-200">
                                        <div className="flex justify-between">
                                          <span className="font-bold text-slate-900">{m.medicineName}</span>
                                          <span className="font-bold text-emerald-700">
                                            {m.quantity} {m.unit}
                                          </span>
                                        </div>
                                        {m.dosageInstructions && (
                                          <p className="text-slate-500 mt-0.5">Liều dùng: {m.dosageInstructions}</p>
                                        )}
                                        {m.batchNumber && (
                                          <p className="text-slate-400 font-mono text-[10px]">
                                            Lô: {m.batchNumber} (HSD: {m.expDate ? formatDateVN(m.expDate) : '—'})
                                          </p>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* Supplies used breakdown */}
                              {hasSupplies && (
                                <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-200 space-y-1.5">
                                  <p className="font-bold text-blue-900 flex items-center gap-1.5">
                                    <BriefcaseMedical className="w-3.5 h-3.5" />
                                    <span>Vật tư y tế đã sử dụng:</span>
                                  </p>
                                  <div className="flex flex-wrap gap-2 text-[11px]">
                                    {v.suppliesUsed!.map((s, idx) => (
                                      <span
                                        key={idx}
                                        className="bg-white px-2.5 py-1 rounded border border-blue-200 font-medium text-slate-800"
                                      >
                                        {s.supplyName}: <strong>{s.quantity} {s.unit}</strong>
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
