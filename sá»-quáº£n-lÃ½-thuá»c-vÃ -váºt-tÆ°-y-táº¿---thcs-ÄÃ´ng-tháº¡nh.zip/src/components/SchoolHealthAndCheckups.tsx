import React, { useState, useMemo } from 'react';
import {
  Activity,
  AlertOctagon,
  Calendar,
  Plus,
  Search,
  Download,
  Printer,
  Eye,
  CheckCircle2,
  AlertTriangle,
  User,
  PieChart as PieChartIcon,
  X,
} from 'lucide-react';
import { db, formatDateVN, formatDateTimeVN } from '../services/db';
import { HealthEvent, HealthCheckup } from '../types';

export const SchoolHealthAndCheckups: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'events' | 'checkups'>('events');
  const [events, setEvents] = useState<HealthEvent[]>(() => db.getHealthEvents());
  const [checkups, setCheckups] = useState<HealthCheckup[]>(() => db.getHealthCheckups());
  const students = db.getStudents();

  // Search
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isAddEventModalOpen, setIsAddEventModalOpen] = useState(false);
  const [isAddCheckupModalOpen, setIsAddCheckupModalOpen] = useState(false);

  // New Event Form State
  const [eventForm, setEventForm] = useState({
    dateTime: new Date().toISOString().substring(0, 16),
    location: 'Sân trường',
    eventType: 'Tai nạn' as any,
    studentId: '',
    description: '',
    initialCondition: '',
    treatment: '',
    witness: '',
    performer: 'Y sĩ Trần Thị Bích Thảo',
    outcome: 'Đã sơ cứu, theo dõi tiếp tục',
    notes: '',
  });

  // New Checkup Form State
  const [checkupForm, setCheckupForm] = useState({
    checkupDate: new Date().toISOString().split('T')[0],
    schoolYear: '2026-2027',
    studentId: '',
    height: 152,
    weight: 44,
    visionLeft: 10,
    visionRight: 10,
    refractiveError: 'Không',
    dentalStatus: 'Bình thường',
    entStatus: 'Bình thường',
    spineStatus: 'Bình thường',
    nutritionClassification: 'Bình thường' as any,
    recommendations: '',
  });

  const refreshData = () => {
    setEvents(db.getHealthEvents());
    setCheckups(db.getHealthCheckups());
  };

  // Submit new Event
  const handleSubmitEvent = (e: React.FormEvent) => {
    e.preventDefault();
    const stu = students.find((s) => s.id === eventForm.studentId);
    db.addHealthEvent({
      ...eventForm,
      studentName: stu?.fullName,
      studentCode: stu?.studentCode,
      className: stu?.className,
    });
    setIsAddEventModalOpen(false);
    refreshData();
  };

  // Submit new Checkup
  const handleSubmitCheckup = (e: React.FormEvent) => {
    e.preventDefault();
    const stu = students.find((s) => s.id === checkupForm.studentId);
    if (!stu) return;

    const bmi = parseFloat((checkupForm.weight / Math.pow(checkupForm.height / 100, 2)).toFixed(1));

    db.addHealthCheckup({
      ...checkupForm,
      studentCode: stu.studentCode,
      studentName: stu.fullName,
      className: stu.className,
      bmi,
    });
    setIsAddCheckupModalOpen(false);
    refreshData();
  };

  // Stats for Checkups
  const checkupStats = useMemo(() => {
    const total = checkups.length;
    if (total === 0) return { total: 0, myopiaRate: 0, dentalRate: 0, spineRate: 0 };
    const myopia = checkups.filter((c) => c.refractiveError && c.refractiveError !== 'Không').length;
    const dental = checkups.filter((c) => c.dentalStatus && !c.dentalStatus.toLowerCase().includes('bình thường')).length;
    const spine = checkups.filter((c) => c.spineStatus && !c.spineStatus.toLowerCase().includes('bình thường')).length;

    return {
      total,
      myopiaCount: myopia,
      myopiaRate: Math.round((myopia / total) * 100),
      dentalCount: dental,
      dentalRate: Math.round((dental / total) * 100),
      spineCount: spine,
      spineRate: Math.round((spine / total) * 100),
    };
  }, [checkups]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
              Y TẾ HỌC ĐƯỜNG
            </span>
            <h1 className="text-xl font-bold text-slate-900">Sự Kiện Y Tế & Khám Sức Khỏe Định Kỳ</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Trường THCS Đông Thạnh • Theo dõi tai nạn thương tích, dịch bệnh học đường và kết quả khám sức khỏe hàng năm
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'events' ? (
            <button
              onClick={() => setIsAddEventModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-semibold shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Ghi nhận sự cố y tế</span>
            </button>
          ) : (
            <button
              onClick={() => setIsAddCheckupModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm kết quả khám định kỳ</span>
            </button>
          )}

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200"
          >
            <Printer className="w-4 h-4" />
            <span>In sổ</span>
          </button>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex border-b border-slate-200 gap-4">
        <button
          onClick={() => setActiveTab('events')}
          className={`flex items-center gap-2 pb-3 font-bold text-xs border-b-2 transition-colors ${
            activeTab === 'events'
              ? 'border-rose-600 text-rose-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <AlertOctagon className="w-4 h-4" />
          <span>Sự kiện tai nạn, chấn thương, dịch bệnh ({events.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('checkups')}
          className={`flex items-center gap-2 pb-3 font-bold text-xs border-b-2 transition-colors ${
            activeTab === 'checkups'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Khám sức khỏe học sinh định kỳ ({checkups.length})</span>
        </button>
      </div>

      {/* TAB 1: SỰ KIỆN Y TẾ & TAI NẠN THƯƠNG TÍCH */}
      {activeTab === 'events' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-rose-50/70 p-4 rounded-xl border border-rose-200">
              <p className="text-xs font-bold text-rose-800">Tai nạn, chấn thương sân trường</p>
              <p className="text-2xl font-bold text-rose-900 mt-1">
                {events.filter((e) => e.eventType === 'Tai nạn' || e.eventType === 'Chấn thương').length}
              </p>
              <p className="text-[10px] text-rose-600/80 mt-0.5">Xảy ra trong giờ thể dục hoặc ra chơi</p>
            </div>

            <div className="bg-amber-50/70 p-4 rounded-xl border border-amber-200">
              <p className="text-xs font-bold text-amber-800">Sốt cao & Ngất tại lớp</p>
              <p className="text-2xl font-bold text-amber-900 mt-1">
                {events.filter((e) => e.eventType === 'Sốt cao' || e.eventType === 'Ngất').length}
              </p>
              <p className="text-[10px] text-amber-600/80 mt-0.5">Được sơ cứu và bàn giao phụ huynh</p>
            </div>

            <div className="bg-blue-50/70 p-4 rounded-xl border border-blue-200">
              <p className="text-xs font-bold text-blue-800">Dịch bệnh nghi ngờ / Dị ứng</p>
              <p className="text-2xl font-bold text-blue-900 mt-1">
                {events.filter((e) => e.eventType === 'Dịch bệnh nghi ngờ' || e.eventType === 'Dị ứng').length}
              </p>
              <p className="text-[10px] text-blue-600/80 mt-0.5">Theo dõi giám sát y tế trường học</p>
            </div>
          </div>

          {/* Events Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="py-3 px-3.5">Mã sự kiện</th>
                    <th className="py-3 px-3">Thời gian</th>
                    <th className="py-3 px-3">Địa điểm</th>
                    <th className="py-3 px-3">Phân loại</th>
                    <th className="py-3 px-3">Học sinh liên quan</th>
                    <th className="py-3 px-3">Mô tả sự cố & Sơ cứu</th>
                    <th className="py-3 px-3">Kết quả xử trí</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {events.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-10 text-center text-slate-400">
                        Chưa có ghi nhận sự cố y tế nào.
                      </td>
                    </tr>
                  ) : (
                    events.map((e) => (
                      <tr key={e.id} className="hover:bg-slate-50">
                        <td className="py-3 px-3.5 font-mono font-bold text-slate-800 whitespace-nowrap">
                          {e.eventCode}
                        </td>
                        <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                          {formatDateTimeVN(e.dateTime)}
                        </td>
                        <td className="py-3 px-3 font-medium text-slate-800 whitespace-nowrap">{e.location}</td>
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              e.eventType === 'Tai nạn' || e.eventType === 'Chấn thương'
                                ? 'bg-rose-100 text-rose-800'
                                : e.eventType === 'Sốt cao'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {e.eventType}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-semibold text-slate-900">
                          {e.studentName ? (
                            <div>
                              <span>{e.studentName}</span>
                              <span className="text-[10px] text-slate-400 block font-normal">
                                Lớp {e.className} ({e.studentCode})
                              </span>
                            </div>
                          ) : (
                            'Nhiều học sinh / Tập thể'
                          )}
                        </td>
                        <td className="py-3 px-3 max-w-sm">
                          <p className="font-medium text-slate-800">{e.description}</p>
                          <p className="text-[11px] text-slate-500 mt-0.5">Sơ cứu: {e.treatment}</p>
                        </td>
                        <td className="py-3 px-3 text-emerald-800 font-semibold">{e.outcome}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: KHÁM SỨC KHỎE ĐỊNH KỲ */}
      {activeTab === 'checkups' && (
        <div className="space-y-4">
          {/* Health Indicators Overview */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <p className="text-xs font-semibold text-slate-500">Tổng HS đã khám</p>
              <p className="text-2xl font-bold text-slate-900 mt-1">{checkupStats.total}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Đợt khám đầu năm học</p>
            </div>

            <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 shadow-xs">
              <p className="text-xs font-bold text-amber-800">Tật khúc xạ (Cận thị)</p>
              <p className="text-2xl font-bold text-amber-900 mt-1">
                {checkupStats.myopiaRate}%{' '}
                <span className="text-xs font-normal text-amber-700">({checkupStats.myopiaCount} HS)</span>
              </p>
              <p className="text-[10px] text-amber-700 mt-0.5">Thị lực &lt; 10/10</p>
            </div>

            <div className="bg-blue-50 p-4 rounded-xl border border-blue-200 shadow-xs">
              <p className="text-xs font-bold text-blue-800">Bệnh Răng - Miệng</p>
              <p className="text-2xl font-bold text-blue-900 mt-1">
                {checkupStats.dentalRate}%{' '}
                <span className="text-xs font-normal text-blue-700">({checkupStats.dentalCount} HS)</span>
              </p>
              <p className="text-[10px] text-blue-700 mt-0.5">Sâu răng, viêm lợi</p>
            </div>

            <div className="bg-purple-50 p-4 rounded-xl border border-purple-200 shadow-xs">
              <p className="text-xs font-bold text-purple-800">Cong vẹo cột sống</p>
              <p className="text-2xl font-bold text-purple-900 mt-1">
                {checkupStats.spineRate}%{' '}
                <span className="text-xs font-normal text-purple-700">({checkupStats.spineCount} HS)</span>
              </p>
              <p className="text-[10px] text-purple-700 mt-0.5">Tư thế ngồi học sai</p>
            </div>
          </div>

          {/* Checkups Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="py-3 px-3">Mã phiếu</th>
                    <th className="py-3 px-3">Học sinh</th>
                    <th className="py-3 px-3">Lớp</th>
                    <th className="py-3 px-3">Thể lực (Cao/Nặng)</th>
                    <th className="py-3 px-3">Chỉ số BMI</th>
                    <th className="py-3 px-3">Thị lực (T/P)</th>
                    <th className="py-3 px-3">Tật khúc xạ</th>
                    <th className="py-3 px-3">Răng - Miệng</th>
                    <th className="py-3 px-3">Dinh dưỡng</th>
                    <th className="py-3 px-3">Khuyến nghị phụ huynh</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {checkups.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                        {c.checkupCode}
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-900">{c.studentName}</td>
                      <td className="py-3 px-3 font-bold text-emerald-800">{c.className}</td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        {c.height}cm • {c.weight}kg
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-800">{c.bmi}</td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        {c.visionLeft}/10 • {c.visionRight}/10
                      </td>
                      <td className="py-3 px-3 text-amber-800 font-medium">{c.refractiveError || 'Không'}</td>
                      <td className="py-3 px-3 text-slate-700">{c.dentalStatus || 'Bình thường'}</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                          {c.nutritionClassification}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-600 max-w-xs truncate">{c.recommendations || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Thêm sự kiện y tế */}
      {isAddEventModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">Ghi Nhận Sự Cố / Tai Nạn Học Đường</h3>
              <button onClick={() => setIsAddEventModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSubmitEvent} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Loại sự kiện</label>
                <select
                  value={eventForm.eventType}
                  onChange={(e) => setEventForm({ ...eventForm, eventType: e.target.value as any })}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-white"
                >
                  <option value="Tai nạn">Tai nạn</option>
                  <option value="Chấn thương">Chấn thương</option>
                  <option value="Sốt cao">Sốt cao</option>
                  <option value="Dịch bệnh nghi ngờ">Dịch bệnh nghi ngờ</option>
                  <option value="Ngất">Ngất xỉu</option>
                  <option value="Dị ứng">Dị ứng cấp</option>
                  <option value="Sự cố khác">Sự cố khác</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Học sinh liên quan</label>
                <select
                  value={eventForm.studentId}
                  onChange={(e) => setEventForm({ ...eventForm, studentId: e.target.value })}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-white"
                >
                  <option value="">-- Chọn học sinh hoặc để trống nếu tập thể --</option>
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.studentCode} - {s.fullName} ({s.className})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Thời gian</label>
                  <input
                    type="datetime-local"
                    value={eventForm.dateTime}
                    onChange={(e) => setEventForm({ ...eventForm, dateTime: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Địa điểm xảy ra</label>
                  <input
                    type="text"
                    value={eventForm.location}
                    onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                    placeholder="Sân trường, Căng tin..."
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Mô tả sự cố & Sơ cứu</label>
                <textarea
                  rows={2}
                  required
                  value={eventForm.description}
                  onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
                  placeholder="Mô tả cụ thể diễn biến sự cố..."
                  className="w-full border border-slate-200 rounded-xl p-2.5"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Xử trí ban đầu</label>
                <input
                  type="text"
                  required
                  value={eventForm.treatment}
                  onChange={(e) => setEventForm({ ...eventForm, treatment: e.target.value })}
                  placeholder="Rửa vết thương, băng nẹp, chườm lạnh..."
                  className="w-full border border-slate-200 rounded-xl px-3 py-2"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddEventModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl font-semibold"
                >
                  Lưu sự kiện
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Thêm kết quả khám định kỳ */}
      {isAddCheckupModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">Ghi Nhận Kết Quả Khám Sức Khỏe Định Kỳ</h3>
              <button onClick={() => setIsAddCheckupModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSubmitCheckup} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Học sinh được khám</label>
                <select
                  required
                  value={checkupForm.studentId}
                  onChange={(e) => setCheckupForm({ ...checkupForm, studentId: e.target.value })}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-white"
                >
                  <option value="">-- Chọn học sinh --</option>
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.studentCode} - {s.fullName} ({s.className})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Chiều cao (cm)</label>
                  <input
                    type="number"
                    value={checkupForm.height}
                    onChange={(e) => setCheckupForm({ ...checkupForm, height: parseFloat(e.target.value) || 0 })}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Cân nặng (kg)</label>
                  <input
                    type="number"
                    value={checkupForm.weight}
                    onChange={(e) => setCheckupForm({ ...checkupForm, weight: parseFloat(e.target.value) || 0 })}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Thị lực mắt Trái (/10)</label>
                  <input
                    type="number"
                    max="10"
                    min="1"
                    value={checkupForm.visionLeft}
                    onChange={(e) => setCheckupForm({ ...checkupForm, visionLeft: parseInt(e.target.value, 10) || 10 })}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Thị lực mắt Phải (/10)</label>
                  <input
                    type="number"
                    max="10"
                    min="1"
                    value={checkupForm.visionRight}
                    onChange={(e) => setCheckupForm({ ...checkupForm, visionRight: parseInt(e.target.value, 10) || 10 })}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tật khúc xạ (nếu có)</label>
                <input
                  type="text"
                  value={checkupForm.refractiveError}
                  onChange={(e) => setCheckupForm({ ...checkupForm, refractiveError: e.target.value })}
                  placeholder="Cận thị 1.5 diop..."
                  className="w-full border border-slate-200 rounded-xl px-3 py-2"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Răng hàm mặt</label>
                  <input
                    type="text"
                    value={checkupForm.dentalStatus}
                    onChange={(e) => setCheckupForm({ ...checkupForm, dentalStatus: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Cột sống</label>
                  <input
                    type="text"
                    value={checkupForm.spineStatus}
                    onChange={(e) => setCheckupForm({ ...checkupForm, spineStatus: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Khuyến nghị gửi phụ huynh</label>
                <input
                  type="text"
                  value={checkupForm.recommendations}
                  onChange={(e) => setCheckupForm({ ...checkupForm, recommendations: e.target.value })}
                  placeholder="Khuyên gia đình đưa cháu đi khám chuyên khoa mắt..."
                  className="w-full border border-slate-200 rounded-xl px-3 py-2"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddCheckupModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-semibold"
                >
                  Lưu kết quả khám
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
