import * as XLSX from 'xlsx';
import {
  Medicine,
  MedicineBatch,
  InventoryTransaction,
  MedicalSupply,
  InventoryCheck,
  StockInOutBalanceRow,
} from '../types';
import { formatDateVN, getDaysRemaining } from './db';

// Helper to get formatted date string for file names: YYYY_MM_DD
export function getFilenameDate(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}_${month}_${day}`;
}

// Helper to create styled worksheet with title headers, auto width and summary
function createReportSheet(
  reportTitle: string,
  filterInfo: string,
  headers: string[],
  dataRows: (string | number)[][],
  summaryRow?: (string | number)[]
): XLSX.WorkSheet {
  const schoolHeader = ['TRƯỜNG THCS ĐÔNG THẠNH', 'PHÒNG Y TẾ HỌC ĐƯỜNG'];
  const nowStr = `Thời điểm xuất: ${new Date().toLocaleString('vi-VN')}`;
  
  const sheetAoa: (string | number)[][] = [
    [schoolHeader[0]],
    [schoolHeader[1]],
    [''],
    [reportTitle.toUpperCase()],
    [nowStr],
    [filterInfo ? `Bộ lọc: ${filterInfo}` : ''],
    [''],
    headers,
    ...dataRows,
  ];

  if (summaryRow) {
    sheetAoa.push(summaryRow);
  }

  // Footer signatures
  sheetAoa.push(['']);
  sheetAoa.push(['', '', '', '', 'Ngày ..... tháng ..... năm 2026']);
  sheetAoa.push(['', 'NGƯỜI LẬP BÁO CÁO', '', '', 'CÁN BỘ PHỤ TRÁCH Y TẾ']);
  sheetAoa.push(['', '(Ký, ghi rõ họ tên)', '', '', '(Ký, ghi rõ họ tên)']);

  const ws = XLSX.utils.aoa_to_sheet(sheetAoa);

  // Auto calculate column widths
  const colWidths = headers.map((h, colIdx) => {
    let maxLen = h.length;
    for (const row of dataRows) {
      const val = row[colIdx];
      if (val !== undefined && val !== null) {
        const strVal = String(val);
        if (strVal.length > maxLen) maxLen = strVal.length;
      }
    }
    return { wch: Math.min(Math.max(maxLen + 4, 12), 40) };
  });

  ws['!cols'] = colWidths;
  return ws;
}

function downloadWorkbook(ws: XLSX.WorkSheet, sheetName: string, fileName: string) {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, fileName);
}

// 1. Export Danh mục thuốc
export function exportMedicinesExcel(medicines: Medicine[], batches: MedicineBatch[]) {
  const headers = [
    'STT',
    'Mã thuốc',
    'Tên biệt dược',
    'Hoạt chất',
    'Hàm lượng',
    'Dạng bào chế',
    'Đơn vị tính',
    'Quy cách',
    'Nhà sản xuất',
    'Mức tồn tối thiểu',
    'Tồn hiện tại',
    'Đơn giá (VNĐ)',
    'Vị trí tủ',
  ];

  const rows = medicines.map((m, idx) => {
    const medBatches = batches.filter((b) => b.medicineId === m.id);
    const totalQty = medBatches.reduce((sum, b) => sum + (b.quantity || 0), 0);
    return [
      idx + 1,
      m.code,
      m.name,
      m.activeIngredient,
      m.strength,
      m.dosageForm,
      m.unit,
      m.packing,
      m.manufacturer,
      m.minStock,
      totalQty,
      m.unitPrice,
      m.storageLocation,
    ];
  });

  const totalQty = rows.reduce((sum, r) => sum + Number(r[10] || 0), 0);
  const summaryRow = ['TỔNG CỘNG', '', '', '', '', '', '', '', '', '', totalQty, '', ''];

  const ws = createReportSheet('DANH MỤC THUỐC THIẾT YẾU HỌC ĐƯỜNG', 'Toàn bộ danh mục tủ thuốc', headers, rows, summaryRow);
  downloadWorkbook(ws, 'Danh_Muc_Thuoc', `Danh_Muc_Thuoc_${getFilenameDate()}.xlsx`);
}

// 2. Export Danh mục vật tư y tế
export function exportSuppliesExcel(supplies: MedicalSupply[]) {
  const headers = [
    'STT',
    'Mã vật tư',
    'Tên vật tư y tế',
    'Nhóm phân loại',
    'Đơn vị tính',
    'Số lượng tồn',
    'Mức tồn tối thiểu',
    'Hạn sử dụng',
    'Vị trí bảo quản',
    'Ghi chú',
  ];

  const rows = supplies.map((s, idx) => [
    idx + 1,
    s.code,
    s.name,
    s.category,
    s.unit,
    s.quantity,
    s.minStock,
    s.expDate ? formatDateVN(s.expDate) : 'Không áp dụng',
    s.storageLocation,
    s.notes || '',
  ]);

  const totalQty = rows.reduce((sum, r) => sum + Number(r[5] || 0), 0);
  const summaryRow = ['TỔNG CỘNG', '', '', '', '', totalQty, '', '', '', ''];

  const ws = createReportSheet('DANH MỤC VẬT TƯ Y TẾ HỌC ĐƯỜNG', 'Toàn bộ vật tư tiêu hao và trang thiết bị', headers, rows, summaryRow);
  downloadWorkbook(ws, 'Vat_Tu_Y_Te', `Danh_Muc_Vat_Tu_${getFilenameDate()}.xlsx`);
}

// 3. Export Sổ nhập thuốc
export function exportImportTransactionsExcel(transactions: InventoryTransaction[]) {
  const importTxs = transactions.filter((t) => t.type === 'import' && t.status !== 'cancelled');
  const headers = [
    'STT',
    'Số phiếu',
    'Ngày nhập',
    'Tên thuốc',
    'Số lô',
    'Hạn sử dụng',
    'Đơn vị',
    'Số lượng nhập',
    'Đơn giá (VNĐ)',
    'Thành tiền (VNĐ)',
    'Nguồn / Nhà cung cấp',
    'Người giao',
    'Người nhận',
  ];

  let stt = 1;
  const rows: (string | number)[][] = [];
  let totalQty = 0;
  let totalAmount = 0;

  for (const tx of importTxs) {
    for (const item of tx.items) {
      rows.push([
        stt++,
        tx.transactionCode,
        formatDateVN(tx.date),
        item.medicineName,
        item.batchNumber,
        item.expDate ? formatDateVN(item.expDate) : '---',
        item.unit,
        item.quantity,
        item.unitPrice,
        item.totalAmount,
        tx.source || 'Ngân sách trường',
        tx.deliverer || '',
        tx.receiver || tx.performer,
      ]);
      totalQty += item.quantity;
      totalAmount += item.totalAmount;
    }
  }

  const summaryRow = ['TỔNG CỘNG', '', '', '', '', '', '', totalQty, '', totalAmount, '', '', ''];
  const ws = createReportSheet('SỔ THEO DÕI NHẬP THUỐC VÀO TỦ Y TẾ', `Năm học 2026 - 2027 (${importTxs.length} phiếu)`, headers, rows, summaryRow);
  downloadWorkbook(ws, 'So_Nhap_Thuoc', `So_Nhap_Thuoc_${getFilenameDate()}.xlsx`);
}

// 4. Export Sổ xuất / cấp phát thuốc
export function exportExportTransactionsExcel(transactions: InventoryTransaction[]) {
  const exportTxs = transactions.filter((t) => t.type === 'export' && t.status !== 'cancelled');
  const headers = [
    'STT',
    'Số phiếu',
    'Ngày xuất',
    'Tên thuốc',
    'Số lô xuất',
    'HSD',
    'Đơn vị',
    'Số lượng',
    'Đối tượng sử dụng',
    'Lớp / Bộ phận',
    'Mục đích / Triệu chứng',
    'Người thực hiện',
    'Ghi chú',
  ];

  let stt = 1;
  const rows: (string | number)[][] = [];
  let totalQty = 0;

  for (const tx of exportTxs) {
    for (const item of tx.items) {
      rows.push([
        stt++,
        tx.transactionCode,
        formatDateVN(tx.date),
        item.medicineName,
        item.batchNumber,
        item.expDate ? formatDateVN(item.expDate) : '---',
        item.unit,
        item.quantity,
        tx.recipientName || 'Học sinh',
        tx.recipientClass || '',
        tx.purpose || '',
        tx.performer,
        tx.notes || '',
      ]);
      totalQty += item.quantity;
    }
  }

  const summaryRow = ['TỔNG CỘNG', '', '', '', '', '', '', totalQty, '', '', '', '', ''];
  const ws = createReportSheet('SỔ THEO DÕI XUẤT CẤP PHÁT THUỐC SƠ CỨU', `Năm học 2026 - 2027 (${exportTxs.length} lượt)`, headers, rows, summaryRow);
  downloadWorkbook(ws, 'So_Xuat_Thuoc', `So_Xuat_Thuoc_${getFilenameDate()}.xlsx`);
}

// 5. Export Báo cáo Tồn kho
export function exportStockReportExcel(medicines: Medicine[], batches: MedicineBatch[]) {
  const headers = [
    'STT',
    'Mã thuốc',
    'Tên thuốc',
    'Đơn vị tính',
    'Số lô hiện có',
    'Hạn dùng gần nhất',
    'Mức tồn tối thiểu',
    'Số lượng tồn',
    'Đơn giá tham khảo (VNĐ)',
    'Thành tiền tồn kho (VNĐ)',
    'Vị trí lưu trữ',
    'Tình trạng',
  ];

  let totalQty = 0;
  let totalValuation = 0;

  const rows = medicines.map((m, idx) => {
    const medBatches = batches.filter((b) => b.medicineId === m.id);
    const qty = medBatches.reduce((acc, b) => acc + (b.quantity || 0), 0);
    const valuation = qty * (m.unitPrice || 0);
    totalQty += qty;
    totalValuation += valuation;

    return [
      idx + 1,
      m.code,
      m.name,
      m.unit,
      medBatches.length,
      m.earliestExpDate ? formatDateVN(m.earliestExpDate) : '---',
      m.minStock,
      qty,
      m.unitPrice,
      valuation,
      m.storageLocation,
      qty === 0 ? 'Hết hàng' : qty <= m.minStock ? 'Sắp hết' : 'An toàn',
    ];
  });

  const summaryRow = ['TỔNG CỘNG', '', '', '', '', '', '', totalQty, '', totalValuation, '', ''];
  const ws = createReportSheet('BÁO CÁO TỒN KHO THUỐC TỦ Y TẾ', 'Tổng hợp số dư tồn kho theo mặt hàng', headers, rows, summaryRow);
  downloadWorkbook(ws, 'Bao_Cao_Ton_Kho', `Bao_Cao_Ton_Kho_${getFilenameDate()}.xlsx`);
}

// 6. Export Sổ Nhập - Xuất - Tồn (Core Section 7, 15, 16)
export function exportInOutBalanceExcel(
  rowsData: StockInOutBalanceRow[],
  filterStr = 'Từ đầu kỳ đến hiện tại',
  schoolName = 'TRƯỜNG THCS ĐÔNG THẠNH'
) {
  const headers = [
    'STT',
    'Ngày / Kỳ',
    'Mã thuốc',
    'Tên thuốc',
    'Số lô',
    'Hạn sử dụng',
    'Đơn vị tính',
    'Tồn đầu kỳ',
    'Nhập trong kỳ',
    'Xuất trong kỳ',
    'Điều chỉnh',
    'Tồn cuối kỳ',
    'Ghi chú',
  ];

  let totalOpening = 0;
  let totalImport = 0;
  let totalExport = 0;
  let totalAdj = 0;
  let totalClosing = 0;

  const rows = rowsData.map((r, idx) => {
    totalOpening += r.openingStock;
    totalImport += r.importQuantity;
    totalExport += r.exportQuantity;
    totalAdj += r.adjustmentQuantity || 0;
    totalClosing += r.closingStock;

    return [
      idx + 1,
      r.date || 'Toàn kỳ',
      r.medicineCode,
      r.medicineName,
      r.batchNumber,
      r.expDate ? formatDateVN(r.expDate) : '---',
      r.unit,
      r.openingStock,
      r.importQuantity,
      r.exportQuantity,
      r.adjustmentQuantity || 0,
      r.closingStock,
      r.notes || '',
    ];
  });

  const summaryRow = [
    'TỔNG CỘNG',
    '',
    '',
    '',
    '',
    '',
    '',
    totalOpening,
    totalImport,
    totalExport,
    totalAdj,
    totalClosing,
    '',
  ];

  const ws = createReportSheet(
    'SỔ THEO DÕI NHẬP – XUẤT – TỒN THUỐC VÀ VẬT TƯ Y TẾ',
    filterStr,
    headers,
    rows,
    summaryRow
  );

  // Exact file name per requirement Section 16: So_Nhap_Xuat_Ton_YYYY_MM_DD.xlsx
  downloadWorkbook(ws, 'Nhap_Xuat_Ton', `So_Nhap_Xuat_Ton_${getFilenameDate()}.xlsx`);
}

// 7. Export Tồn theo từng lô riêng biệt (Section 8)
export function exportBatchStockExcel(medicines: Medicine[], batches: MedicineBatch[]) {
  const headers = [
    'STT',
    'Tên thuốc',
    'Số lô',
    'Ngày sản xuất',
    'Hạn sử dụng',
    'Số ngày còn lại',
    'Tổng nhập',
    'Đã xuất',
    'Tồn hiện tại',
    'Đơn vị',
    'Đơn giá (VNĐ)',
    'Thành tiền tồn (VNĐ)',
    'Trạng thái',
  ];

  let totalQty = 0;
  let totalValuation = 0;

  const rows: (string | number)[][] = [];
  batches.forEach((b, idx) => {
    const med = medicines.find((m) => m.id === b.medicineId);
    const days = getDaysRemaining(b.expDate);
    const val = b.quantity * (b.unitPrice || med?.unitPrice || 0);
    totalQty += b.quantity;
    totalValuation += val;

    let statusStr = 'Bình thường';
    if (days < 0) statusStr = 'ĐÃ HẾT HẠN';
    else if (days <= 30) statusStr = 'SẮP HẾT HẠN (≤30 ngày)';
    else if (days <= 60) statusStr = 'CẢNH BÁO (≤60 ngày)';
    else if (b.quantity === 0) statusStr = 'Hết tồn lô';

    rows.push([
      idx + 1,
      med ? med.name : 'Không xác định',
      b.batchNumber,
      b.mfgDate ? formatDateVN(b.mfgDate) : '---',
      formatDateVN(b.expDate),
      days < 0 ? `Quá hạn ${Math.abs(days)} ngày` : `${days} ngày`,
      b.initialQuantity || b.quantity,
      (b.initialQuantity || b.quantity) - b.quantity,
      b.quantity,
      med ? med.unit : 'Viên',
      b.unitPrice || med?.unitPrice || 0,
      val,
      statusStr,
    ]);
  });

  const summaryRow = ['TỔNG CỘNG', '', '', '', '', '', '', '', totalQty, '', '', totalValuation, ''];
  const ws = createReportSheet('BÁO CÁO TỒN KHO CHI TIẾT THEO TỪNG LÔ (FEFO)', 'Tách bạch từng số lô riêng biệt', headers, rows, summaryRow);
  downloadWorkbook(ws, 'Ton_Theo_Lo', `Ton_Kho_Theo_Lo_${getFilenameDate()}.xlsx`);
}

// 8. Export Danh sách thuốc sắp hết
export function exportLowStockExcel(lowStockMeds: Medicine[]) {
  const headers = [
    'STT',
    'Mã thuốc',
    'Tên thuốc',
    'Đơn vị tính',
    'Tồn hiện tại',
    'Mức tồn tối thiểu',
    'Số lượng cần bổ sung',
    'Vị trí bảo quản',
    'Ghi chú đề xuất',
  ];

  const rows = lowStockMeds.map((m, idx) => {
    const need = Math.max(0, m.minStock * 2 - (m.totalStock || 0));
    return [
      idx + 1,
      m.code,
      m.name,
      m.unit,
      m.totalStock || 0,
      m.minStock,
      need,
      m.storageLocation,
      'Cần lập dự trù nhập bổ sung cho tủ y tế học đường',
    ];
  });

  const ws = createReportSheet('DANH SÁCH THUỐC SẮP HẾT & CẦN BỔ SUNG', `Có ${lowStockMeds.length} mặt hàng chạm ngưỡng tồn tối thiểu`, headers, rows);
  downloadWorkbook(ws, 'Thuoc_Sap_Het', `Danh_Sach_Thuoc_Sap_Het_${getFilenameDate()}.xlsx`);
}

// 9. Export Danh sách thuốc sắp hết hạn
export function exportExpiringSoonExcel(medicines: Medicine[], expiringBatches: MedicineBatch[], daysThreshold = 30) {
  const headers = [
    'STT',
    'Tên thuốc',
    'Số lô',
    'Hạn sử dụng',
    'Số lượng tồn',
    'Số ngày còn lại',
    'Trạng thái',
    'Vị trí bảo quản',
    'Ghi chú xử lý',
  ];

  let totalQty = 0;
  const rows = expiringBatches.map((b, idx) => {
    const med = medicines.find((m) => m.id === b.medicineId);
    const days = getDaysRemaining(b.expDate);
    totalQty += b.quantity;
    return [
      idx + 1,
      med ? med.name : 'Không xác định',
      b.batchNumber,
      formatDateVN(b.expDate),
      b.quantity,
      `${days} ngày`,
      days <= 30 ? 'Cực kỳ khẩn cấp (≤ 30 ngày)' : 'Sắp đến hạn',
      med?.storageLocation || 'Tủ y tế',
      'Ưu tiên xuất dùng trước theo nguyên tắc FEFO',
    ];
  });

  const summaryRow = ['TỔNG CỘNG', '', '', '', totalQty, '', '', '', ''];
  const ws = createReportSheet('DANH SÁCH THUỐC SẮP HẾT HẠN', `Ngưỡng lọc cảnh báo: Còn ≤ ${daysThreshold} ngày`, headers, rows, summaryRow);
  downloadWorkbook(ws, 'Sap_Het_Han', `Danh_Sach_Thuoc_Sap_Het_Han_${getFilenameDate()}.xlsx`);
}

// 10. Export Danh sách thuốc đã hết hạn
export function exportExpiredExcel(medicines: Medicine[], expiredBatches: MedicineBatch[]) {
  const headers = [
    'STT',
    'Tên thuốc',
    'Số lô',
    'Hạn sử dụng',
    'Số lượng tồn',
    'Vị trí bảo quản',
    'Tình trạng pháp lý',
    'Đề xuất xử lý',
  ];

  let totalQty = 0;
  const rows = expiredBatches.map((b, idx) => {
    const med = medicines.find((m) => m.id === b.medicineId);
    const days = Math.abs(getDaysRemaining(b.expDate));
    totalQty += b.quantity;
    return [
      idx + 1,
      med ? med.name : 'Không xác định',
      b.batchNumber,
      formatDateVN(b.expDate),
      b.quantity,
      med?.storageLocation || 'Tủ A',
      `ĐÃ HẾT HẠN (${days} ngày trước)`,
      'NIÊM PHONG - KHÔNG ĐƯỢC XUẤT - Lập biên bản tiêu hủy',
    ];
  });

  const summaryRow = ['TỔNG CỘNG', '', '', '', totalQty, '', '', ''];
  const ws = createReportSheet('DANH SÁCH THUỐC ĐÃ HẾT HẠN SỬ DỤNG', 'NGHIÊM CẤM XUẤT CẤP PHÁT HỌC SINH', headers, rows, summaryRow);
  downloadWorkbook(ws, 'Da_Het_Han', `Danh_Sach_Thuoc_Da_Het_Han_${getFilenameDate()}.xlsx`);
}

// 11. Export Biên bản kiểm kê
export function exportInventoryCheckExcel(check: InventoryCheck) {
  const headers = [
    'STT',
    'Mã thuốc/vật tư',
    'Tên thuốc / vật tư y tế',
    'Số lô',
    'Hạn sử dụng',
    'Đơn vị tính',
    'Tồn trên phần mềm',
    'Tồn thực tế kiểm đếm',
    'Chênh lệch',
    'Đánh giá',
    'Nguyên nhân chênh lệch',
    'Ghi chú',
  ];

  let sysTotal = 0;
  let actTotal = 0;
  let diffTotal = 0;

  const rows = check.items.map((item, idx) => {
    sysTotal += item.systemQuantity;
    actTotal += item.actualQuantity;
    diffTotal += item.difference;

    let evalStr = 'KHỚP (Đạt)';
    if (item.difference > 0) evalStr = `THỪA (+${item.difference})`;
    if (item.difference < 0) evalStr = `THIẾU (${item.difference})`;

    return [
      idx + 1,
      item.medicineCode || '',
      item.medicineName,
      item.batchNumber,
      item.expDate ? formatDateVN(item.expDate) : '---',
      item.unit,
      item.systemQuantity,
      item.actualQuantity,
      item.difference,
      evalStr,
      item.reason || '',
      item.notes || '',
    ];
  });

  const summaryRow = ['TỔNG CỘNG', '', '', '', '', '', sysTotal, actTotal, diffTotal, '', '', ''];
  const filterStr = `Số phiếu: ${check.checkCode} • Ngày kiểm: ${formatDateVN(check.checkDate)} • Trạng thái: ${check.status === 'adjusted' ? 'Đã điều chỉnh kho' : check.status === 'confirmed' ? 'Đã xác nhận' : 'Dự thảo'}`;
  const ws = createReportSheet('BIÊN BẢN KIỂM KÊ THUỐC VÀ VẬT TƯ Y TẾ', filterStr, headers, rows, summaryRow);
  downloadWorkbook(ws, 'Kiem_Ke', `Bien_Ban_Kiem_Ke_${check.checkCode}_${getFilenameDate()}.xlsx`);
}

// Alias for StockBalanceComponent
export const exportStockInOutBalanceExcel = exportInOutBalanceExcel;
