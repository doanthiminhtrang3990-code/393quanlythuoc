import { InventoryCheck, InventoryTransaction, MedicineBatch, StockInOutBalanceRow } from '../types';
import { formatDateVN, formatVND } from '../utils/helpers';

interface PrintHeaderConfig {
  schoolName?: string;
  department?: string;
  title: string;
  subtitle?: string;
  code?: string;
}

function openPrintWindow(htmlContent: string, landscape = false) {
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Vui lòng cho phép popup trên trình duyệt để in hoặc xuất PDF mẫu sổ A4.');
    return;
  }

  const orientation = landscape ? 'landscape' : 'portrait';

  const fullHtml = `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>In Mẫu Sổ A4 - Trường THCS Đông Thạnh</title>
  <style>
    @page {
      size: A4 ${orientation};
      margin: 12mm 15mm 15mm 15mm;
    }
    * {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    body {
      font-family: "Times New Roman", Times, serif, Arial, sans-serif;
      font-size: 11pt;
      line-height: 1.35;
      color: #000;
      background: #fff;
      margin: 0;
      padding: 10px;
    }
    .print-actions {
      text-align: center;
      margin-bottom: 20px;
      padding: 10px;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
    }
    .print-actions button {
      background: #0284c7;
      color: #fff;
      border: none;
      padding: 8px 18px;
      font-size: 14px;
      font-weight: bold;
      border-radius: 4px;
      cursor: pointer;
      margin: 0 6px;
    }
    .print-actions button.close {
      background: #64748b;
    }
    @media print {
      .print-actions {
        display: none !important;
      }
      body {
        padding: 0;
      }
    }
    .header-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 15px;
    }
    .header-table td {
      vertical-align: top;
      border: none;
      padding: 2px 0;
    }
    .header-left {
      text-align: center;
      width: 45%;
    }
    .header-right {
      text-align: center;
      width: 55%;
    }
    .unit-name {
      font-size: 10.5pt;
      text-transform: uppercase;
      font-weight: bold;
    }
    .school-name {
      font-size: 11pt;
      text-transform: uppercase;
      font-weight: bold;
      color: #000;
    }
    .divider-line {
      width: 120px;
      height: 1px;
      background: #000;
      margin: 4px auto 0 auto;
    }
    .national-title {
      font-size: 11pt;
      font-weight: bold;
      text-transform: uppercase;
    }
    .national-motto {
      font-size: 11pt;
      font-weight: bold;
      font-style: italic;
    }
    .doc-title {
      text-align: center;
      font-size: 15pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 15px 0 4px 0;
    }
    .doc-subtitle {
      text-align: center;
      font-size: 11pt;
      font-style: italic;
      margin-bottom: 12px;
    }
    .meta-box {
      margin-bottom: 12px;
      font-size: 11pt;
    }
    .meta-box p {
      margin: 4px 0;
    }
    table.data-table {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0;
      font-size: 10pt;
    }
    table.data-table th,
    table.data-table td {
      border: 1px solid #000;
      padding: 5px 6px;
      vertical-align: middle;
    }
    table.data-table th {
      background-color: #e2e8f0;
      font-weight: bold;
      text-align: center;
    }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .text-left { text-align: left; }
    .font-bold { font-weight: bold; }
    .signatures-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 25px;
      page-break-inside: avoid;
    }
    .signatures-table td {
      border: none;
      vertical-align: top;
      text-align: center;
      width: 33.33%;
      padding: 4px;
    }
    .signature-title {
      font-weight: bold;
      font-size: 10.5pt;
      text-transform: uppercase;
      margin-bottom: 3px;
    }
    .signature-sub {
      font-style: italic;
      font-size: 9.5pt;
      color: #333;
    }
    .signature-space {
      height: 70px;
    }
    .signature-name {
      font-weight: bold;
      font-size: 10.5pt;
    }
  </style>
</head>
<body>
  <div class="print-actions">
    <button onclick="window.print()">🖨️ In Mẫu Sổ / Xuất PDF (A4)</button>
    <button class="close" onclick="window.close()">Đóng Cửa Sổ</button>
  </div>
  ${htmlContent}
</body>
</html>`;

  printWindow.document.open();
  printWindow.document.write(fullHtml);
  printWindow.document.close();
}

function renderHeader(config: PrintHeaderConfig) {
  const now = new Date();
  return `
    <table class="header-table">
      <tr>
        <td class="header-left">
          <div class="unit-name">PHÒNG GD&ĐT HUYỆN HÓC MÔN</div>
          <div class="school-name">${config.schoolName || 'TRƯỜNG THCS ĐÔNG THẠNH'}</div>
          <div>Bộ phận: ${config.department || 'Y TẾ HỌC ĐƯỜNG'}</div>
          <div class="divider-line"></div>
        </td>
        <td class="header-right">
          <div class="national-title">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</div>
          <div class="national-motto">Độc lập - Tự do - Hạnh phúc</div>
          <div class="divider-line"></div>
          <div style="font-style: italic; font-size: 10pt; margin-top: 6px;">
            Đông Thạnh, ngày ${now.getDate()} tháng ${now.getMonth() + 1} năm ${now.getFullYear()}
          </div>
        </td>
      </tr>
    </table>
    <div class="doc-title">${config.title}</div>
    ${config.subtitle ? `<div class="doc-subtitle">${config.subtitle}</div>` : ''}
    ${config.code ? `<div style="text-align: center; font-weight: bold; margin-bottom: 8px;">Mã số: ${config.code}</div>` : ''}
  `;
}

// 1. In Sổ Nhập - Xuất - Tồn A4 Landscape
export function printStockBalanceA4(
  rows: StockInOutBalanceRow[],
  periodLabel: string,
  schoolName = 'TRƯỜNG THCS ĐÔNG THẠNH'
) {
  const content = `
    ${renderHeader({
      schoolName,
      title: 'SỔ THEO DÕI NHẬP - XUẤT - TỒN THUỐC VÀ VẬT TƯ Y TẾ',
      subtitle: `Kỳ báo cáo: ${periodLabel}`,
    })}

    <table class="data-table">
      <thead>
        <tr>
          <th rowspan="2" style="width: 35px;">STT</th>
          <th rowspan="2" style="width: 80px;">Mã thuốc</th>
          <th rowspan="2">Tên thuốc, nồng độ, hàm lượng</th>
          <th rowspan="2" style="width: 75px;">Số lô</th>
          <th rowspan="2" style="width: 75px;">Hạn dùng</th>
          <th rowspan="2" style="width: 50px;">ĐVT</th>
          <th rowspan="2" style="width: 60px;">Tồn đầu kỳ</th>
          <th colspan="2">Phát sinh trong kỳ</th>
          <th rowspan="2" style="width: 60px;">Điều chỉnh</th>
          <th rowspan="2" style="width: 60px;">Tồn cuối kỳ</th>
          <th rowspan="2" style="width: 90px;">Vị trí lưu trữ</th>
        </tr>
        <tr>
          <th style="width: 60px;">Nhập (+)</th>
          <th style="width: 60px;">Xuất (-)</th>
        </tr>
      </thead>
      <tbody>
        ${rows
          .map(
            (r, i) => `
          <tr>
            <td class="text-center">${i + 1}</td>
            <td class="text-center font-bold">${r.medicineCode}</td>
            <td>${r.medicineName}</td>
            <td class="text-center font-bold">${r.batchNumber}</td>
            <td class="text-center">${formatDateVN(r.expDate)}</td>
            <td class="text-center">${r.unit}</td>
            <td class="text-right font-bold">${r.openingStock}</td>
            <td class="text-right" style="color: #047857;">${r.importQuantity > 0 ? '+' + r.importQuantity : '0'}</td>
            <td class="text-right" style="color: #b91c1c;">${r.exportQuantity > 0 ? '-' + r.exportQuantity : '0'}</td>
            <td class="text-right">${r.adjustmentQuantity !== 0 ? (r.adjustmentQuantity > 0 ? '+' + r.adjustmentQuantity : r.adjustmentQuantity) : '0'}</td>
            <td class="text-right font-bold" style="background: #f8fafc;">${r.closingStock}</td>
            <td class="text-left" style="font-size: 9pt;">${r.notes || 'Tủ thuốc y tế'}</td>
          </tr>
        `
          )
          .join('')}
      </tbody>
      <tfoot>
        <tr style="font-weight: bold; background: #f1f5f9;">
          <td colspan="6" class="text-center">TỔNG CỘNG (${rows.length} mục)</td>
          <td class="text-right">${rows.reduce((s, r) => s + r.openingStock, 0)}</td>
          <td class="text-right">${rows.reduce((s, r) => s + r.importQuantity, 0)}</td>
          <td class="text-right">${rows.reduce((s, r) => s + r.exportQuantity, 0)}</td>
          <td class="text-right">${rows.reduce((s, r) => s + r.adjustmentQuantity, 0)}</td>
          <td class="text-right font-bold">${rows.reduce((s, r) => s + r.closingStock, 0)}</td>
          <td></td>
        </tr>
      </tfoot>
    </table>

    <table class="signatures-table">
      <tr>
        <td>
          <div class="signature-title">NGƯỜI LẬP SỔ</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Cán bộ Y tế học đường</div>
        </td>
        <td>
          <div class="signature-title">KẾ TOÁN / THỦ KHO</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Đại diện kiểm soát</div>
        </td>
        <td>
          <div class="signature-title">HIỆU TRƯỞNG</div>
          <div class="signature-sub">(Ký, đóng dấu và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Ban Giám Hiệu Nhà Trường</div>
        </td>
      </tr>
    </table>
  `;

  openPrintWindow(content, true); // Landscape for wide tables
}

// 2. In Biên Bản Kiểm Kê A4 Portrait
export function printInventoryCheckA4(check: InventoryCheck, schoolName = 'TRƯỜNG THCS ĐÔNG THẠNH') {
  const content = `
    ${renderHeader({
      schoolName,
      title: 'BIÊN BẢN KIỂM KÊ THUỐC VÀ VẬT TƯ Y TẾ',
      subtitle: `Thời điểm kiểm kê: ${check.checkTime || '---'}, ngày ${formatDateVN(check.checkDate)}`,
      code: check.checkCode,
    })}

    <div class="meta-box">
      <p><strong>1. Hội đồng kiểm kê gồm có:</strong></p>
      <ul style="margin: 4px 0 10px 20px; padding: 0;">
        ${(check.participants || ['Cán bộ Y tế học đường', 'Ban Giám Hiệu', 'Đại diện kế toán'])
          .map((p) => `<li>${p}</li>`)
          .join('')}
      </ul>
      <p><strong>2. Người lập biên bản:</strong> ${check.performer}</p>
      <p><strong>3. Trạng thái biên bản:</strong> ${
        check.status === 'adjusted'
          ? 'ĐÃ ĐIỀU CHỈNH TỒN KHO THỰC TẾ'
          : check.status === 'confirmed'
          ? 'ĐÃ XÁC NHẬN BỞI BAN KIỂM KÊ'
          : 'DỰ THẢO / ĐANG XỬ LÝ'
      } ${check.confirmedBy ? `(Người duyệt: ${check.confirmedBy})` : ''}</p>
      ${check.notes ? `<p><strong>4. Nhận xét / Đề xuất:</strong> ${check.notes}</p>` : ''}
    </div>

    <table class="data-table">
      <thead>
        <tr>
          <th style="width: 35px;">STT</th>
          <th style="width: 75px;">Mã thuốc</th>
          <th>Tên thuốc / Nồng độ</th>
          <th style="width: 75px;">Số lô</th>
          <th style="width: 75px;">Hạn dùng</th>
          <th style="width: 50px;">ĐVT</th>
          <th style="width: 60px;">Tồn sổ sách</th>
          <th style="width: 60px;">Thực kiểm</th>
          <th style="width: 60px;">Chênh lệch</th>
          <th style="width: 80px;">Chất lượng</th>
          <th>Lý do chênh lệch & Xử lý</th>
        </tr>
      </thead>
      <tbody>
        ${check.items
          .map(
            (it, i) => `
          <tr ${it.difference !== 0 ? 'style="background: #fffbeb;"' : ''}>
            <td class="text-center">${i + 1}</td>
            <td class="text-center font-bold">${it.medicineCode}</td>
            <td>${it.medicineName}</td>
            <td class="text-center font-bold">${it.batchNumber}</td>
            <td class="text-center">${formatDateVN(it.expDate)}</td>
            <td class="text-center">${it.unit}</td>
            <td class="text-right">${it.bookQuantity}</td>
            <td class="text-right font-bold">${it.actualQuantity}</td>
            <td class="text-right font-bold" style="color: ${it.difference < 0 ? '#dc2626' : it.difference > 0 ? '#16a34a' : '#000'};">
              ${it.difference > 0 ? '+' + it.difference : it.difference}
            </td>
            <td class="text-center">${it.qualityStatus === 'damaged' ? 'Hỏng/kém phẩm chất' : it.qualityStatus === 'expired' ? 'Hết hạn' : 'Tốt'}</td>
            <td style="font-size: 9pt;">${it.reason || (it.difference === 0 ? 'Khớp số liệu' : 'Cần rà soát')}</td>
          </tr>
        `
          )
          .join('')}
      </tbody>
      <tfoot>
        <tr style="font-weight: bold; background: #f1f5f9;">
          <td colspan="6" class="text-center">TỔNG CỘNG</td>
          <td class="text-right">${check.items.reduce((s, it) => s + it.bookQuantity, 0)}</td>
          <td class="text-right">${check.items.reduce((s, it) => s + it.actualQuantity, 0)}</td>
          <td class="text-right">${check.items.reduce((s, it) => s + it.difference, 0)}</td>
          <td colspan="2" class="text-center">Số mục lệch: ${check.items.filter((it) => it.difference !== 0).length}</td>
        </tr>
      </tfoot>
    </table>

    <table class="signatures-table">
      <tr>
        <td>
          <div class="signature-title">CÁN BỘ Y TẾ</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">${check.performer}</div>
        </td>
        <td>
          <div class="signature-title">ĐẠI DIỆN HỘI ĐỒNG KIỂM KÊ</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Thành viên Ban kiểm kê</div>
        </td>
        <td>
          <div class="signature-title">HIỆU TRƯỞNG</div>
          <div class="signature-sub">(Ký, đóng dấu và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">${check.confirmedBy || 'Ban Giám Hiệu'}</div>
        </td>
      </tr>
    </table>
  `;

  openPrintWindow(content, false); // Portrait
}

// 3. In Phiếu Nhập / Phiếu Xuất A4 Portrait
export function printTransactionA4(tx: InventoryTransaction, schoolName = 'TRƯỜNG THCS ĐÔNG THẠNH') {
  const isImport = tx.type === 'import';
  const title = isImport ? 'PHIẾU NHẬP KHO THUỐC VÀ VẬT TƯ Y TẾ' : 'PHIẾU XUẤT / CẤP PHÁT THUỐC HỌC ĐƯỜNG';

  const content = `
    ${renderHeader({
      schoolName,
      title,
      subtitle: `Ngày thực hiện: ${formatDateVN(tx.date)}`,
      code: tx.transactionCode,
    })}

    <div class="meta-box">
      ${
        isImport
          ? `
        <p><strong>Nguồn cấp / Đơn vị cung cấp:</strong> ${tx.source || 'Nhà thuốc / Trung tâm y tế'}</p>
        <p><strong>Người giao hàng:</strong> ${tx.deliverer || 'Đại diện nhà cung ứng'} | <strong>Người nhận:</strong> ${tx.receiver || tx.performer}</p>
        <p><strong>Cán bộ y tế lập phiếu:</strong> ${tx.performer}</p>
      `
          : `
        <p><strong>Họ và tên người nhận / sử dụng:</strong> ${tx.recipientName || '---'} ${tx.recipientClass ? `(Lớp: ${tx.recipientClass})` : ''}</p>
        <p><strong>Đối tượng:</strong> ${tx.recipientType === 'student' ? 'Học sinh' : tx.recipientType === 'teacher' ? 'Giáo viên' : 'Cán bộ / Khác'}</p>
        <p><strong>Lý do / Mục đích cấp phát:</strong> ${tx.purpose || 'Xử lý sơ cấp cứu học sinh'}</p>
        <p><strong>Cán bộ y tế thực hiện:</strong> ${tx.performer}</p>
      `
      }
      ${tx.notes ? `<p><strong>Ghi chú:</strong> ${tx.notes}</p>` : ''}
    </div>

    <table class="data-table">
      <thead>
        <tr>
          <th style="width: 35px;">STT</th>
          <th style="width: 80px;">Mã thuốc</th>
          <th>Tên thuốc, nồng độ, quy cách</th>
          <th style="width: 80px;">Số lô</th>
          <th style="width: 80px;">Hạn sử dụng</th>
          <th style="width: 50px;">ĐVT</th>
          <th style="width: 65px;">Số lượng</th>
          <th style="width: 85px;">Đơn giá</th>
          <th style="width: 95px;">Thành tiền</th>
        </tr>
      </thead>
      <tbody>
        ${tx.items
          .map(
            (it, i) => `
          <tr>
            <td class="text-center">${i + 1}</td>
            <td class="text-center font-bold">${it.medicineCode}</td>
            <td>${it.medicineName}</td>
            <td class="text-center font-bold">${it.batchNumber}</td>
            <td class="text-center">${formatDateVN(it.expDate || '')}</td>
            <td class="text-center">${it.unit}</td>
            <td class="text-right font-bold">${it.quantity}</td>
            <td class="text-right">${formatVND(it.unitPrice)}</td>
            <td class="text-right font-bold">${formatVND(it.totalAmount)}</td>
          </tr>
        `
          )
          .join('')}
      </tbody>
      <tfoot>
        <tr style="font-weight: bold; background: #f1f5f9;">
          <td colspan="6" class="text-center">TỔNG CỘNG</td>
          <td class="text-right">${tx.items.reduce((s, it) => s + it.quantity, 0)}</td>
          <td></td>
          <td class="text-right font-bold">${formatVND(tx.totalAmount)}</td>
        </tr>
      </tfoot>
    </table>

    <table class="signatures-table">
      <tr>
        <td>
          <div class="signature-title">${isImport ? 'NGƯỜI GIAO HÀNG' : 'NGƯỜI NHẬN THUỐC'}</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">${isImport ? tx.deliverer || 'Đại diện nhà xe/NCC' : tx.recipientName || 'Người nhận'}</div>
        </td>
        <td>
          <div class="signature-title">CÁN BỘ Y TẾ</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">${tx.performer}</div>
        </td>
        <td>
          <div class="signature-title">BAN GIÁM HIỆU</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Hiệu Trưởng duyệt</div>
        </td>
      </tr>
    </table>
  `;

  openPrintWindow(content, false);
}

// 4. In Báo Cáo Hạn Sử Dụng / Đề Nghị Tiêu Hủy A4 Portrait
export function printExpiryReportA4(
  batches: (MedicineBatch & { medicineName?: string; unit?: string; medicineCode?: string })[],
  reportType: 'expired' | 'expiring_soon',
  schoolName = 'TRƯỜNG THCS ĐÔNG THẠNH'
) {
  const isExpired = reportType === 'expired';
  const title = isExpired
    ? 'DANH SÁCH THUỐC HẾT HẠN SỬ DỤNG - ĐỀ NGHỊ TIÊU HỦY'
    : 'DANH SÁCH THUỐC CẢNH BÁO SẮP HẾT HẠN DÙNG (CẦN ƯU TIÊN SỬ DỤNG)';

  const content = `
    ${renderHeader({
      schoolName,
      title,
      subtitle: `Thời điểm xuất báo cáo: ${formatDateVN(new Date().toISOString().split('T')[0])}`,
    })}

    <div class="meta-box">
      <p>Căn cứ quy chế quản lý thuốc và trang thiết bị y tế học đường hiện hành;</p>
      <p>Bộ phận Y tế học đường kính trình Ban Giám Hiệu danh sách các mặt hàng thuốc ${
        isExpired ? 'đã hết hạn sử dụng cần thực hiện niêm phong và tiêu hủy' : 'sắp hết hạn dùng cần ưu tiên cấp phát theo nguyên tắc FEFO'
      }:</p>
    </div>

    <table class="data-table">
      <thead>
        <tr>
          <th style="width: 35px;">STT</th>
          <th style="width: 75px;">Mã thuốc</th>
          <th>Tên thuốc / Hoạt chất</th>
          <th style="width: 80px;">Số lô</th>
          <th style="width: 80px;">Hạn dùng</th>
          <th style="width: 50px;">ĐVT</th>
          <th style="width: 65px;">Số lượng</th>
          <th style="width: 85px;">Đơn giá</th>
          <th style="width: 95px;">Giá trị</th>
          <th>Đề xuất xử lý</th>
        </tr>
      </thead>
      <tbody>
        ${batches
          .map(
            (b, i) => `
          <tr>
            <td class="text-center">${i + 1}</td>
            <td class="text-center font-bold">${b.medicineCode || '---'}</td>
            <td>${b.medicineName || 'Thuốc'}</td>
            <td class="text-center font-bold">${b.batchNumber}</td>
            <td class="text-center font-bold" style="color: #dc2626;">${formatDateVN(b.expDate)}</td>
            <td class="text-center">${b.unit || 'Đơn vị'}</td>
            <td class="text-right font-bold">${b.quantity}</td>
            <td class="text-right">${formatVND(b.unitPrice || 0)}</td>
            <td class="text-right font-bold">${formatVND(b.quantity * (b.unitPrice || 0))}</td>
            <td style="font-size: 9pt;">${isExpired ? 'Niêm phong chờ tiêu hủy' : 'Ưu tiên xuất theo FEFO'}</td>
          </tr>
        `
          )
          .join('')}
      </tbody>
      <tfoot>
        <tr style="font-weight: bold; background: #f1f5f9;">
          <td colspan="6" class="text-center">TỔNG CỘNG (${batches.length} lô)</td>
          <td class="text-right">${batches.reduce((s, b) => s + b.quantity, 0)}</td>
          <td></td>
          <td class="text-right font-bold">${formatVND(batches.reduce((s, b) => s + b.quantity * (b.unitPrice || 0), 0))}</td>
          <td></td>
        </tr>
      </tfoot>
    </table>

    <table class="signatures-table">
      <tr>
        <td>
          <div class="signature-title">CÁN BỘ Y TẾ</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Người lập danh sách</div>
        </td>
        <td>
          <div class="signature-title">ĐẠI DIỆN CÔNG ĐOÀN / THANH TRA</div>
          <div class="signature-sub">(Ký và ghi rõ họ tên)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Thành viên giám sát</div>
        </td>
        <td>
          <div class="signature-title">HIỆU TRƯỞNG</div>
          <div class="signature-sub">(Ký, đóng dấu duyệt phương án)</div>
          <div class="signature-space"></div>
          <div class="signature-name">Ban Giám Hiệu Nhà Trường</div>
        </td>
      </tr>
    </table>
  `;

  openPrintWindow(content, false);
}
