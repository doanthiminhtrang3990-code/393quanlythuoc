import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { User, UserRole } from '../types';

const app = initializeApp(firebaseConfig);
export const dbFirestore = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = async () => {
  const result = await signInWithPopup(auth, googleProvider);
  const user = result.user;
  
  // Check if user exists in Firestore
  const userRef = doc(dbFirestore, 'users', user.uid);
  const userSnap = await getDoc(userRef);
  
  const isAdminEmail = user.email === 'minhtrangdongthanh@gmail.com';
  const role = isAdminEmail ? 'admin' : 'medic';

  if (!userSnap.exists()) {
    const newUser: User = {
      id: user.uid,
      username: user.email?.split('@')[0] || 'user',
      fullName: user.displayName || 'Unknown User',
      email: user.email || '',
      role: role,
    };
    await setDoc(userRef, newUser);
    return newUser;
  } else {
    // If they exist but need to be upgraded to admin
    const userData = userSnap.data() as User;
    if (isAdminEmail && userData.role !== 'admin') {
      const { updateDoc } = await import('firebase/firestore');
      await updateDoc(userRef, { role: 'admin' });
      userData.role = 'admin';
    }
    return userData;
  }
};

export const getUsers = async (): Promise<User[]> => {
  try {
    const { collection, getDocs } = await import('firebase/firestore');
    const usersRef = collection(dbFirestore, 'users');
    const snap = await getDocs(usersRef);
    return snap.docs.map(doc => doc.data() as User);
  } catch (err) {
    console.warn('Could not fetch users from Firebase:', err);
    return [];
  }
};

export const updateUserRole = async (userId: string, newRole: UserRole, fullUser?: Partial<User>): Promise<void> => {
  try {
    const { getDoc, setDoc } = await import('firebase/firestore');
    const userRef = doc(dbFirestore, 'users', userId);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      const existing = snap.data();
      await setDoc(userRef, {
        id: existing.id || userId,
        username: existing.username || fullUser?.username || 'user',
        fullName: existing.fullName || fullUser?.fullName || 'Người dùng',
        email: existing.email || fullUser?.email || '',
        role: newRole,
      });
    } else if (fullUser) {
      await setDoc(userRef, {
        id: userId,
        username: fullUser.username || 'user',
        fullName: fullUser.fullName || 'Người dùng',
        email: fullUser.email || '',
        role: newRole,
      });
    }
  } catch (err) {
    console.error('Error updating user role in Firebase:', err);
    throw err;
  }
};

export const saveUserToFirebase = async (userData: User): Promise<void> => {
  try {
    const { setDoc } = await import('firebase/firestore');
    const userRef = doc(dbFirestore, 'users', userData.id);
    await setDoc(userRef, {
      id: userData.id,
      username: userData.username || 'user',
      fullName: userData.fullName || 'Người dùng',
      email: userData.email || '',
      role: userData.role,
    }, { merge: true });
  } catch (err) {
    console.warn('Could not save user to Firebase:', err);
  }
};

export const logout = () => signOut(auth);
