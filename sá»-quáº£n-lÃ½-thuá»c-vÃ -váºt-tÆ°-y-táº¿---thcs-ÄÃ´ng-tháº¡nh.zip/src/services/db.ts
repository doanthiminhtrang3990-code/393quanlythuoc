import {
  Medicine,
  MedicineBatch,
  InventoryTransaction,
  Supplier,
  MedicalSupply,
  UsageRecord,
  InventoryCheck,
  AuditLog,
  AppSettings,
  MedicineStatus,
  ExpiryAlertLevel,
  StockBalanceItem,
  StockInOutBalanceRow,
  DataIntegrityIssue,
  User,
  UserRole,
  UserPermission,
  Student,
  StudentHealthProfile,
  ClinicVisit,
  ClinicVisitMedicineUsage,
  ClinicVisitSupplyUsage,
  HealthEvent,
  HealthCheckup,
  SchoolClass,
} from '../types';
import {
  DEFAULT_CLASSES,
  INITIAL_STUDENTS,
  INITIAL_HEALTH_PROFILES,
  INITIAL_CLINIC_VISITS,
  INITIAL_HEALTH_EVENTS,
  INITIAL_HEALTH_CHECKUPS,
  CLINIC_REASONS,
  CLINIC_TREATMENTS,
} from './studentData';

const STORAGE_KEYS = {
  MEDICINES: 'thcs_dongthanh_medicines_v1',
  BATCHES: 'thcs_dongthanh_batches_v1',
  TRANSACTIONS: 'thcs_dongthanh_transactions_v1',
  SUPPLIERS: 'thcs_dongthanh_suppliers_v1',
  SUPPLIES: 'thcs_dongthanh_supplies_v1',
  USAGE_RECORDS: 'thcs_dongthanh_usage_v1',
  INVENTORY_CHECKS: 'thcs_dongthanh_checks_v1',
  AUDIT_LOGS: 'thcs_dongthanh_audit_v1',
  SETTINGS: 'thcs_dongthanh_settings_v1',
  USERS: 'thcs_dongthanh_users_v1',
  CURRENT_USER: 'thcs_dongthanh_current_user_v1',
  STUDENTS: 'thcs_dongthanh_students_v1',
  STUDENT_HEALTH_PROFILES: 'thcs_dongthanh_student_profiles_v1',
  CLINIC_VISITS: 'thcs_dongthanh_clinic_visits_v1',
  HEALTH_EVENTS: 'thcs_dongthanh_health_events_v1',
  HEALTH_CHECKUPS: 'thcs_dongthanh_health_checkups_v1',
  SCHOOL_CLASSES: 'thcs_dongthanh_school_classes_v1',
};

export const DEFAULT_SETTINGS: AppSettings = {
  schoolName: 'TRƯỜNG THCS ĐÔNG THẠNH',
  systemName: 'SỔ QUẢN LÝ THUỐC VÀ VẬT TƯ Y TẾ',
  warningExpiringDays: 30,
  warningNoticeDays: 60,
  clinicLocation: 'Phòng Y tế Học đường - Khu Hiệu Bộ',
  nurseInCharge: 'Đỗ Thị Mai Trang (Cán bộ Y tế học đường)',
};

export const DEFAULT_ROLE_PERMISSIONS: Record<UserRole, UserPermission> = {
  bgh: {
    canManageMedicine: true,
    canManageTransactions: true,
    canManageClinicVisits: true,
    canManageStudents: true,
    canManageInventoryCheck: true,
    canViewReports: true,
    canManageSettings: false,
    canApproveAudits: true,
  },
  admin: {
    canManageMedicine: true,
    canManageTransactions: true,
    canManageClinicVisits: true,
    canManageStudents: true,
    canManageInventoryCheck: true,
    canViewReports: true,
    canManageSettings: true,
    canApproveAudits: true,
  },
  medic: {
    canManageMedicine: true,
    canManageTransactions: true,
    canManageClinicVisits: true,
    canManageStudents: true,
    canManageInventoryCheck: true,
    canViewReports: true,
    canManageSettings: false,
    canApproveAudits: false,
  },
};

export const DEFAULT_USERS: User[] = [
  {
    id: 'usr-bgh',
    username: 'bgh_hieutruong',
    fullName: 'Ban Giám Hiệu (Thầy Hiệu Trưởng)',
    role: 'bgh',
    email: 'bgh.thcsdongthanh@edu.vn',
    phone: '0903 888 999',
    title: 'Hiệu Trưởng / Đại diện Lãnh đạo Trường',
    department: 'Ban Giám Hiệu',
    status: 'active',
    permissions: { ...DEFAULT_ROLE_PERMISSIONS.bgh },
    createdAt: '2026-01-05T08:00:00.000Z',
  },
  {
    id: 'usr-admin',
    username: 'admin_quantri',
    fullName: 'Quản Trị Viên Hệ Thống (IT Trường)',
    role: 'admin',
    email: 'quantri.dongthanh@edu.vn',
    phone: '0909 666 777',
    title: 'Phụ trách Quản trị Kỹ thuật & CNTT',
    department: 'Tổ CNTT & Cơ sở vật chất',
    status: 'active',
    permissions: { ...DEFAULT_ROLE_PERMISSIONS.admin },
    createdAt: '2026-01-05T08:00:00.000Z',
  },
  {
    id: 'usr-medic',
    username: 'yte_maitrang',
    fullName: 'Đỗ Thị Mai Trang (Nhân viên Y tế)',
    role: 'medic',
    email: 'yte.dongthanh@gmail.com',
    phone: '0908 123 456',
    title: 'Nhân viên Chuyên trách Y tế trường học',
    department: 'Phòng Y tế Học đường',
    status: 'active',
    permissions: { ...DEFAULT_ROLE_PERMISSIONS.medic },
    createdAt: '2026-01-08T08:00:00.000Z',
  },
  {
    id: 'usr-medic-2',
    username: 'yte_thanhthao',
    fullName: 'Lê Thanh Thảo (Cán bộ hỗ trợ)',
    role: 'medic',
    email: 'thanhthao.yhoc@gmail.com',
    phone: '0912 345 678',
    title: 'Nhân viên Hỗ trợ Y tế & Kiểm kê',
    department: 'Phòng Y tế Học đường',
    status: 'active',
    permissions: { ...DEFAULT_ROLE_PERMISSIONS.medic },
    createdAt: '2026-02-15T08:00:00.000Z',
  },
];

export function getRoleLabel(role: UserRole): string {
  switch (role) {
    case 'bgh':
      return 'Ban Giám Hiệu';
    case 'admin':
      return 'Quản Trị Viên';
    case 'medic':
      return 'Nhân Viên Y Tế';
    default:
      return 'Nhân Viên Y Tế';
  }
}

export const DEFAULT_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-01',
    code: 'NCC-DHG',
    name: 'Công ty Cổ phần Dược phẩm Hậu Giang (DHG Pharma)',
    phone: '0292 3891 433',
    address: '288 Bis Nguyễn Văn Cừ, P. An Hòa, TP. Cần Thơ',
    contactPerson: 'Trần Văn Cường (Trình dược viên)',
    notes: 'Nhà cung cấp thuốc thiết yếu chính ngạch',
  },
  {
    id: 'sup-02',
    code: 'NCC-TTYT',
    name: 'Trung tâm Y tế Huyện Hóc Môn (Cấp theo chương trình YTHĐ)',
    phone: '028 3891 0244',
    address: 'Bà Triệu, Thị trấn Hóc Môn, Hóc Môn, TP. Hồ Chí Minh',
    contactPerson: 'Bs. Nguyễn Thanh Hà (Phụ trách Y tế học đường)',
    notes: 'Nguồn cấp ngân sách Nhà nước và thuốc sơ cứu học đường',
  },
  {
    id: 'sup-03',
    code: 'NCC-MED',
    name: 'Công ty TNHH Thiết Bị & Vật Tư Y Tế Sài Gòn',
    phone: '028 3927 8899',
    address: 'Quận 10, TP. Hồ Chí Minh',
    contactPerson: 'Lê Hoàng Oanh',
    notes: 'Cung cấp găng tay, nhiệt kế, bông băng, gạc tiệt trùng',
  },
];

// Initial realistic demo medicines
export const INITIAL_MEDICINES: Medicine[] = [
  {
    id: 'med-01',
    code: 'TH-PARA500',
    name: 'Paracetamol 500mg (Hapacol)',
    activeIngredient: 'Paracetamol',
    dosageForm: 'Viên nén bao phim',
    strength: '500mg',
    unit: 'Viên',
    packing: 'Hộp 10 vỉ x 10 viên',
    manufacturer: 'DHG Pharma',
    country: 'Việt Nam',
    supplierId: 'sup-01',
    minStock: 30,
    unitPrice: 1200,
    storageLocation: 'Tủ A - Ngăn 1 (Thuốc giảm đau hạ sốt)',
    notes: 'Dùng hạ sốt > 38.5 độ hoặc đau đầu nhẹ cho học sinh THCS',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
  {
    id: 'med-02',
    code: 'TH-ORES245',
    name: 'Oresol 245mg (Bột bù nước điện giải)',
    activeIngredient: 'Glucose, Natri clorid, Kali clorid, Natri citrat',
    dosageForm: 'Bột pha dung dịch uống',
    strength: 'Gói 4.1g / 200ml',
    unit: 'Gói',
    packing: 'Hộp 20 gói',
    manufacturer: 'Dược phẩm OPC',
    country: 'Việt Nam',
    supplierId: 'sup-01',
    minStock: 25,
    unitPrice: 2500,
    storageLocation: 'Tủ A - Ngăn 2',
    notes: 'Bù nước khi học sinh sốt, say nắng hoạt động thể dục, tiêu chảy',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
  {
    id: 'med-03',
    code: 'TH-POVI10',
    name: 'Povidone Iodine 10% 20ml',
    activeIngredient: 'Povidone Iodine',
    dosageForm: 'Dung dịch sát khuẩn',
    strength: '10% (20ml)',
    unit: 'Chai',
    packing: 'Chai nhựa 20ml',
    manufacturer: 'Dược phẩm Pharmedic',
    country: 'Việt Nam',
    supplierId: 'sup-02',
    minStock: 6,
    unitPrice: 8500,
    storageLocation: 'Tủ C - Ngăn sát trùng ngoài da',
    notes: 'Sát khuẩn vết thương xây xát khi học sinh ngã, trầy da',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
  {
    id: 'med-04',
    code: 'TH-NACL09',
    name: 'Nước muối sinh lý Natri Clorid 0.9% 10ml',
    activeIngredient: 'Natri clorid 0.9%',
    dosageForm: 'Dung dịch nhỏ mắt mũi',
    strength: '0.9% (10ml)',
    unit: 'Lọ',
    packing: 'Hộp 10 lọ x 10ml',
    manufacturer: 'Pharmedic',
    country: 'Việt Nam',
    supplierId: 'sup-01',
    minStock: 20,
    unitPrice: 4000,
    storageLocation: 'Tủ B - Ngăn nhỏ mắt mũi',
    notes: 'Rửa bụi bẩn mắt, vệ sinh mũi họng',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
  {
    id: 'med-05',
    code: 'TH-BERB50',
    name: 'Berberin Clorid 50mg',
    activeIngredient: 'Berberin clorid',
    dosageForm: 'Viên bao vàng',
    strength: '50mg',
    unit: 'Viên',
    packing: 'Lọ 100 viên',
    manufacturer: 'Dược Nam Hà',
    country: 'Việt Nam',
    supplierId: 'sup-01',
    minStock: 40,
    unitPrice: 600,
    storageLocation: 'Tủ A - Ngăn tiêu hóa',
    notes: 'Đau bụng, rối loạn tiêu hóa nhẹ',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
  {
    id: 'med-06',
    code: 'TH-DAUGIO',
    name: 'Dầu xoa bóp Bạc Hà Con Én 5ml',
    activeIngredient: 'Menthol, Tinh dầu Bạc hà',
    dosageForm: 'Chai xoa',
    strength: '5ml',
    unit: 'Chai',
    packing: 'Chai thủy tinh 5ml',
    manufacturer: 'OPC Pharma',
    country: 'Việt Nam',
    supplierId: 'sup-01',
    minStock: 5,
    unitPrice: 15000,
    storageLocation: 'Tủ A - Ngăn ngoài',
    notes: 'Dùng thoa trán, thái dương khi trúng gió, choáng váng',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
  {
    id: 'med-07',
    code: 'TH-CON70',
    name: 'Cồn y tế Ethanol 70 độ 500ml',
    activeIngredient: 'Ethanol 70%',
    dosageForm: 'Dung dịch sát khuẩn',
    strength: '70 độ (500ml)',
    unit: 'Chai',
    packing: 'Chai 500ml',
    manufacturer: 'Vĩnh Phúc',
    country: 'Việt Nam',
    supplierId: 'sup-03',
    minStock: 5,
    unitPrice: 22000,
    storageLocation: 'Kệ dưới tủ sát trùng',
    notes: 'Sát khuẩn kéo, nhíp, dụng cụ sơ cứu (không đổ trực tiếp lên vết thương hở sâu)',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
  {
    id: 'med-08',
    code: 'TH-VITAC500',
    name: 'Vitamin C 500mg sủi',
    activeIngredient: 'Acid ascorbic',
    dosageForm: 'Viên sủi bọt',
    strength: '500mg',
    unit: 'Tuýp',
    packing: 'Tuýp 10 viên',
    manufacturer: 'DHG Pharma',
    country: 'Việt Nam',
    supplierId: 'sup-01',
    minStock: 10,
    unitPrice: 28000,
    storageLocation: 'Tủ A - Ngăn vitamin',
    notes: 'Bổ sung sức đề kháng khi mệt lả',
    isDemo: true,
    createdAt: '2026-08-15T08:00:00.000Z',
    updatedAt: '2026-08-15T08:00:00.000Z',
  },
];

// Initial batches showing different scenarios:
// Today is ~ Sept 2026.
// Some batches expiring soon (within 30 days), some expired in Aug 2026, some long shelf-life.
export const INITIAL_BATCHES: MedicineBatch[] = [
  // Paracetamol: 2 batches (FEFO demonstration)
  {
    id: 'batch-p01',
    medicineId: 'med-01',
    batchNumber: 'L2408-A',
    mfgDate: '2024-08-10',
    expDate: '2026-10-05', // Còn ~21 ngày -> SẮP HẾT HẠN (Cảnh báo 30 ngày)
    quantity: 45,
    initialQuantity: 100,
    unitPrice: 1200,
    supplierId: 'sup-01',
    storageLocation: 'Tủ A - Ngăn 1',
    isDemo: true,
  },
  {
    id: 'batch-p02',
    medicineId: 'med-01',
    batchNumber: 'L2503-B',
    mfgDate: '2025-03-15',
    expDate: '2027-09-20', // Còn an toàn > 1 năm
    quantity: 180,
    initialQuantity: 200,
    unitPrice: 1200,
    supplierId: 'sup-01',
    storageLocation: 'Tủ A - Ngăn 1',
    isDemo: true,
  },
  // Oresol: 1 expired batch (ĐÃ HẾT HẠN) + 1 safe batch
  {
    id: 'batch-or01',
    medicineId: 'med-02',
    batchNumber: 'OR-2308',
    mfgDate: '2023-08-01',
    expDate: '2026-08-15', // ĐÃ HẾT HẠN (Quá hạn 1 tháng)
    quantity: 12,
    initialQuantity: 50,
    unitPrice: 2500,
    supplierId: 'sup-01',
    storageLocation: 'Tủ A - Ngăn cách ly chờ tiêu hủy',
    isDemo: true,
  },
  {
    id: 'batch-or02',
    medicineId: 'med-02',
    batchNumber: 'OR-2412',
    mfgDate: '2024-12-01',
    expDate: '2027-05-30',
    quantity: 65,
    initialQuantity: 100,
    unitPrice: 2500,
    supplierId: 'sup-01',
    storageLocation: 'Tủ A - Ngăn 2',
    isDemo: true,
  },
  // Povidone Iodine 10%: Total quantity = 4 (minStock is 6) -> SẮP HẾT
  {
    id: 'batch-pv01',
    medicineId: 'med-03',
    batchNumber: 'PV-2405',
    mfgDate: '2024-05-10',
    expDate: '2027-05-10',
    quantity: 4,
    initialQuantity: 20,
    unitPrice: 8500,
    supplierId: 'sup-02',
    storageLocation: 'Tủ C',
    isDemo: true,
  },
  // Natri Clorid 0.9%:
  {
    id: 'batch-nc01',
    medicineId: 'med-04',
    batchNumber: 'NC-2501',
    mfgDate: '2025-01-10',
    expDate: '2026-11-10', // Còn ~57 ngày -> Cảnh báo trong 60 ngày
    quantity: 35,
    initialQuantity: 50,
    unitPrice: 4000,
    supplierId: 'sup-01',
    storageLocation: 'Tủ B',
    isDemo: true,
  },
  // Berberin 50mg:
  {
    id: 'batch-bb01',
    medicineId: 'med-05',
    batchNumber: 'BB-2410',
    mfgDate: '2024-10-12',
    expDate: '2027-10-12',
    quantity: 85,
    initialQuantity: 100,
    unitPrice: 600,
    supplierId: 'sup-01',
    storageLocation: 'Tủ A',
    isDemo: true,
  },
  // Dầu xoa bóp:
  {
    id: 'batch-dg01',
    medicineId: 'med-06',
    batchNumber: 'DG-2502',
    mfgDate: '2025-02-20',
    expDate: '2028-02-20',
    quantity: 8,
    initialQuantity: 10,
    unitPrice: 15000,
    supplierId: 'sup-01',
    storageLocation: 'Tủ A',
    isDemo: true,
  },
  // Cồn 70 độ: Sắp hết (còn 3 chai, minStock = 5)
  {
    id: 'batch-c701',
    medicineId: 'med-07',
    batchNumber: 'C7-2506',
    mfgDate: '2025-06-01',
    expDate: '2027-06-01',
    quantity: 3,
    initialQuantity: 10,
    unitPrice: 22000,
    supplierId: 'sup-03',
    storageLocation: 'Kệ dưới',
    isDemo: true,
  },
  // Vitamin C:
  {
    id: 'batch-vc01',
    medicineId: 'med-08',
    batchNumber: 'VC-2504',
    mfgDate: '2025-04-10',
    expDate: '2027-04-10',
    quantity: 14,
    initialQuantity: 20,
    unitPrice: 28000,
    supplierId: 'sup-01',
    storageLocation: 'Tủ A',
    isDemo: true,
  },
];

export const INITIAL_TRANSACTIONS: InventoryTransaction[] = [
  {
    id: 'tx-01',
    transactionCode: 'PN-2026-001',
    type: 'import',
    date: '2026-08-20',
    source: 'Ngân sách y tế trường học năm học 2026-2027',
    supplierId: 'sup-01',
    deliverer: 'Trần Văn Cường (DHG Pharma)',
    receiver: 'Đỗ Thị Mai Trang (Cán bộ YTHĐ)',
    performer: 'Đỗ Thị Mai Trang',
    notes: 'Nhập kiện thuốc dự trù đầu năm học cho phòng y tế học đường',
    status: 'completed',
    items: [
      {
        medicineId: 'med-01',
        medicineCode: 'TH-PARA500',
        medicineName: 'Paracetamol 500mg (Hapacol)',
        batchId: 'batch-p02',
        batchNumber: 'L2503-B',
        quantity: 200,
        unitPrice: 1200,
        totalAmount: 240000,
        unit: 'Viên',
        expDate: '2027-09-20',
      },
      {
        medicineId: 'med-02',
        medicineCode: 'TH-ORES245',
        medicineName: 'Oresol 245mg (Bột bù nước điện giải)',
        batchId: 'batch-or02',
        batchNumber: 'OR-2412',
        quantity: 100,
        unitPrice: 2500,
        totalAmount: 250000,
        unit: 'Gói',
        expDate: '2027-05-30',
      },
    ],
    totalAmount: 490000,
    isDemo: true,
    createdAt: '2026-08-20T09:30:00.000Z',
  },
  {
    id: 'tx-02',
    transactionCode: 'PX-2026-001',
    type: 'export',
    date: '2026-09-08',
    recipientName: 'Lê Văn Minh',
    recipientType: 'student',
    recipientClass: '8A2',
    purpose: 'Sốt nhẹ 38.6 độ trong giờ học thể dục, sau đó cho nằm nghỉ phòng y tế',
    performer: 'Đỗ Thị Mai Trang (Cán bộ YTHĐ)',
    notes: 'Cấp 1 viên Paracetamol 500mg uống sau ăn nhẹ, đã thông báo cho GVCN',
    status: 'completed',
    items: [
      {
        medicineId: 'med-01',
        medicineCode: 'TH-PARA500',
        medicineName: 'Paracetamol 500mg (Hapacol)',
        batchId: 'batch-p01',
        batchNumber: 'L2408-A',
        quantity: 1,
        unitPrice: 1200,
        totalAmount: 1200,
        unit: 'Viên',
        expDate: '2026-10-05',
      },
    ],
    totalAmount: 1200,
    isDemo: true,
    createdAt: '2026-09-08T08:45:00.000Z',
  },
  {
    id: 'tx-03',
    transactionCode: 'PX-2026-002',
    type: 'export',
    date: '2026-09-10',
    recipientName: 'Cô Nguyễn Thị Hoa',
    recipientType: 'teacher',
    recipientClass: 'Tổ Văn - Sử',
    purpose: 'Đau đầu, mệt mỏi sau 4 tiết dạy',
    performer: 'Đỗ Thị Mai Trang (Cán bộ YTHĐ)',
    notes: 'Cấp 1 viên Paracetamol 500mg',
    status: 'completed',
    items: [
      {
        medicineId: 'med-01',
        medicineCode: 'TH-PARA500',
        medicineName: 'Paracetamol 500mg (Hapacol)',
        batchId: 'batch-p01',
        batchNumber: 'L2408-A',
        quantity: 1,
        unitPrice: 1200,
        totalAmount: 1200,
        unit: 'Viên',
        expDate: '2026-10-05',
      },
    ],
    totalAmount: 1200,
    isDemo: true,
    createdAt: '2026-09-10T11:15:00.000Z',
  },
  {
    id: 'tx-04',
    transactionCode: 'PX-2026-003',
    type: 'export',
    date: '2026-09-12',
    recipientName: 'Trần Bảo Nam',
    recipientType: 'student',
    recipientClass: '6A4',
    purpose: 'Say nắng, mất nước khi sinh hoạt ngoại khóa dưới sân trường',
    performer: 'Đỗ Thị Mai Trang (Cán bộ YTHĐ)',
    notes: 'Pha 1 gói Oresol với 200ml nước đun sôi để nguội cho uống từng ngụm nhỏ',
    status: 'completed',
    items: [
      {
        medicineId: 'med-02',
        medicineCode: 'TH-ORES245',
        medicineName: 'Oresol 245mg (Bột bù nước điện giải)',
        batchId: 'batch-or02',
        batchNumber: 'OR-2412',
        quantity: 1,
        unitPrice: 2500,
        totalAmount: 2500,
        unit: 'Gói',
        expDate: '2027-05-30',
      },
    ],
    totalAmount: 2500,
    isDemo: true,
    createdAt: '2026-09-12T14:20:00.000Z',
  },
];

export const INITIAL_USAGE_RECORDS: UsageRecord[] = [
  {
    id: 'rec-01',
    transactionId: 'tx-02',
    date: '2026-09-08',
    recipientName: 'Lê Văn Minh',
    recipientType: 'student',
    recipientClass: '8A2',
    medicineId: 'med-01',
    medicineName: 'Paracetamol 500mg (Hapacol)',
    batchNumber: 'L2408-A',
    quantity: 1,
    unit: 'Viên',
    purpose: 'Sốt nhẹ 38.6 độ, nằm nghỉ phòng y tế',
    performer: 'Đỗ Thị Mai Trang',
    notes: 'Đã báo GVCN và phụ huynh',
    isDemo: true,
  },
  {
    id: 'rec-02',
    transactionId: 'tx-03',
    date: '2026-09-10',
    recipientName: 'Cô Nguyễn Thị Hoa',
    recipientType: 'teacher',
    recipientClass: 'Tổ Văn - Sử',
    medicineId: 'med-01',
    medicineName: 'Paracetamol 500mg (Hapacol)',
    batchNumber: 'L2408-A',
    quantity: 1,
    unit: 'Viên',
    purpose: 'Đau đầu, căng thẳng',
    performer: 'Đỗ Thị Mai Trang',
    notes: 'Nghỉ 20 phút rồi về lớp',
    isDemo: true,
  },
  {
    id: 'rec-03',
    transactionId: 'tx-04',
    date: '2026-09-12',
    recipientName: 'Trần Bảo Nam',
    recipientType: 'student',
    recipientClass: '6A4',
    medicineId: 'med-02',
    medicineName: 'Oresol 245mg (Bột bù nước điện giải)',
    batchNumber: 'OR-2412',
    quantity: 1,
    unit: 'Gói',
    purpose: 'Mất nước, say nắng nhẹ',
    performer: 'Đỗ Thị Mai Trang',
    notes: 'Học sinh hồi phục tốt',
    isDemo: true,
  },
];

export const INITIAL_SUPPLIES: MedicalSupply[] = [
  {
    id: 'sup-item-01',
    code: 'VT-BANGCA',
    name: 'Băng dán vết thương cá nhân Urgo',
    category: 'Băng gạc sơ cứu',
    unit: 'Miếng',
    quantity: 180,
    minStock: 50,
    importDate: '2026-08-20',
    expDate: '2028-06-30',
    supplierId: 'sup-03',
    storageLocation: 'Tủ C - Ngăn băng gạc',
    notes: 'Dán vết xước tay chân nhẹ khi vui chơi thể thao',
    isDemo: true,
  },
  {
    id: 'sup-item-02',
    code: 'VT-GACYTE',
    name: 'Gạc y tế tiệt trùng 8x10cm (Gói 10 miếng)',
    category: 'Băng gạc sơ cứu',
    unit: 'Gói',
    quantity: 25,
    minStock: 10,
    importDate: '2026-08-20',
    expDate: '2027-12-31',
    supplierId: 'sup-03',
    storageLocation: 'Tủ C - Ngăn băng gạc',
    notes: 'Đắp che vết thương hở sau khi rửa sạch sát khuẩn',
    isDemo: true,
  },
  {
    id: 'sup-item-03',
    code: 'VT-BANGCHUN',
    name: 'Băng cuộn chun y tế 8cm x 2m',
    category: 'Băng gạc sơ cứu',
    unit: 'Cuộn',
    quantity: 8,
    minStock: 10, // Sắp hết
    importDate: '2026-08-20',
    expDate: '2029-01-01',
    supplierId: 'sup-03',
    storageLocation: 'Tủ C - Ngăn băng gạc',
    notes: 'Cố định nẹp hoặc băng ép cầm máu',
    isDemo: true,
  },
  {
    id: 'sup-item-04',
    code: 'VT-NHIETKE',
    name: 'Nhiệt kế điện tử đo trán Omron MC-720',
    category: 'Dụng cụ khám sơ cứu',
    unit: 'Cái',
    quantity: 3,
    minStock: 2,
    importDate: '2026-08-10',
    supplierId: 'sup-03',
    storageLocation: 'Bàn trực khám y tế',
    notes: 'Đo thân nhiệt nhanh không tiếp xúc cho học sinh',
    isDemo: true,
  },
  {
    id: 'sup-item-05',
    code: 'VT-GANGTAY',
    name: 'Găng tay y tế cao su có bột (Hộp 50 đôi)',
    category: 'Vật tư bảo hộ',
    unit: 'Hộp',
    quantity: 4,
    minStock: 3,
    importDate: '2026-08-20',
    expDate: '2028-05-30',
    supplierId: 'sup-03',
    storageLocation: 'Tủ C - Ngăn bảo hộ',
    notes: 'Đeo khi xử lý vết thương dính máu, dịch tiết',
    isDemo: true,
  },
  {
    id: 'sup-item-06',
    code: 'VT-KHAUTRANG',
    name: 'Khẩu trang y tế kháng khuẩn 4 lớp (Hộp 50 cái)',
    category: 'Vật tư bảo hộ',
    unit: 'Hộp',
    quantity: 12,
    minStock: 5,
    importDate: '2026-08-20',
    expDate: '2029-08-01',
    supplierId: 'sup-03',
    storageLocation: 'Tủ C - Ngăn bảo hộ',
    notes: 'Phát cho học sinh bị ho, cảm cúm, sốt',
    isDemo: true,
  },
  {
    id: 'sup-item-07',
    code: 'VT-TUICHUOM',
    name: 'Túi chườm lạnh hạ sốt y tế',
    category: 'Dụng cụ khám sơ cứu',
    unit: 'Cái',
    quantity: 4,
    minStock: 2,
    importDate: '2026-08-15',
    supplierId: 'sup-03',
    storageLocation: 'Tủ lạnh bảo quản y tế',
    notes: 'Chườm trán khi sốt cao hoặc chấn thương bầm tím',
    isDemo: true,
  },
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-01',
    timestamp: '2026-08-15T08:00:00.000Z',
    userName: 'Đỗ Thị Mai Trang',
    userRole: 'medic',
    action: 'Khởi tạo hệ thống',
    details: 'Khởi tạo dữ liệu danh mục thuốc và vật tư y tế năm học 2026-2027 (Dữ liệu Demo)',
  },
  {
    id: 'log-02',
    timestamp: '2026-08-20T09:30:00.000Z',
    userName: 'Đỗ Thị Mai Trang',
    userRole: 'medic',
    action: 'Nhập kho',
    details: 'Lập phiếu nhập PN-2026-001 từ NCC DHG Pharma',
    targetId: 'tx-01',
  },
  {
    id: 'log-03',
    timestamp: '2026-09-08T08:45:00.000Z',
    userName: 'Đỗ Thị Mai Trang',
    userRole: 'medic',
    action: 'Xuất cấp phát',
    details: 'Xuất 1 viên Paracetamol cho HS Lê Văn Minh - Lớp 8A2 (Phiếu PX-2026-001)',
    targetId: 'tx-02',
  },
];

export const INITIAL_INVENTORY_CHECKS: InventoryCheck[] = [
  {
    id: 'chk-01',
    checkCode: 'KK-2026-0001',
    checkDate: '2026-09-05',
    checkTime: '15:30',
    performer: 'Đỗ Thị Mai Trang (Cán bộ Y tế học đường)',
    participants: [
      'Đỗ Thị Mai Trang - Cán bộ Y tế học đường',
      'Thầy Nguyễn Văn Hưng - Phó Hiệu Trưởng',
      'Cô Lê Thị Kim Cúc - Kế toán kiêm Thủ kho trường',
    ],
    notes: 'Biên bản kiểm kê định kỳ đầu năm học mới 2026 - 2027',
    status: 'adjusted',
    confirmedAt: '2026-09-05T16:00:00.000Z',
    confirmedBy: 'Nguyễn Văn Hưng (Phó Hiệu Trưởng)',
    adjustedAt: '2026-09-05T16:15:00.000Z',
    adjustedBy: 'Đỗ Thị Mai Trang',
    createdAt: '2026-09-05T15:30:00.000Z',
    items: [
      {
        medicineId: 'med-01',
        medicineCode: 'TH-PARA500',
        medicineName: 'Paracetamol 500mg (Hapacol)',
        batchId: 'batch-p02',
        batchNumber: 'L2503-B',
        expDate: '2027-09-20',
        unit: 'Viên',
        systemQuantity: 200,
        actualQuantity: 200,
        difference: 0,
        reason: 'Khớp chính xác với số liệu nhập kho',
      },
      {
        medicineId: 'med-02',
        medicineCode: 'TH-ORES245',
        medicineName: 'Oresol 245mg (Bột bù nước điện giải)',
        batchId: 'batch-or02',
        batchNumber: 'OR-2412',
        expDate: '2027-05-30',
        unit: 'Gói',
        systemQuantity: 100,
        actualQuantity: 100,
        difference: 0,
        reason: 'Khớp thực tế kiểm đếm',
      },
      {
        medicineId: 'med-03',
        medicineCode: 'TH-POVI10',
        medicineName: 'Povidone Iodine 10% 20ml',
        batchId: 'batch-pov01',
        batchNumber: 'PI-2501',
        expDate: '2027-04-15',
        unit: 'Chai',
        systemQuantity: 15,
        actualQuantity: 15,
        difference: 0,
        reason: 'Khớp thực tế',
      },
      {
        medicineId: 'med-05',
        medicineCode: 'TH-BERB50',
        medicineName: 'Berberin Clorid 50mg',
        batchId: 'batch-bb01',
        batchNumber: 'BB-2405',
        expDate: '2026-08-15',
        unit: 'Viên',
        systemQuantity: 40,
        actualQuantity: 40,
        difference: 0,
        reason: 'Lô đã hết hạn, đã niêm phong lập biên bản cách ly',
      },
    ],
  },
];

// Calculation and Helper Functions
export function getDaysRemaining(expDateStr: string, referenceDateStr?: string): number {
  const ref = referenceDateStr ? new Date(referenceDateStr) : new Date();
  ref.setHours(0, 0, 0, 0);
  const exp = new Date(expDateStr);
  exp.setHours(0, 0, 0, 0);
  const diffTime = exp.getTime() - ref.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function getExpiryAlertLevel(
  expDateStr: string,
  warning30 = 30,
  warning60 = 60,
  referenceDateStr?: string
): ExpiryAlertLevel {
  const days = getDaysRemaining(expDateStr, referenceDateStr);
  if (days < 0) return 'expired';
  if (days <= warning30) return 'warning_30';
  if (days <= warning60) return 'warning_60';
  return 'safe';
}

export function computeMedicineStatus(
  medicine: Medicine,
  batches: MedicineBatch[],
  warningDays = 30
): MedicineStatus {
  const medBatches = batches.filter((b) => b.medicineId === medicine.id);
  const totalStock = medBatches.reduce((acc, b) => acc + (b.quantity || 0), 0);

  if (totalStock === 0) {
    return 'out_of_stock';
  }

  // Check if any batch with quantity > 0 is expired
  const hasExpiredBatch = medBatches.some(
    (b) => b.quantity > 0 && getDaysRemaining(b.expDate) < 0
  );
  if (hasExpiredBatch) {
    return 'expired';
  }

  // Check if any batch with quantity > 0 is expiring soon
  const hasExpiringSoonBatch = medBatches.some(
    (b) => b.quantity > 0 && getDaysRemaining(b.expDate) >= 0 && getDaysRemaining(b.expDate) <= warningDays
  );
  if (hasExpiringSoonBatch) {
    return 'expiring_soon';
  }

  // Check if total stock is below minStock
  if (totalStock <= medicine.minStock) {
    return 'low_stock';
  }

  return 'active';
}

export function getStatusText(status: MedicineStatus): { label: string; color: string; bg: string; border: string } {
  switch (status) {
    case 'active':
      return { label: 'Đang sử dụng', color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200' };
    case 'low_stock':
      return { label: 'Sắp hết', color: 'text-amber-700', bg: 'bg-amber-50', border: 'border-amber-200' };
    case 'out_of_stock':
      return { label: 'Hết hàng', color: 'text-gray-700', bg: 'bg-gray-100', border: 'border-gray-300' };
    case 'expiring_soon':
      return { label: 'Sắp hết hạn', color: 'text-orange-700', bg: 'bg-orange-50', border: 'border-orange-200' };
    case 'expired':
      return { label: 'Đã hết hạn', color: 'text-rose-700', bg: 'bg-rose-50', border: 'border-rose-200' };
    case 'discontinued':
      return { label: 'Ngưng sử dụng', color: 'text-slate-500', bg: 'bg-slate-100', border: 'border-slate-200' };
    default:
      return { label: 'Bình thường', color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200' };
  }
}

export function formatVND(amount: number): string {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
}

export function formatDateVN(dateStr?: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}/${month}/${year}`;
}

export function formatDateTimeVN(dateStr?: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${hours}:${minutes} ${day}/${month}/${year}`;
}

// In-Memory / LocalStorage Database Engine
class AppDatabase {
  private medicines: Medicine[] = [];
  private batches: MedicineBatch[] = [];
  private transactions: InventoryTransaction[] = [];
  private suppliers: Supplier[] = [];
  private supplies: MedicalSupply[] = [];
  private usageRecords: UsageRecord[] = [];
  private inventoryChecks: InventoryCheck[] = [];
  private auditLogs: AuditLog[] = [];
  private settings: AppSettings = DEFAULT_SETTINGS;
  private currentUser: User = DEFAULT_USERS[1]; // Default to school medical officer
  private users: User[] = [];
  private students: Student[] = [];
  private healthProfiles: StudentHealthProfile[] = [];
  private clinicVisits: ClinicVisit[] = [];
  private healthEvents: HealthEvent[] = [];
  private healthCheckups: HealthCheckup[] = [];
  private classes: SchoolClass[] = [];
  private listeners: (() => void)[] = [];

  constructor() {
    this.init();
  }

  private init() {
    try {
      const storedMeds = localStorage.getItem(STORAGE_KEYS.MEDICINES);
      const storedBatches = localStorage.getItem(STORAGE_KEYS.BATCHES);
      const storedTxs = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      const storedSups = localStorage.getItem(STORAGE_KEYS.SUPPLIERS);
      const storedSupplies = localStorage.getItem(STORAGE_KEYS.SUPPLIES);
      const storedUsage = localStorage.getItem(STORAGE_KEYS.USAGE_RECORDS);
      const storedChecks = localStorage.getItem(STORAGE_KEYS.INVENTORY_CHECKS);
      const storedLogs = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      const storedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      const storedUser = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      const storedUsersList = localStorage.getItem(STORAGE_KEYS.USERS);
      const storedStudents = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      const storedProfiles = localStorage.getItem(STORAGE_KEYS.STUDENT_HEALTH_PROFILES);
      const storedVisits = localStorage.getItem(STORAGE_KEYS.CLINIC_VISITS);
      const storedEvents = localStorage.getItem(STORAGE_KEYS.HEALTH_EVENTS);
      const storedCheckups = localStorage.getItem(STORAGE_KEYS.HEALTH_CHECKUPS);
      const storedClasses = localStorage.getItem(STORAGE_KEYS.SCHOOL_CLASSES);

      if (storedMeds && storedBatches) {
        this.medicines = JSON.parse(storedMeds);
        this.batches = JSON.parse(storedBatches);
        this.transactions = storedTxs ? JSON.parse(storedTxs) : [];
        this.suppliers = storedSups ? JSON.parse(storedSups) : DEFAULT_SUPPLIERS;
        this.supplies = storedSupplies ? JSON.parse(storedSupplies) : INITIAL_SUPPLIES;
        this.usageRecords = storedUsage ? JSON.parse(storedUsage) : INITIAL_USAGE_RECORDS;
        this.inventoryChecks = storedChecks ? JSON.parse(storedChecks) : [...INITIAL_INVENTORY_CHECKS];
        this.auditLogs = storedLogs ? JSON.parse(storedLogs) : INITIAL_AUDIT_LOGS;
        this.settings = storedSettings ? JSON.parse(storedSettings) : DEFAULT_SETTINGS;
        this.users = storedUsersList ? JSON.parse(storedUsersList) : [...DEFAULT_USERS];
        for (const defUser of DEFAULT_USERS) {
          if (!this.users.some((u) => u.id === defUser.id || u.username === defUser.username)) {
            this.users.push({ ...defUser });
          }
        }
        this.currentUser = storedUser ? JSON.parse(storedUser) : (this.users.find(u => u.role === 'medic') || DEFAULT_USERS[2]);
        this.students = storedStudents ? JSON.parse(storedStudents) : [...INITIAL_STUDENTS];
        this.healthProfiles = storedProfiles ? JSON.parse(storedProfiles) : [...INITIAL_HEALTH_PROFILES];
        this.clinicVisits = storedVisits ? JSON.parse(storedVisits) : [...INITIAL_CLINIC_VISITS];
        this.healthEvents = storedEvents ? JSON.parse(storedEvents) : [...INITIAL_HEALTH_EVENTS];
        this.healthCheckups = storedCheckups ? JSON.parse(storedCheckups) : [...INITIAL_HEALTH_CHECKUPS];
        this.classes = storedClasses ? JSON.parse(storedClasses) : [...DEFAULT_CLASSES];
      } else {
        this.seedDemoData();
      }
    } catch {
      this.seedDemoData();
    }
  }

  public seedDemoData() {
    this.medicines = [...INITIAL_MEDICINES];
    this.batches = [...INITIAL_BATCHES];
    this.transactions = [...INITIAL_TRANSACTIONS];
    this.suppliers = [...DEFAULT_SUPPLIERS];
    this.supplies = [...INITIAL_SUPPLIES];
    this.usageRecords = [...INITIAL_USAGE_RECORDS];
    this.inventoryChecks = [...INITIAL_INVENTORY_CHECKS];
    this.auditLogs = [...INITIAL_AUDIT_LOGS];
    this.settings = { ...DEFAULT_SETTINGS };
    this.users = [...DEFAULT_USERS];
    this.currentUser = DEFAULT_USERS[1];
    this.students = [...INITIAL_STUDENTS];
    this.healthProfiles = [...INITIAL_HEALTH_PROFILES];
    this.clinicVisits = [...INITIAL_CLINIC_VISITS];
    this.healthEvents = [...INITIAL_HEALTH_EVENTS];
    this.healthCheckups = [...INITIAL_HEALTH_CHECKUPS];
    this.classes = [...DEFAULT_CLASSES];
    this.saveAll();
    this.notify();
  }

  public resetAllData() {
    this.seedDemoData();
  }

  private saveAll() {
    try {
      localStorage.setItem(STORAGE_KEYS.MEDICINES, JSON.stringify(this.medicines));
      localStorage.setItem(STORAGE_KEYS.BATCHES, JSON.stringify(this.batches));
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(this.transactions));
      localStorage.setItem(STORAGE_KEYS.SUPPLIERS, JSON.stringify(this.suppliers));
      localStorage.setItem(STORAGE_KEYS.SUPPLIES, JSON.stringify(this.supplies));
      localStorage.setItem(STORAGE_KEYS.USAGE_RECORDS, JSON.stringify(this.usageRecords));
      localStorage.setItem(STORAGE_KEYS.INVENTORY_CHECKS, JSON.stringify(this.inventoryChecks));
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(this.auditLogs));
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(this.settings));
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(this.users));
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(this.currentUser));
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(this.students));
      localStorage.setItem(STORAGE_KEYS.STUDENT_HEALTH_PROFILES, JSON.stringify(this.healthProfiles));
      localStorage.setItem(STORAGE_KEYS.CLINIC_VISITS, JSON.stringify(this.clinicVisits));
      localStorage.setItem(STORAGE_KEYS.HEALTH_EVENTS, JSON.stringify(this.healthEvents));
      localStorage.setItem(STORAGE_KEYS.HEALTH_CHECKUPS, JSON.stringify(this.healthCheckups));
      localStorage.setItem(STORAGE_KEYS.SCHOOL_CLASSES, JSON.stringify(this.classes));
    } catch (e) {
      console.error('Failed to persist database to localStorage', e);
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      try {
        listener();
      } catch (err) {
        console.error('Listener callback error', err);
      }
    }
  }

  // --- Users & Roles ---
  public getCurrentUser(): User {
    return this.currentUser;
  }

  public setCurrentUser(user: User) {
    this.currentUser = user;
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(this.currentUser));
    // Also ensure this user exists or is updated in this.users
    const idx = this.users.findIndex((u) => u.id === user.id || (user.email && u.email === user.email));
    if (idx >= 0) {
      this.users[idx] = { ...this.users[idx], ...user };
    } else {
      this.users.push({
        ...user,
        permissions: user.permissions || { ...(DEFAULT_ROLE_PERMISSIONS[user.role] || DEFAULT_ROLE_PERMISSIONS.medic) },
      });
    }
    this.saveAll();
    this.notify();
  }

  public setCurrentUserRole(role: UserRole) {
    const matched = this.users.find((u) => u.role === role) || DEFAULT_USERS.find((u) => u.role === role) || DEFAULT_USERS[0];
    this.currentUser = { ...matched, role };
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(this.currentUser));
    this.logAudit('Đổi quyền người dùng', `Chuyển quyền sang: ${matched.fullName} (${getRoleLabel(role)})`);
    this.notify();
  }

  public getUsers(): User[] {
    if (!this.users || this.users.length === 0) {
      this.users = [...DEFAULT_USERS];
      this.saveAll();
    }
    return [...this.users];
  }

  public getUserById(id: string): User | undefined {
    return this.users.find((u) => u.id === id);
  }

  public addUser(userData: Omit<User, 'id'> & { id?: string }): User {
    const role = userData.role || 'medic';
    const newUser: User = {
      ...userData,
      id: userData.id || `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      status: userData.status || 'active',
      role,
      permissions: userData.permissions || { ...(DEFAULT_ROLE_PERMISSIONS[role] || DEFAULT_ROLE_PERMISSIONS.medic) },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.users.unshift(newUser);
    this.logAudit('Thêm cán bộ mới', `Tạo tài khoản: ${newUser.fullName} (${getRoleLabel(newUser.role)})`, newUser.id);
    this.saveAll();
    this.notify();
    return newUser;
  }

  public updateUser(id: string, updates: Partial<User>): User {
    const index = this.users.findIndex((u) => u.id === id);
    if (index === -1) {
      throw new Error(`Không tìm thấy cán bộ với mã ${id}`);
    }
    const current = this.users[index];
    const newRole = updates.role || current.role;
    let updatedPermissions = updates.permissions || current.permissions;
    if (updates.role && updates.role !== current.role && !updates.permissions) {
      updatedPermissions = { ...(DEFAULT_ROLE_PERMISSIONS[newRole] || DEFAULT_ROLE_PERMISSIONS.medic) };
    }

    const updatedUser: User = {
      ...current,
      ...updates,
      role: newRole,
      permissions: updatedPermissions,
      updatedAt: new Date().toISOString(),
    };

    this.users[index] = updatedUser;

    if (this.currentUser.id === id) {
      this.currentUser = { ...this.currentUser, ...updatedUser };
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(this.currentUser));
    }

    this.logAudit(
      'Cập nhật thông tin cán bộ / phân quyền',
      `Cập nhật tài khoản: ${updatedUser.fullName}, Vai trò: ${getRoleLabel(newRole)}`,
      id
    );
    this.saveAll();
    this.notify();
    return updatedUser;
  }

  public toggleUserStatus(id: string): User {
    const user = this.getUserById(id);
    if (!user) throw new Error('Không tìm thấy người dùng');
    const newStatus: 'active' | 'inactive' = user.status === 'inactive' ? 'active' : 'inactive';
    return this.updateUser(id, { status: newStatus });
  }

  public deleteUser(id: string): boolean {
    if (this.currentUser.id === id) {
      throw new Error('Không thể xóa tài khoản bạn đang sử dụng');
    }
    const target = this.getUserById(id);
    this.users = this.users.filter((u) => u.id !== id);
    this.logAudit('Xóa tài khoản cán bộ', `Đã xóa tài khoản: ${target?.fullName || id}`, id);
    this.saveAll();
    this.notify();
    return true;
  }

  public syncUsers(externalUsers: User[]) {
    let changed = false;
    for (const ext of externalUsers) {
      const idx = this.users.findIndex((u) => u.id === ext.id || (ext.email && u.email === ext.email));
      if (idx >= 0) {
        this.users[idx] = { ...this.users[idx], ...ext };
        changed = true;
      } else {
        this.users.push({
          ...ext,
          permissions: ext.permissions || { ...(DEFAULT_ROLE_PERMISSIONS[ext.role] || DEFAULT_ROLE_PERMISSIONS.medic) },
          status: ext.status || 'active',
        });
        changed = true;
      }
    }
    if (changed) {
      this.saveAll();
      this.notify();
    }
  }

  // --- Audit Logging ---
  public logAudit(action: string, details: string, targetId?: string) {
    const newLog: AuditLog = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString(),
      userName: this.currentUser.fullName,
      userRole: this.currentUser.role,
      action,
      details,
      targetId,
    };
    this.auditLogs.unshift(newLog);
    if (this.auditLogs.length > 500) {
      this.auditLogs = this.auditLogs.slice(0, 500);
    }
    this.saveAll();
  }

  public getAuditLogs(): AuditLog[] {
    return [...this.auditLogs];
  }

  // --- Settings ---
  public getSettings(): AppSettings {
    return { ...this.settings };
  }

  public updateSettings(newSettings: Partial<AppSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    this.logAudit('Cập nhật cài đặt', 'Thay đổi cấu hình cảnh báo và thông tin trường');
    this.saveAll();
    this.notify();
  }

  // --- Suppliers ---
  public getSuppliers(): Supplier[] {
    return [...this.suppliers];
  }

  public addSupplier(supplierData: Omit<Supplier, 'id'>): Supplier {
    const newSupplier: Supplier = {
      id: 'sup-' + Date.now(),
      ...supplierData,
    };
    this.suppliers.push(newSupplier);
    this.logAudit('Thêm nhà cung cấp', `Thêm NCC: ${newSupplier.name} (${newSupplier.code})`);
    this.saveAll();
    this.notify();
    return newSupplier;
  }

  // --- Medicines ---
  public getMedicines(): (Medicine & { totalStock: number; earliestExpDate?: string; computedStatus: MedicineStatus })[] {
    return this.medicines.map((m) => {
      const medBatches = this.batches.filter((b) => b.medicineId === m.id);
      const totalStock = medBatches.reduce((acc, b) => acc + (b.quantity || 0), 0);
      
      // Calculate earliest active expiry
      const activeBatches = medBatches
        .filter((b) => b.quantity > 0)
        .sort((a, b) => new Date(a.expDate).getTime() - new Date(b.expDate).getTime());
      const earliestExpDate = activeBatches[0]?.expDate;
      const computedStatus = computeMedicineStatus(m, this.batches, this.settings.warningExpiringDays);

      return {
        ...m,
        totalStock,
        earliestExpDate,
        computedStatus,
      };
    });
  }

  public getMedicineById(id: string): Medicine | undefined {
    return this.medicines.find((m) => m.id === id);
  }

  public seedStandardMedicalCatalog() {
    const defaultCatalog = [
      { code: 'YT-PARA500', name: 'Paracetamol', activeIngredient: 'Paracetamol', dosageForm: 'Viên nén', strength: '500mg', unit: 'Viên', packing: 'Hộp 10 vỉ x 10 viên', manufacturer: 'Dược Hậu Giang', country: 'Việt Nam', minStock: 100, unitPrice: 500, storageLocation: 'Tủ A - Ngăn 1' },
      { code: 'YT-ORESOL', name: 'Oresol', activeIngredient: 'Muối bù nước điện giải', dosageForm: 'Bột pha uống', strength: '', unit: 'Gói', packing: 'Hộp 40 gói', manufacturer: 'Dược phẩm TW', country: 'Việt Nam', minStock: 50, unitPrice: 1500, storageLocation: 'Tủ A - Ngăn 2' },
      { code: 'YT-NMSL', name: 'Nước muối sinh lý 0.9%', activeIngredient: 'Natri Clorid 0.9%', dosageForm: 'Dung dịch', strength: '0.9%', unit: 'Chai', packing: 'Thùng 50 chai', manufacturer: 'Vĩnh Phúc', country: 'Việt Nam', minStock: 10, unitPrice: 5000, storageLocation: 'Tủ B - Ngăn 1' },
      { code: 'YT-POV10', name: 'Povidine 10%', activeIngredient: 'Povidon Iod 10%', dosageForm: 'Dung dịch sát khuẩn', strength: '10%', unit: 'Lọ', packing: 'Hộp 1 lọ 20ml', manufacturer: 'Pharmedic', country: 'Việt Nam', minStock: 5, unitPrice: 12000, storageLocation: 'Tủ B - Ngăn 2' },
      { code: 'VT-URGO', name: 'Băng cá nhân Urgo', activeIngredient: '', dosageForm: 'Vật tư y tế', strength: '', unit: 'Miếng', packing: 'Hộp 100 miếng', manufacturer: 'Urgo', country: 'Thái Lan', minStock: 200, unitPrice: 500, storageLocation: 'Tủ C - Ngăn 1' },
      { code: 'VT-BONG', name: 'Bông y tế thấm nước', activeIngredient: '', dosageForm: 'Vật tư y tế', strength: '', unit: 'Cuộn', packing: 'Bao 1 cuộn 50g', manufacturer: 'Bảo Thạch', country: 'Việt Nam', minStock: 10, unitPrice: 7000, storageLocation: 'Tủ C - Ngăn 2' },
      { code: 'VT-GAC', name: 'Gạc vô trùng', activeIngredient: '', dosageForm: 'Vật tư y tế', strength: '', unit: 'Miếng', packing: 'Hộp 10 miếng', manufacturer: 'Bảo Thạch', country: 'Việt Nam', minStock: 50, unitPrice: 2000, storageLocation: 'Tủ C - Ngăn 2' },
      { code: 'YT-DAUGIO', name: 'Dầu gió xanh Thiên Ân', activeIngredient: 'Tinh dầu bạc hà', dosageForm: 'Dung dịch xoa ngoài', strength: '', unit: 'Chai', packing: 'Hộp 1 chai 5ml', manufacturer: 'Thiên Ân', country: 'Việt Nam', minStock: 5, unitPrice: 25000, storageLocation: 'Tủ A - Ngăn 3' },
      { code: 'YT-OSLA', name: 'Thuốc nhỏ mắt Osla', activeIngredient: 'Natri clorid', dosageForm: 'Dung dịch nhỏ mắt', strength: '0.9%', unit: 'Lọ', packing: 'Hộp 1 lọ 15ml', manufacturer: 'Merap', country: 'Việt Nam', minStock: 10, unitPrice: 15000, storageLocation: 'Tủ B - Ngăn 1' },
      { code: 'YT-SMECTA', name: 'Smecta (Đau bụng)', activeIngredient: 'Diosmectit', dosageForm: 'Bột pha uống', strength: '3g', unit: 'Gói', packing: 'Hộp 30 gói', manufacturer: 'Beaufour Ipsen', country: 'Pháp', minStock: 20, unitPrice: 4000, storageLocation: 'Tủ A - Ngăn 2' },
    ];

    let added = 0;
    for (const item of defaultCatalog) {
      const existingMed = this.medicines.find((m) => m.code.toUpperCase() === item.code.toUpperCase());
      
      let medId = '';
      if (!existingMed) {
        medId = 'med-' + Date.now() + '-' + added;
        this.medicines.unshift({
          ...item,
          id: medId,
          supplierId: this.suppliers.length > 0 ? this.suppliers[0].id : '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        added++;
      } else {
        medId = existingMed.id;
      }
      
      // Check if this medicine has any batches, if not, create one
      const hasBatches = this.batches.some(b => b.medicineId === medId);
      if (!hasBatches) {
        const nextYear = new Date();
        nextYear.setFullYear(nextYear.getFullYear() + 2);
        this.batches.unshift({
          id: 'batch-' + Date.now() + '-' + added + Math.random(),
          medicineId: medId,
          batchNumber: 'LO-' + new Date().getFullYear() + '-' + (added + 1),
          mfgDate: new Date().toISOString().split('T')[0],
          expDate: nextYear.toISOString().split('T')[0],
          quantity: item.minStock * 5, 
          initialQuantity: item.minStock * 5,
          unitPrice: item.unitPrice,
          storageLocation: item.storageLocation,
        });
        if (existingMed) added++; // Count as an update if we added a missing batch
      }
    }

    if (added > 0) {
      this.saveAll();
      this.logAudit('Thêm danh mục mẫu', `Đã tự động thêm ${added} loại thuốc/vật tư thiết yếu`);
      this.notify();
    }
    return added;
  }

  public addMedicine(medicineData: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>, initialBatch?: {
    batchNumber: string;
    mfgDate: string;
    expDate: string;
    quantity: number;
    unitPrice: number;
  }): Medicine {
    // Check duplicate code
    if (this.medicines.some((m) => m.code.trim().toUpperCase() === medicineData.code.trim().toUpperCase())) {
      throw new Error(`Mã thuốc "${medicineData.code}" đã tồn tại trên hệ thống. Vui lòng kiểm tra lại.`);
    }

    const now = new Date().toISOString();
    const newMed: Medicine = {
      id: 'med-' + Date.now(),
      ...medicineData,
      createdAt: now,
      updatedAt: now,
    };

    this.medicines.unshift(newMed);

    if (initialBatch && initialBatch.quantity > 0) {
      const newBatch: MedicineBatch = {
        id: 'batch-' + Date.now(),
        medicineId: newMed.id,
        batchNumber: initialBatch.batchNumber || 'LO-BAN-DAU',
        mfgDate: initialBatch.mfgDate,
        expDate: initialBatch.expDate,
        quantity: Number(initialBatch.quantity),
        initialQuantity: Number(initialBatch.quantity),
        unitPrice: Number(initialBatch.unitPrice) || Number(medicineData.unitPrice) || 0,
        supplierId: medicineData.supplierId,
        storageLocation: medicineData.storageLocation,
        isDemo: false,
      };
      this.batches.push(newBatch);
    }

    this.logAudit('Thêm thuốc', `Thêm mới thuốc: ${newMed.name} (${newMed.code})`, newMed.id);
    this.saveAll();
    this.notify();
    return newMed;
  }

  public updateMedicine(id: string, updates: Partial<Medicine>): Medicine {
    const index = this.medicines.findIndex((m) => m.id === id);
    if (index === -1) throw new Error('Không tìm thấy thông tin thuốc cần sửa.');

    // If changing code, verify uniqueness
    if (updates.code) {
      const duplicate = this.medicines.find(
        (m) => m.id !== id && m.code.trim().toUpperCase() === updates.code?.trim().toUpperCase()
      );
      if (duplicate) {
        throw new Error(`Mã thuốc "${updates.code}" đã được sử dụng cho thuốc khác.`);
      }
    }

    this.medicines[index] = {
      ...this.medicines[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    this.logAudit('Sửa thuốc', `Cập nhật thông tin thuốc: ${this.medicines[index].name} (${this.medicines[index].code})`, id);
    this.saveAll();
    this.notify();
    return this.medicines[index];
  }

  public deleteMedicine(id: string): void {
    const med = this.medicines.find((m) => m.id === id);
    if (!med) throw new Error('Thuốc không tồn tại.');

    // Check if medicine has active stock or transactions
    const medBatches = this.batches.filter((b) => b.medicineId === id && b.quantity > 0);
    const totalStock = medBatches.reduce((acc, b) => acc + b.quantity, 0);
    if (totalStock > 0) {
      throw new Error(`Không thể xóa thuốc "${med.name}" vì vẫn còn tồn kho (${totalStock} ${med.unit}). Vui lòng xử lý xuất hủy hoặc điều chỉnh tồn trước.`);
    }

    this.medicines = this.medicines.filter((m) => m.id !== id);
    this.batches = this.batches.filter((b) => b.medicineId !== id);
    this.logAudit('Xóa thuốc', `Xóa danh mục thuốc: ${med.name} (${med.code})`, id);
    this.saveAll();
    this.notify();
  }

  // --- Sequential Auto Transaction Codes ---
  public getNextImportCode(): string {
    const year = new Date().getFullYear();
    const prefix = `PN-${year}-`;
    let maxSeq = 0;
    for (const tx of this.transactions) {
      if (tx.transactionCode && tx.transactionCode.startsWith(prefix)) {
        const numPart = parseInt(tx.transactionCode.replace(prefix, ''), 10);
        if (!isNaN(numPart) && numPart > maxSeq) {
          maxSeq = numPart;
        }
      }
    }
    return `${prefix}${String(maxSeq + 1).padStart(4, '0')}`;
  }

  public getNextExportCode(): string {
    const year = new Date().getFullYear();
    const prefix = `PX-${year}-`;
    let maxSeq = 0;
    for (const tx of this.transactions) {
      if (tx.transactionCode && tx.transactionCode.startsWith(prefix)) {
        const numPart = parseInt(tx.transactionCode.replace(prefix, ''), 10);
        if (!isNaN(numPart) && numPart > maxSeq) {
          maxSeq = numPart;
        }
      }
    }
    return `${prefix}${String(maxSeq + 1).padStart(4, '0')}`;
  }

  public getNextCheckCode(): string {
    const year = new Date().getFullYear();
    const prefix = `KK-${year}-`;
    let maxSeq = 0;
    for (const chk of this.inventoryChecks) {
      if (chk.checkCode && chk.checkCode.startsWith(prefix)) {
        const numPart = parseInt(chk.checkCode.replace(prefix, ''), 10);
        if (!isNaN(numPart) && numPart > maxSeq) {
          maxSeq = numPart;
        }
      }
    }
    return `${prefix}${String(maxSeq + 1).padStart(4, '0')}`;
  }

  // --- Batches (Quản lý Lô) ---
  public getBatches(medicineId?: string): MedicineBatch[] {
    if (medicineId) {
      return this.batches.filter((b) => b.medicineId === medicineId);
    }
    return [...this.batches];
  }

  // FEFO: Get available batches sorted by expiry date ascending
  // Excludes expired batches by default (getDaysRemaining >= 0)
  public getFEFOBatches(medicineId: string, includeExpired = false): MedicineBatch[] {
    return this.batches
      .filter((b) => {
        if (b.medicineId !== medicineId || b.quantity <= 0) return false;
        if (!includeExpired && getDaysRemaining(b.expDate) < 0) return false;
        return true;
      })
      .sort((a, b) => new Date(a.expDate).getTime() - new Date(b.expDate).getTime());
  }

  // Calculate FEFO multi-batch allocation breakdown before confirming export
  public calculateFEFOAllocation(medicineId: string, requestedQuantity: number) {
    const med = this.medicines.find((m) => m.id === medicineId);
    const validBatches = this.getFEFOBatches(medicineId, false);
    const expiredBatches = this.batches.filter(
      (b) => b.medicineId === medicineId && b.quantity > 0 && getDaysRemaining(b.expDate) < 0
    );

    let remaining = requestedQuantity;
    const allocations: { batch: MedicineBatch; allocatedQty: number }[] = [];

    for (const batch of validBatches) {
      if (remaining <= 0) break;
      const take = Math.min(batch.quantity, remaining);
      allocations.push({ batch, allocatedQty: take });
      remaining -= take;
    }

    const totalValidAvailable = validBatches.reduce((sum, b) => sum + b.quantity, 0);
    const canFulfill = requestedQuantity > 0 && remaining <= 0;

    return {
      medicine: med,
      allocations,
      totalValidAvailable,
      canFulfill,
      shortage: Math.max(0, remaining),
      expiredBatches,
    };
  }

  // --- Imports (Nhập Thuốc) ---
  public importMedicineTransaction(payload: {
    transactionCode: string;
    date: string;
    source: string;
    supplierId: string;
    deliverer: string;
    receiver: string;
    performer: string;
    notes?: string;
    items: {
      medicineId: string;
      batchNumber: string;
      mfgDate: string;
      expDate: string;
      quantity: number;
      unitPrice: number;
      storageLocation?: string;
    }[];
  }): InventoryTransaction {
    if (!payload.items || payload.items.length === 0) {
      throw new Error('Phiếu nhập phải có ít nhất 1 mặt hàng.');
    }

    // Validation: no negative or zero quantity, valid dates
    for (const item of payload.items) {
      if (item.quantity <= 0) {
        throw new Error(`Số lượng nhập của thuốc phải lớn hơn 0 (phát hiện số lượng: ${item.quantity}).`);
      }
      if (item.unitPrice < 0) {
        throw new Error('Đơn giá nhập không được là số âm.');
      }
      if (!item.batchNumber?.trim()) {
        throw new Error('Số lô không được để trống.');
      }
      if (item.mfgDate && item.expDate && new Date(item.expDate) <= new Date(item.mfgDate)) {
        throw new Error(`Hạn sử dụng (${item.expDate}) phải sau ngày sản xuất (${item.mfgDate}) cho lô "${item.batchNumber}".`);
      }
    }

    const transactionItems: {
      medicineId: string;
      medicineCode: string;
      medicineName: string;
      batchId: string;
      batchNumber: string;
      quantity: number;
      unitPrice: number;
      totalAmount: number;
      unit: string;
      expDate?: string;
    }[] = [];

    let grandTotal = 0;

    // Process each item & update / create batch
    for (const item of payload.items) {
      const med = this.medicines.find((m) => m.id === item.medicineId);
      if (!med) throw new Error(`Không tìm thấy mã thuốc ID: ${item.medicineId}`);

      const totalAmount = item.quantity * item.unitPrice;
      grandTotal += totalAmount;

      // Find if exact batch exists for this medicine and batch number
      let existingBatch = this.batches.find(
        (b) => b.medicineId === item.medicineId && b.batchNumber.trim().toUpperCase() === item.batchNumber.trim().toUpperCase()
      );

      let batchId: string;
      if (existingBatch) {
        // Add to existing batch
        existingBatch.quantity += item.quantity;
        existingBatch.initialQuantity += item.quantity;
        batchId = existingBatch.id;
      } else {
        // Create new batch
        const newBatch: MedicineBatch = {
          id: 'batch-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          medicineId: item.medicineId,
          batchNumber: item.batchNumber.trim().toUpperCase(),
          mfgDate: item.mfgDate || '2025-01-01',
          expDate: item.expDate,
          quantity: item.quantity,
          initialQuantity: item.quantity,
          unitPrice: item.unitPrice,
          supplierId: payload.supplierId,
          storageLocation: item.storageLocation || med.storageLocation,
          isDemo: false,
        };
        this.batches.push(newBatch);
        batchId = newBatch.id;
      }

      transactionItems.push({
        medicineId: med.id,
        medicineCode: med.code,
        medicineName: med.name,
        batchId,
        batchNumber: item.batchNumber.trim().toUpperCase(),
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalAmount,
        unit: med.unit,
        expDate: item.expDate,
      });
    }

    const newTx: InventoryTransaction = {
      id: 'tx-' + Date.now(),
      transactionCode: payload.transactionCode?.trim() || this.getNextImportCode(),
      type: 'import',
      date: payload.date || new Date().toISOString().split('T')[0],
      source: payload.source,
      supplierId: payload.supplierId,
      deliverer: payload.deliverer,
      receiver: payload.receiver,
      performer: payload.performer || this.currentUser.fullName,
      notes: payload.notes,
      items: transactionItems,
      totalAmount: grandTotal,
      status: 'completed',
      isDemo: false,
      createdAt: new Date().toISOString(),
    };

    this.transactions.unshift(newTx);
    this.logAudit(
      'Nhập kho thuốc',
      `Tạo phiếu nhập ${newTx.transactionCode}: Nhập ${transactionItems.length} thuốc, tổng tiền ${formatVND(grandTotal)}`,
      newTx.id
    );

    this.saveAll();
    this.notify();
    return newTx;
  }

  // --- Exports (Xuất / Cấp phát thuốc) ---
  public exportMedicineTransaction(payload: {
    transactionCode?: string;
    date: string;
    recipientName: string;
    recipientType: 'student' | 'teacher' | 'staff' | 'other';
    recipientClass?: string;
    purpose: string;
    performer: string;
    notes?: string;
    items: {
      medicineId: string;
      batchId?: string; // If not provided, auto select using FEFO
      quantity: number;
    }[];
  }): InventoryTransaction {
    if (!payload.items || payload.items.length === 0) {
      throw new Error('Phiếu xuất phải có ít nhất 1 loại thuốc.');
    }
    if (!payload.recipientName?.trim()) {
      throw new Error('Họ và tên người sử dụng/nhận thuốc không được để trống.');
    }
    if (!payload.purpose?.trim()) {
      throw new Error('Mục đích sử dụng thuốc không được để trống.');
    }

    const transactionItems: {
      medicineId: string;
      medicineCode: string;
      medicineName: string;
      batchId: string;
      batchNumber: string;
      quantity: number;
      unitPrice: number;
      totalAmount: number;
      unit: string;
      expDate?: string;
    }[] = [];

    let grandTotal = 0;

    // Check each requested item against current batch balances
    for (const req of payload.items) {
      if (req.quantity <= 0) {
        throw new Error(`Số lượng xuất phải lớn hơn 0.`);
      }

      const med = this.medicines.find((m) => m.id === req.medicineId);
      if (!med) throw new Error(`Không tìm thấy thuốc ID: ${req.medicineId}`);

      // If specific batch requested:
      if (req.batchId) {
        const batch = this.batches.find((b) => b.id === req.batchId);
        if (!batch) throw new Error(`Không tìm thấy lô thuốc đã chọn.`);

        // STRICT REQUIREMENT: Do not allow export of expired batches!
        if (getDaysRemaining(batch.expDate) < 0) {
          throw new Error(
            `Lô thuốc "${batch.batchNumber}" của "${med.name}" đã hết hạn sử dụng (${formatDateVN(batch.expDate)}), không được phép xuất kho.`
          );
        }

        if (batch.quantity < req.quantity) {
          throw new Error(
            `Lô ${batch.batchNumber} chỉ còn ${batch.quantity} ${med.unit}, không đủ để xuất ${req.quantity} ${med.unit}.`
          );
        }

        // Deduct from batch
        batch.quantity -= req.quantity;
        const totalAmount = req.quantity * (batch.unitPrice || med.unitPrice || 0);
        grandTotal += totalAmount;

        transactionItems.push({
          medicineId: med.id,
          medicineCode: med.code,
          medicineName: med.name,
          batchId: batch.id,
          batchNumber: batch.batchNumber,
          quantity: req.quantity,
          unitPrice: batch.unitPrice || med.unitPrice || 0,
          totalAmount,
          unit: med.unit,
          expDate: batch.expDate,
        });
      } else {
        // Automatic FEFO Allocation:
        const fefoAllocation = this.calculateFEFOAllocation(med.id, req.quantity);
        if (!fefoAllocation.canFulfill) {
          if (fefoAllocation.expiredBatches.length > 0 && fefoAllocation.totalValidAvailable === 0) {
            throw new Error(
              `Không thể xuất thuốc "${med.name}": Toàn bộ các lô tồn kho hiện tại đã hết hạn sử dụng, không được phép xuất kho.`
            );
          }
          throw new Error(
            `Không đủ số lượng tồn kho còn hạn sử dụng để xuất thuốc "${med.name}". (Hiện còn hạn: ${fefoAllocation.totalValidAvailable} ${med.unit}, yêu cầu xuất: ${req.quantity} ${med.unit})`
          );
        }

        for (const item of fefoAllocation.allocations) {
          const batch = item.batch;
          const deductAmount = item.allocatedQty;
          batch.quantity -= deductAmount;

          const totalAmount = deductAmount * (batch.unitPrice || med.unitPrice || 0);
          grandTotal += totalAmount;

          transactionItems.push({
            medicineId: med.id,
            medicineCode: med.code,
            medicineName: med.name,
            batchId: batch.id,
            batchNumber: batch.batchNumber,
            quantity: deductAmount,
            unitPrice: batch.unitPrice || med.unitPrice || 0,
            totalAmount,
            unit: med.unit,
            expDate: batch.expDate,
          });
        }
      }
    }

    const txCode = payload.transactionCode?.trim() || this.getNextExportCode();
    const newTx: InventoryTransaction = {
      id: 'tx-' + Date.now(),
      transactionCode: txCode,
      type: 'export',
      date: payload.date || new Date().toISOString().split('T')[0],
      recipientName: payload.recipientName,
      recipientType: payload.recipientType,
      recipientClass: payload.recipientClass,
      purpose: payload.purpose,
      performer: payload.performer || this.currentUser.fullName,
      notes: payload.notes,
      items: transactionItems,
      totalAmount: grandTotal,
      status: 'completed',
      isDemo: false,
      createdAt: new Date().toISOString(),
    };

    this.transactions.unshift(newTx);

    // Also write into Usage Records (Sổ theo dõi sử dụng thuốc)
    for (const item of transactionItems) {
      const record: UsageRecord = {
        id: 'rec-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
        transactionId: newTx.id,
        date: newTx.date,
        recipientName: payload.recipientName,
        recipientType: payload.recipientType,
        recipientClass: payload.recipientClass || 'Không có',
        medicineId: item.medicineId,
        medicineName: item.medicineName,
        batchNumber: item.batchNumber,
        quantity: item.quantity,
        unit: item.unit,
        purpose: payload.purpose,
        performer: newTx.performer,
        notes: payload.notes,
        isDemo: false,
      };
      this.usageRecords.unshift(record);
    }

    this.logAudit(
      'Xuất cấp phát thuốc',
      `Tạo phiếu xuất ${newTx.transactionCode} cho ${payload.recipientName} (${payload.recipientType === 'student' ? 'Học sinh ' + (payload.recipientClass || '') : 'Giáo viên/Nhân viên'}): ${transactionItems.map((i) => `${i.medicineName} (${i.quantity} ${i.unit})`).join(', ')}`,
      newTx.id
    );

    this.saveAll();
    this.notify();
    return newTx;
  }

  // --- Cancel Transaction (Hủy phiếu an toàn) ---
  public cancelTransaction(transactionId: string, reason: string): void {
    const tx = this.transactions.find((t) => t.id === transactionId);
    if (!tx) throw new Error('Không tìm thấy phiếu giao dịch.');
    if (tx.status === 'cancelled') throw new Error('Phiếu này đã được hủy trước đó.');

    // Reverse inventory effects
    if (tx.type === 'import') {
      // Must deduct what was imported; verify each batch still has enough quantity
      for (const item of tx.items) {
        const batch = this.batches.find((b) => b.id === item.batchId);
        if (batch) {
          if (batch.quantity < item.quantity) {
            throw new Error(`Không thể hủy phiếu nhập: Lô ${batch.batchNumber} đã được xuất một phần, lượng tồn hiện tại (${batch.quantity}) nhỏ hơn số lượng nhập cần hoàn tác (${item.quantity}).`);
          }
          batch.quantity -= item.quantity;
        }
      }
    } else if (tx.type === 'export') {
      // Re-add to batch quantities
      for (const item of tx.items) {
        const batch = this.batches.find((b) => b.id === item.batchId);
        if (batch) {
          batch.quantity += item.quantity;
        }
      }
      // Remove or mark usage records
      this.usageRecords = this.usageRecords.filter((r) => r.transactionId !== tx.id);
    }

    tx.status = 'cancelled';
    tx.cancellationReason = reason;

    this.logAudit(
      'HỦY PHIẾU GIAO DỊCH',
      `Hủy phiếu ${tx.transactionCode} (${tx.type === 'import' ? 'Nhập kho' : 'Xuất kho'}). Lý do: ${reason}`,
      tx.id
    );

    this.saveAll();
    this.notify();
  }

  // --- Transactions Query ---
  public getTransactions(type?: 'import' | 'export'): InventoryTransaction[] {
    if (type) {
      return this.transactions.filter((t) => t.type === type);
    }
    return [...this.transactions];
  }

  // --- Usage Records Query ---
  public getUsageRecords(): UsageRecord[] {
    return [...this.usageRecords];
  }

  // --- Supplies (Vật tư y tế) ---
  public getSupplies(): MedicalSupply[] {
    return [...this.supplies];
  }

  public addSupply(supplyData: Omit<MedicalSupply, 'id'>): MedicalSupply {
    const newSupply: MedicalSupply = {
      id: 'sup-item-' + Date.now(),
      ...supplyData,
    };
    this.supplies.unshift(newSupply);
    this.logAudit('Thêm vật tư y tế', `Thêm mới vật tư: ${newSupply.name} (${newSupply.code})`);
    this.saveAll();
    this.notify();
    return newSupply;
  }

  // --- Inventory Calculations & Stock Balances (Quản lý tồn kho) ---
  // Formula: Tồn cuối = Tồn đầu + Tổng Nhập - Tổng Xuất
  public getStockBalances(startDate?: string, endDate?: string): StockBalanceItem[] {
    const allMeds = this.getMedicines();
    const balances: StockBalanceItem[] = [];

    // Filter transactions in date range if provided
    const txInPeriod = this.transactions.filter((t) => {
      if (t.status === 'cancelled') return false;
      if (startDate && t.date < startDate) return false;
      if (endDate && t.date > endDate) return false;
      return true;
    });

    for (const med of allMeds) {
      const medBatches = this.batches.filter((b) => b.medicineId === med.id);

      if (medBatches.length === 0) {
        balances.push({
          medicineId: med.id,
          medicineCode: med.code,
          medicineName: med.name,
          batchNumber: 'Chưa có lô',
          expDate: '---',
          unit: med.unit,
          openingStock: 0,
          importQuantity: 0,
          exportQuantity: 0,
          closingStock: 0,
          minStock: med.minStock,
          unitPrice: med.unitPrice,
          totalValuation: 0,
          status: 'out_of_stock',
          expiryAlert: 'safe',
        });
        continue;
      }

      for (const batch of medBatches) {
        // Calculate imports and exports in period for this batch
        let importQty = 0;
        let exportQty = 0;

        for (const tx of txInPeriod) {
          for (const item of tx.items) {
            if (item.batchId === batch.id || (item.medicineId === med.id && item.batchNumber === batch.batchNumber)) {
              if (tx.type === 'import') importQty += item.quantity;
              if (tx.type === 'export') exportQty += item.quantity;
            }
          }
        }

        const closingStock = batch.quantity;
        // Opening stock for the filtered period
        const openingStock = Math.max(0, closingStock - importQty + exportQty);
        const expAlert = getExpiryAlertLevel(batch.expDate, this.settings.warningExpiringDays, this.settings.warningNoticeDays);

        let itemStatus: MedicineStatus = 'active';
        if (closingStock === 0) itemStatus = 'out_of_stock';
        else if (expAlert === 'expired') itemStatus = 'expired';
        else if (expAlert === 'warning_30') itemStatus = 'expiring_soon';
        else if (closingStock <= med.minStock) itemStatus = 'low_stock';

        balances.push({
          medicineId: med.id,
          medicineCode: med.code,
          medicineName: med.name,
          batchNumber: batch.batchNumber,
          expDate: batch.expDate,
          unit: med.unit,
          openingStock,
          importQuantity: importQty,
          exportQuantity: exportQty,
          closingStock,
          minStock: med.minStock,
          unitPrice: batch.unitPrice || med.unitPrice,
          totalValuation: closingStock * (batch.unitPrice || med.unitPrice),
          status: itemStatus,
          expiryAlert: expAlert,
        });
      }
    }

    return balances;
  }

  // --- SỔ NHẬP - XUẤT - TỒN (In-Out-Balance Report) ---
  public getStockInOutReport(options?: {
    startDate?: string;
    endDate?: string;
    medicineId?: string;
    batchNumber?: string;
  }): StockInOutBalanceRow[] {
    const { startDate, endDate, medicineId, batchNumber } = options || {};
    const rows: StockInOutBalanceRow[] = [];

    // Filter transactions
    const validTxs = this.transactions.filter((t) => t.status !== 'cancelled');

    // Filter target batches
    let targetBatches = [...this.batches];
    if (medicineId) {
      targetBatches = targetBatches.filter((b) => b.medicineId === medicineId);
    }
    if (batchNumber) {
      targetBatches = targetBatches.filter(
        (b) => b.batchNumber.toLowerCase().includes(batchNumber.toLowerCase().trim())
      );
    }

    let stt = 1;
    for (const batch of targetBatches) {
      const med = this.medicines.find((m) => m.id === batch.medicineId);
      if (!med) continue;

      let importQty = 0;
      let exportQty = 0;
      let adjQty = 0;

      // Prior to startDate: transactions used to calculate opening stock if startDate is provided
      let priorImport = 0;
      let priorExport = 0;

      for (const tx of validTxs) {
        for (const item of tx.items) {
          const match = item.batchId === batch.id || (item.medicineId === med.id && item.batchNumber === batch.batchNumber);
          if (match) {
            const inPeriod = (!startDate || tx.date >= startDate) && (!endDate || tx.date <= endDate);
            const isPrior = startDate && tx.date < startDate;

            if (inPeriod) {
              if (tx.type === 'import') importQty += item.quantity;
              if (tx.type === 'export') exportQty += item.quantity;
            }
            if (isPrior) {
              if (tx.type === 'import') priorImport += item.quantity;
              if (tx.type === 'export') priorExport += item.quantity;
            }
          }
        }
      }

      // If user specified a startDate, opening stock is calculated by back-tracking from current stock or prior sums
      const closingStock = batch.quantity;
      const openingStock = startDate
        ? Math.max(0, (batch.initialQuantity || batch.quantity) + priorImport - priorExport)
        : Math.max(0, closingStock - importQty + exportQty);

      // Check if there was an audit difference recorded
      adjQty = closingStock - (openingStock + importQty - exportQty);

      rows.push({
        id: `ior-${batch.id}`,
        stt: stt++,
        date: startDate && endDate ? `${formatDateVN(startDate)} - ${formatDateVN(endDate)}` : 'Toàn kỳ',
        medicineId: med.id,
        medicineCode: med.code,
        medicineName: med.name,
        batchNumber: batch.batchNumber,
        expDate: batch.expDate,
        unit: med.unit,
        openingStock,
        importQuantity: importQty,
        exportQuantity: exportQty,
        adjustmentQuantity: adjQty,
        closingStock,
        notes: batch.storageLocation || med.storageLocation || '',
      });
    }

    return rows;
  }

  // --- Inventory Checks (Kiểm Kê Thuốc & Vật Tư Y Tế) ---
  public getInventoryChecks(): InventoryCheck[] {
    return [...this.inventoryChecks];
  }

  public getInventoryCheckById(id: string): InventoryCheck | undefined {
    return this.inventoryChecks.find((c) => c.id === id);
  }

  public saveInventoryCheck(payload: Partial<InventoryCheck>): InventoryCheck {
    const existingIdx = payload.id ? this.inventoryChecks.findIndex((c) => c.id === payload.id) : -1;
    const checkCode = payload.checkCode?.trim() || this.getNextCheckCode();

    const checkRecord: InventoryCheck = {
      id: payload.id || 'chk-' + Date.now(),
      checkCode,
      checkDate: payload.checkDate || new Date().toISOString().split('T')[0],
      checkTime: payload.checkTime || new Date().toTimeString().slice(0, 5),
      performer: payload.performer || this.currentUser.fullName,
      participants: payload.participants || [
        this.currentUser.fullName + ' - Cán bộ Y tế học đường',
        'Ban Giám Hiệu trường',
        'Đại diện Kế toán / Thủ kho',
      ],
      notes: payload.notes || '',
      status: payload.status || 'draft',
      confirmedAt: payload.confirmedAt,
      confirmedBy: payload.confirmedBy,
      adjustedAt: payload.adjustedAt,
      adjustedBy: payload.adjustedBy,
      createdAt: payload.createdAt || new Date().toISOString(),
      items: payload.items || [],
    };

    if (existingIdx >= 0) {
      this.inventoryChecks[existingIdx] = checkRecord;
    } else {
      this.inventoryChecks.unshift(checkRecord);
    }

    this.logAudit(
      'Lập phiếu kiểm kê',
      `Lưu biên bản kiểm kê ${checkRecord.checkCode} (${checkRecord.items.length} mặt hàng). Trạng thái: ${checkRecord.status}`,
      checkRecord.id
    );

    this.saveAll();
    this.notify();
    return checkRecord;
  }

  public confirmInventoryCheck(checkId: string, approverName: string): InventoryCheck {
    const check = this.inventoryChecks.find((c) => c.id === checkId);
    if (!check) throw new Error('Không tìm thấy phiếu kiểm kê.');
    if (check.status === 'adjusted') {
      throw new Error('Phiếu kiểm kê này đã được điều chỉnh kho trước đó.');
    }

    check.status = 'confirmed';
    check.confirmedAt = new Date().toISOString();
    check.confirmedBy = approverName;

    this.logAudit(
      'Xác nhận kiểm kê',
      `Xác nhận biên bản kiểm kê ${check.checkCode}. Người duyệt: ${approverName}`,
      check.id
    );

    this.saveAll();
    this.notify();
    return check;
  }

  // 2-Step Workflow: Adjust inventory from confirmed or draft check
  public adjustInventoryFromCheck(
    checkId: string,
    approverName: string,
    adjustmentNotes?: string
  ): InventoryCheck {
    const check = this.inventoryChecks.find((c) => c.id === checkId);
    if (!check) throw new Error('Không tìm thấy phiếu kiểm kê.');
    if (check.status === 'adjusted') {
      throw new Error('Phiếu kiểm kê này đã được điều chỉnh kho trước đó.');
    }

    let adjustmentCount = 0;
    const adjustedDetails: string[] = [];

    for (const item of check.items) {
      if (item.difference !== 0) {
        const batch = this.batches.find((b) => b.id === item.batchId);
        if (batch) {
          const oldQty = batch.quantity;
          const newQty = item.actualQuantity;
          batch.quantity = newQty;
          adjustmentCount++;

          adjustedDetails.push(
            `${item.medicineName} (Lô ${item.batchNumber}): ${oldQty} -> ${newQty} ${item.unit} (chênh lệch: ${item.difference > 0 ? '+' : ''}${item.difference})`
          );
        }
      }
    }

    check.status = 'adjusted';
    check.adjustedAt = new Date().toISOString();
    check.adjustedBy = approverName;
    if (adjustmentNotes) {
      check.notes = (check.notes ? check.notes + ' | ' : '') + `Ghi chú điều chỉnh: ${adjustmentNotes}`;
    }

    this.logAudit(
      'ĐIỀU CHỈNH TỒN KHO THEO KIỂM KÊ',
      `Điều chỉnh số liệu kho theo biên bản ${check.checkCode}. Người duyệt: ${approverName}. Đã điều chỉnh ${adjustmentCount} mặt hàng: ${adjustedDetails.slice(0, 3).join('; ')}${adjustedDetails.length > 3 ? '...' : ''}`,
      check.id
    );

    this.saveAll();
    this.notify();
    return check;
  }

  // --- Data Integrity Check (Kiểm tra tính toàn vẹn dữ liệu) ---
  public checkDataIntegrity(): DataIntegrityIssue[] {
    const issues: DataIntegrityIssue[] = [];

    // 1. Check for negative batch quantities
    for (const batch of this.batches) {
      if (batch.quantity < 0) {
        const med = this.medicines.find((m) => m.id === batch.medicineId);
        issues.push({
          id: `issue-neg-${batch.id}`,
          type: 'negative_stock',
          severity: 'error',
          medicineId: batch.medicineId,
          medicineName: med?.name || 'Không xác định',
          batchNumber: batch.batchNumber,
          description: `Lô "${batch.batchNumber}" bị tồn âm: ${batch.quantity} ${med?.unit || ''}.`,
          suggestedAction: 'Điều chỉnh số lượng về 0 hoặc kiểm tra lại phiếu xuất.',
        });
      }

      // 2. Check for missing batch number
      if (!batch.batchNumber || !batch.batchNumber.trim()) {
        issues.push({
          id: `issue-nobatch-${batch.id}`,
          type: 'invalid_batch',
          severity: 'error',
          medicineId: batch.medicineId,
          description: 'Lô thuốc bị thiếu thông tin số lô hợp lệ.',
          suggestedAction: 'Bổ sung số lô nhận diện.',
        });
      }

      // 3. Check for invalid expiry date
      if (!batch.expDate || isNaN(new Date(batch.expDate).getTime())) {
        const med = this.medicines.find((m) => m.id === batch.medicineId);
        issues.push({
          id: `issue-nodate-${batch.id}`,
          type: 'invalid_batch',
          severity: 'warning',
          medicineId: batch.medicineId,
          medicineName: med?.name,
          batchNumber: batch.batchNumber,
          description: `Lô "${batch.batchNumber}" có định dạng ngày hết hạn không hợp lệ (${batch.expDate}).`,
          suggestedAction: 'Cập nhật lại ngày hết hạn chuẩn (YYYY-MM-DD).',
        });
      }
    }

    // 4. Check for medicine totalStock discrepancy vs sum of batches
    for (const med of this.medicines) {
      const medBatches = this.batches.filter((b) => b.medicineId === med.id);
      const sumQuantity = medBatches.reduce((acc, b) => acc + (b.quantity || 0), 0);
      if (med.totalStock !== sumQuantity) {
        issues.push({
          id: `issue-mismatch-${med.id}`,
          type: 'discrepancy',
          severity: 'warning',
          medicineId: med.id,
          medicineName: med.name,
          description: `Chênh lệch bộ đếm tổng tồn: Thuốc ghi nhận ${med.totalStock}, tổng các lô thực tế là ${sumQuantity}.`,
          suggestedAction: 'Chạy đồng bộ tự động để tính lại từ các lô.',
        });
      }
    }

    // 5. Check for transactions with invalid or negative items
    for (const tx of this.transactions) {
      if (tx.status !== 'cancelled') {
        for (const item of tx.items) {
          if (item.quantity <= 0) {
            issues.push({
              id: `issue-txzero-${tx.id}-${item.medicineId}`,
              type: 'transaction_mismatch',
              severity: 'error',
              description: `Phiếu ${tx.transactionCode} có mặt hàng với số lượng không hợp lệ (${item.quantity}).`,
              suggestedAction: 'Kiểm tra và hủy hoặc sửa phiếu giao dịch.',
            });
          }
        }
      }
    }

    return issues;
  }

  // Auto Heal / Fix Integrity Discrepancies
  public autoFixDataIntegrity(): { fixedCount: number; message: string } {
    let fixed = 0;

    // 1. Fix negative batches
    for (const batch of this.batches) {
      if (batch.quantity < 0) {
        batch.quantity = 0;
        fixed++;
      }
    }

    // 2. Re-sync all medicine totalStock
    for (const med of this.medicines) {
      const medBatches = this.batches.filter((b) => b.medicineId === med.id);
      const sumQuantity = medBatches.reduce((acc, b) => acc + (b.quantity || 0), 0);
      if (med.totalStock !== sumQuantity) {
        med.totalStock = sumQuantity;
        fixed++;
      }
    }

    this.saveAll();
    this.notify();

    return {
      fixedCount: fixed,
      message:
        fixed > 0
          ? `Đã tự động chuẩn hóa và đồng bộ thành công ${fixed} điểm dữ liệu kho!`
          : 'Toàn bộ dữ liệu kho thuốc và vật tư đã hoàn toàn toàn vẹn và chính xác 100%.',
    };
  }

  // --- Dashboard Summary Metrics ---
  public getDashboardMetrics() {
    const meds = this.getMedicines();
    const batches = this.batches;
    const warning30 = this.settings.warningExpiringDays;
    const warning60 = this.settings.warningNoticeDays || 60;

    const totalMedicineTypes = meds.length;
    const totalBatches = batches.length;
    const totalMedicineStock = batches.reduce((sum, b) => sum + (b.quantity || 0), 0);
    const totalMedicalSupplies = this.supplies.reduce((sum, s) => sum + (s.quantity || 0), 0);
    const totalSuppliesCount = this.supplies.length;

    // Valuation
    const totalInventoryValuation = batches.reduce(
      (sum, b) => sum + (b.quantity || 0) * (b.unitPrice || 0),
      0
    );

    // Expired batches
    const expiredBatches = batches.filter((b) => b.quantity > 0 && getDaysRemaining(b.expDate) < 0);

    // Expiring soon (0 <= days <= warning30)
    const expiringSoonBatches = batches.filter(
      (b) => b.quantity > 0 && getDaysRemaining(b.expDate) >= 0 && getDaysRemaining(b.expDate) <= warning30
    );

    // Expiring 60 days
    const expiring60Batches = batches.filter(
      (b) => b.quantity > 0 && getDaysRemaining(b.expDate) > warning30 && getDaysRemaining(b.expDate) <= warning60
    );

    // Safe batches
    const safeBatches = batches.filter((b) => b.quantity > 0 && getDaysRemaining(b.expDate) > warning60);

    // Low stock medicines (totalStock <= minStock and > 0)
    const lowStockMedicines = meds.filter((m) => m.totalStock > 0 && m.totalStock <= m.minStock);

    // Low stock supplies
    const lowStockSupplies = this.supplies.filter((s) => s.quantity <= s.minStock);

    // Out of stock medicines
    const outOfStockMedicines = meds.filter((m) => m.totalStock === 0);

    // Monthly counts
    const currentYearMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
    const monthlyImports = this.transactions.filter(
      (t) => t.type === 'import' && t.status === 'completed' && t.date.startsWith(currentYearMonth)
    );
    const monthlyExports = this.transactions.filter(
      (t) => t.type === 'export' && t.status === 'completed' && t.date.startsWith(currentYearMonth)
    );

    // Monthly trends for Recharts (last 6 months)
    const monthlyTrends: { month: string; imports: number; exports: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = `T${d.getMonth() + 1}/${d.getFullYear().toString().slice(-2)}`;

      const imps = this.transactions
        .filter((t) => t.type === 'import' && t.status === 'completed' && t.date.startsWith(ym))
        .reduce((sum, t) => sum + t.items.reduce((s, it) => s + it.quantity, 0), 0);

      const exps = this.transactions
        .filter((t) => t.type === 'export' && t.status === 'completed' && t.date.startsWith(ym))
        .reduce((sum, t) => sum + t.items.reduce((s, it) => s + it.quantity, 0), 0);

      monthlyTrends.push({
        month: label,
        imports: imps,
        exports: exps,
      });
    }

    // Category distribution for charts
    const categoryMap: Record<string, number> = {};
    for (const m of meds) {
      const cat = m.dosageForm || 'Khác';
      categoryMap[cat] = (categoryMap[cat] || 0) + 1;
    }
    const categoryStats = Object.entries(categoryMap).map(([name, count]) => ({ name, count }));

    // Phase 3 Metrics: Clinic & Student metrics
    const todayStr = new Date().toISOString().split('T')[0];
    const currentMonthPrefix = todayStr.substring(0, 7); // YYYY-MM

    const todayVisits = this.clinicVisits.filter((v) => v.visitDate === todayStr);
    const monthVisits = this.clinicVisits.filter((v) => v.visitDate.startsWith(currentMonthPrefix));

    const todayFirstAidCount = todayVisits.filter((v) => v.treatmentType === 'Sơ cứu').length;
    const todayParentContactCount = todayVisits.filter((v) => v.parentContacted).length;
    const todayTransfersCount = todayVisits.filter((v) => v.isTransferred || v.outcome === 'Chuyển viện').length;

    let todayMedicinesUsedCount = 0;
    for (const v of todayVisits) {
      todayMedicinesUsedCount += (v.medicinesUsed || []).reduce((sum, item) => sum + item.quantity, 0);
    }

    let todaySuppliesUsedCount = 0;
    for (const v of todayVisits) {
      todaySuppliesUsedCount += (v.suppliesUsed || []).reduce((sum, item) => sum + item.quantity, 0);
    }

    // Top reasons this month
    const reasonCounts: Record<string, number> = {};
    for (const v of monthVisits) {
      for (const r of v.reasons) {
        reasonCounts[r] = (reasonCounts[r] || 0) + 1;
      }
    }
    const topVisitReasonsMonth = Object.entries(reasonCounts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);

    // Visits by class this month
    const classVisitCounts: Record<string, number> = {};
    for (const v of monthVisits) {
      const c = v.className || 'Khác';
      classVisitCounts[c] = (classVisitCounts[c] || 0) + 1;
    }
    const visitsByClassMonth = Object.entries(classVisitCounts)
      .map(([className, count]) => ({ className, count }))
      .sort((a, b) => b.count - a.count);

    return {
      totalMedicineTypes,
      totalBatches,
      totalMedicineStock,
      totalMedicalSupplies,
      totalSuppliesCount,
      totalInventoryValuation,
      expiredCount: expiredBatches.length,
      expiringSoonCount: expiringSoonBatches.length,
      lowStockCount: lowStockMedicines.length,
      outOfStockCount: outOfStockMedicines.length,
      suppliesLowStockCount: lowStockSupplies.length,
      monthlyImportsCount: monthlyImports.length,
      monthlyExportsCount: monthlyExports.length,
      totalInventoryChecksCount: this.inventoryChecks.length,
      monthlyUsageCount: monthlyExports.length,
      expiredBatches,
      expiringSoonBatches,
      lowStockMedicines,
      outOfStockMedicines,
      lowStockSupplies,
      monthlyTrends,
      categoryStats,
      expiryBreakdown: {
        expired: expiredBatches.length,
        warning30: expiringSoonBatches.length,
        warning60: expiring60Batches.length,
        safe: safeBatches.length,
      },
      // Giai đoạn 3 metrics:
      totalStudentsCount: this.students.length,
      totalClassesCount: this.classes.length,
      todayVisitsCount: todayVisits.length,
      monthVisitsCount: monthVisits.length,
      todayFirstAidCount,
      todayParentContactCount,
      todayTransfersCount,
      todayMedicinesUsedCount,
      todaySuppliesUsedCount,
      topVisitReasonsMonth,
      visitsByClassMonth,
    };
  }

  // ==========================================
  // GIAI ĐOẠN 3: METHODS QUẢN LÝ HỌC SINH & PHÒNG Y TẾ
  // ==========================================

  // --- Students Management ---
  public getStudents(search?: string, className?: string, grade?: number): Student[] {
    let result = [...this.students];
    if (className && className !== 'all') {
      result = result.filter((s) => s.className === className);
    }
    if (grade && grade > 0) {
      result = result.filter((s) => s.grade === grade);
    }
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      result = result.filter(
        (s) =>
          s.fullName.toLowerCase().includes(q) ||
          s.studentCode.toLowerCase().includes(q) ||
          (s.parentPhone && s.parentPhone.includes(q)) ||
          (s.citizenId && s.citizenId.includes(q)) ||
          (s.healthInsuranceCode && s.healthInsuranceCode.toLowerCase().includes(q))
      );
    }
    return result;
  }

  public getStudentById(id: string): Student | undefined {
    return this.students.find((s) => s.id === id);
  }

  public getStudentByCode(code: string): Student | undefined {
    return this.students.find((s) => s.studentCode.toUpperCase() === code.trim().toUpperCase());
  }

  public addStudent(studentData: Omit<Student, 'id' | 'createdAt' | 'updatedAt'>): Student {
    if (!studentData.fullName?.trim()) {
      throw new Error('Họ và tên học sinh không được để trống.');
    }
    if (!studentData.studentCode?.trim()) {
      throw new Error('Mã học sinh không được để trống.');
    }
    const existing = this.getStudentByCode(studentData.studentCode);
    if (existing) {
      throw new Error(`Mã học sinh "${studentData.studentCode}" đã tồn tại trên hệ thống.`);
    }

    const now = new Date().toISOString();
    const newStudent: Student = {
      ...studentData,
      id: `stu-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: now,
      updatedAt: now,
    };

    this.students.push(newStudent);

    // Auto create basic health profile
    const newProfile: StudentHealthProfile = {
      id: `prof-${newStudent.id}`,
      studentId: newStudent.id,
      studentCode: newStudent.studentCode,
      fullName: newStudent.fullName,
      className: newStudent.className,
      bloodType: newStudent.bloodType,
      allergies: newStudent.allergies,
      chronicConditions: newStudent.chronicConditions,
      specialAttention: !!newStudent.specialAttention,
      emergencyContact: {
        name: newStudent.parentName || 'Phụ huynh',
        relationship: 'Phụ huynh',
        phone: newStudent.parentPhone || '',
      },
      notes: newStudent.notes,
      lastUpdated: now,
    };
    this.healthProfiles.push(newProfile);

    this.saveAll();
    this.logAudit('Thêm học sinh mới', `Đã thêm học sinh: ${newStudent.fullName} (${newStudent.studentCode}) - Lớp ${newStudent.className}`);
    this.notify();
    return newStudent;
  }

  public updateStudent(id: string, updates: Partial<Student>): Student {
    const idx = this.students.findIndex((s) => s.id === id);
    if (idx === -1) {
      throw new Error(`Không tìm thấy học sinh với ID: ${id}`);
    }

    const current = this.students[idx];
    if (updates.studentCode && updates.studentCode !== current.studentCode) {
      const existing = this.getStudentByCode(updates.studentCode);
      if (existing && existing.id !== id) {
        throw new Error(`Mã học sinh "${updates.studentCode}" đã được sử dụng.`);
      }
    }

    const updated: Student = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.students[idx] = updated;

    // Synchronize health profile
    const pIdx = this.healthProfiles.findIndex((p) => p.studentId === id);
    if (pIdx !== -1) {
      this.healthProfiles[pIdx] = {
        ...this.healthProfiles[pIdx],
        studentCode: updated.studentCode,
        fullName: updated.fullName,
        className: updated.className,
        bloodType: updated.bloodType,
        allergies: updated.allergies,
        chronicConditions: updated.chronicConditions,
        specialAttention: !!updated.specialAttention,
        lastUpdated: new Date().toISOString(),
      };
    }

    this.saveAll();
    this.logAudit('Cập nhật học sinh', `Đã cập nhật thông tin học sinh: ${updated.fullName} (${updated.studentCode})`);
    this.notify();
    return updated;
  }

  public deleteStudent(id: string): void {
    const idx = this.students.findIndex((s) => s.id === id);
    if (idx === -1) {
      throw new Error('Không tìm thấy học sinh cần xóa.');
    }
    const student = this.students[idx];

    // Check if student has clinic visits
    const visits = this.clinicVisits.filter((v) => v.studentId === id);
    if (visits.length > 0) {
      throw new Error(`Học sinh "${student.fullName}" đã có ${visits.length} lượt khám tại phòng y tế, không thể xóa trực tiếp để đảm bảo tính toàn vẹn y bạ.`);
    }

    this.students.splice(idx, 1);
    this.healthProfiles = this.healthProfiles.filter((p) => p.studentId !== id);
    this.saveAll();
    this.logAudit('Xóa học sinh', `Đã xóa học sinh: ${student.fullName} (${student.studentCode})`);
    this.notify();
  }

  public importStudentsFromExcel(studentsData: any[]): { added: number; errors: string[] } {
    let added = 0;
    const errors: string[] = [];

    for (let i = 0; i < studentsData.length; i++) {
      const row = studentsData[i];
      const rowNum = i + 2; // Excel row numbering
      try {
        const studentCode = String(row['Mã học sinh'] || row['studentCode'] || row['MaHS'] || '').trim();
        const fullName = String(row['Họ và tên'] || row['fullName'] || row['HoTen'] || '').trim();
        const className = String(row['Lớp'] || row['className'] || row['Lop'] || '').trim();
        const gender = String(row['Giới tính'] || row['gender'] || row['GioiTinh'] || 'Nam').trim();
        const birthDate = String(row['Ngày sinh'] || row['birthDate'] || row['NgaySinh'] || '2014-01-01').trim();
        const grade = parseInt(String(row['Khối'] || row['grade'] || className.charAt(0) || '6'), 10) || 6;
        const parentName = String(row['Phụ huynh'] || row['parentName'] || row['HoTenPhuHuynh'] || '').trim();
        const parentPhone = String(row['SĐT phụ huynh'] || row['parentPhone'] || row['SDT'] || '').trim();
        const healthInsuranceCode = String(row['Mã BHYT'] || row['healthInsuranceCode'] || row['BHYT'] || '').trim();
        const citizenId = String(row['CCCD/Định danh'] || row['citizenId'] || '').trim();
        const allergies = String(row['Dị ứng'] || row['allergies'] || '').trim();
        const chronicConditions = String(row['Bệnh nền'] || row['chronicConditions'] || '').trim();

        if (!studentCode || !fullName || !className) {
          errors.push(`Dòng ${rowNum}: Thiếu Mã học sinh, Họ tên hoặc Lớp.`);
          continue;
        }

        const existing = this.getStudentByCode(studentCode);
        if (existing) {
          errors.push(`Dòng ${rowNum}: Mã học sinh "${studentCode}" đã tồn tại.`);
          continue;
        }

        const now = new Date().toISOString();
        const newStu: Student = {
          id: `stu-${Date.now()}-${i}`,
          studentCode,
          fullName,
          className,
          grade,
          gender: gender.toLowerCase().includes('nữ') ? 'Nữ' : 'Nam',
          birthDate,
          schoolYear: '2026-2027',
          parentName: parentName || undefined,
          parentPhone: parentPhone || undefined,
          healthInsuranceCode: healthInsuranceCode || undefined,
          citizenId: citizenId || undefined,
          allergies: allergies || undefined,
          chronicConditions: chronicConditions || undefined,
          specialAttention: !!allergies || !!chronicConditions,
          createdAt: now,
          updatedAt: now,
        };

        this.students.push(newStu);

        this.healthProfiles.push({
          id: `prof-${newStu.id}`,
          studentId: newStu.id,
          studentCode: newStu.studentCode,
          fullName: newStu.fullName,
          className: newStu.className,
          bloodType: undefined,
          allergies: newStu.allergies,
          chronicConditions: newStu.chronicConditions,
          specialAttention: !!newStu.specialAttention,
          emergencyContact: {
            name: newStu.parentName || 'Phụ huynh',
            relationship: 'Phụ huynh',
            phone: newStu.parentPhone || '',
          },
          lastUpdated: now,
        });

        added++;
      } catch (err: any) {
        errors.push(`Dòng ${rowNum}: ${err.message}`);
      }
    }

    if (added > 0) {
      this.saveAll();
      this.logAudit('Import học sinh', `Đã import thành công ${added} học sinh từ tệp Excel.`);
      this.notify();
    }

    return { added, errors };
  }

  // --- Student Health Profiles ---
  public getStudentHealthProfile(studentId: string): StudentHealthProfile | undefined {
    return this.healthProfiles.find((p) => p.studentId === studentId);
  }

  public updateStudentHealthProfile(studentId: string, data: Partial<StudentHealthProfile>): StudentHealthProfile {
    const idx = this.healthProfiles.findIndex((p) => p.studentId === studentId);
    const now = new Date().toISOString();
    if (idx === -1) {
      const student = this.getStudentById(studentId);
      if (!student) throw new Error(`Không tìm thấy học sinh ID: ${studentId}`);
      const newProfile: StudentHealthProfile = {
        id: `prof-${studentId}`,
        studentId,
        studentCode: student.studentCode,
        fullName: student.fullName,
        className: student.className,
        specialAttention: false,
        emergencyContact: {
          name: student.parentName || 'Phụ huynh',
          relationship: 'Phụ huynh',
          phone: student.parentPhone || '',
        },
        ...data,
        lastUpdated: now,
      };
      this.healthProfiles.push(newProfile);
      this.saveAll();
      this.notify();
      return newProfile;
    }

    this.healthProfiles[idx] = {
      ...this.healthProfiles[idx],
      ...data,
      lastUpdated: now,
    };

    // Keep student in sync if critical health info changes
    const stuIdx = this.students.findIndex((s) => s.id === studentId);
    if (stuIdx !== -1) {
      if (data.bloodType !== undefined) this.students[stuIdx].bloodType = data.bloodType;
      if (data.allergies !== undefined) this.students[stuIdx].allergies = data.allergies;
      if (data.chronicConditions !== undefined) this.students[stuIdx].chronicConditions = data.chronicConditions;
      if (data.specialAttention !== undefined) this.students[stuIdx].specialAttention = data.specialAttention;
    }

    this.saveAll();
    this.logAudit('Cập nhật hồ sơ sức khỏe', `Đã cập nhật hồ sơ sức khỏe học sinh: ${this.healthProfiles[idx].fullName}`);
    this.notify();
    return this.healthProfiles[idx];
  }

  // --- Classes & School Years ---
  public getSchoolClasses(): SchoolClass[] {
    return [...this.classes];
  }

  public getSchoolYears(): string[] {
    return ['2026-2027', '2025-2026', '2024-2025'];
  }

  // --- Clinic Visits Management (Sổ tiếp nhận & Theo dõi phòng y tế) ---
  private normalizeClinicVisit(v: ClinicVisit): ClinicVisit {
    const dateTime =
      v.dateTime ||
      (v.visitDate ? `${v.visitDate}T${v.timeIn || '08:00'}:00` : new Date().toISOString());
    const reason =
      v.reason ||
      (v.reasons && v.reasons.length > 0 ? v.reasons.join(', ') : v.customReason || '');
    const treatment = v.treatment || v.treatmentDetails || v.treatmentType || '';
    const medicinesDispensed = v.medicinesDispensed || v.medicinesUsed || [];
    const temperature = v.temperature !== undefined ? v.temperature : v.vitals?.temperature;
    const pulse = v.pulse !== undefined ? v.pulse : v.vitals?.pulse;
    const bloodPressure = v.bloodPressure || v.vitals?.bloodPressure;
    const performer = v.performer || 'Cán bộ Y tế';
    return {
      ...v,
      dateTime,
      reason,
      treatment,
      medicinesDispensed,
      temperature,
      pulse,
      bloodPressure,
      performer,
    };
  }

  public getClinicVisits(filters?: {
    date?: string;
    className?: string;
    studentId?: string;
    reason?: string;
    month?: string;
  }): ClinicVisit[] {
    let result = this.clinicVisits.map((v) => this.normalizeClinicVisit(v));
    if (filters?.date) {
      result = result.filter((v) => v.visitDate === filters.date);
    }
    if (filters?.month) {
      result = result.filter((v) => v.visitDate.startsWith(filters.month!));
    }
    if (filters?.className && filters.className !== 'all') {
      result = result.filter((v) => v.className === filters.className);
    }
    if (filters?.studentId) {
      result = result.filter((v) => v.studentId === filters.studentId);
    }
    if (filters?.reason && filters.reason !== 'all') {
      result = result.filter(
        (v) => (v.reasons && v.reasons.includes(filters.reason!)) || v.reason?.includes(filters.reason!)
      );
    }
    return result.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  }

  public getClinicVisitById(id: string): ClinicVisit | undefined {
    const found = this.clinicVisits.find((v) => v.id === id);
    return found ? this.normalizeClinicVisit(found) : undefined;
  }

  public generateNextVisitCode(): string {
    const year = new Date().getFullYear();
    const prefix = `KB-${year}-`;
    const yearVisits = this.clinicVisits.filter((v) => v.visitCode && v.visitCode.startsWith(prefix));
    let maxSeq = 0;
    for (const v of yearVisits) {
      const parts = v.visitCode.split('-');
      if (parts.length >= 3) {
        const seq = parseInt(parts[2], 10);
        if (!isNaN(seq) && seq > maxSeq) maxSeq = seq;
      }
    }
    return `${prefix}${String(maxSeq + 1).padStart(4, '0')}`;
  }

  /**
   * Preview FEFO allocation for a medicine without modifying database
   */
  public previewFEFOForMedicine(
    medicineId: string,
    requestedQuantity: number
  ): { batch: MedicineBatch; quantity: number }[] {
    if (requestedQuantity <= 0) return [];
    const validBatches = this.batches
      .filter((b) => b.medicineId === medicineId && b.quantity > 0 && getDaysRemaining(b.expDate) >= 0)
      .sort((a, b) => new Date(a.expDate).getTime() - new Date(b.expDate).getTime());

    const allocation: { batch: MedicineBatch; quantity: number }[] = [];
    let needed = requestedQuantity;

    for (const b of validBatches) {
      if (needed <= 0) break;
      const take = Math.min(b.quantity, needed);
      allocation.push({ batch: b, quantity: take });
      needed -= take;
    }

    if (needed > 0) {
      throw new Error(
        `Không đủ tồn kho khả dụng (chưa hết hạn) cho thuốc này. Còn thiếu ${needed} đơn vị.`
      );
    }
    return allocation;
  }

  /**
   * Add a new clinic visit.
   * If medicines are specified, it automatically exports them from inventory using FEFO,
   * creates an InventoryTransaction, and links the transactionId.
   * If supplies are specified, it deducts the supply stocks.
   */
  public addClinicVisit(
    payload: Omit<ClinicVisit, 'id' | 'visitCode' | 'createdAt' | 'inventoryTransactionId'> & {
      visitCode?: string;
    }
  ): ClinicVisit {
    const student = this.getStudentById(payload.studentId);
    if (!student) {
      throw new Error(`Không tìm thấy học sinh với ID: ${payload.studentId}`);
    }

    if (!payload.reasons || payload.reasons.length === 0) {
      throw new Error('Vui lòng chọn ít nhất một lý do đến phòng y tế.');
    }
    if (!payload.treatmentDetails?.trim()) {
      throw new Error('Nội dung xử trí không được để trống.');
    }

    const visitCode = payload.visitCode || this.generateNextVisitCode();
    let inventoryTxId: string | undefined = undefined;

    // 1. Process Medication Usage: Must deduct via InventoryTransaction with FEFO
    const finalMedicinesUsed: ClinicVisitMedicineUsage[] = [];
    if (payload.medicinesUsed && payload.medicinesUsed.length > 0) {
      const itemsToExport: { medicineId: string; batchId?: string; quantity: number }[] = [];

      for (const m of payload.medicinesUsed) {
        if (m.quantity <= 0) continue;
        itemsToExport.push({
          medicineId: m.medicineId,
          batchId: m.batchId,
          quantity: m.quantity,
        });
      }

      if (itemsToExport.length > 0) {
        // Execute inventory export transaction
        const exportTx = this.exportMedicineTransaction({
          date: payload.visitDate,
          recipientName: student.fullName,
          recipientType: 'student',
          recipientClass: student.className,
          purpose: `Cấp phát phòng y tế - Ca khám ${visitCode} (${payload.reasons.join(', ')})`,
          performer: payload.performer || this.currentUser.fullName,
          notes: `Tình trạng ban đầu: ${payload.initialCondition}. Xử trí: ${payload.treatmentDetails}`,
          items: itemsToExport,
        });

        inventoryTxId = exportTx.id;

        // Map the allocated batches from the transaction items to medicinesUsed
        for (const item of exportTx.items) {
          const originalReq = payload.medicinesUsed.find((m) => m.medicineId === item.medicineId);
          finalMedicinesUsed.push({
            medicineId: item.medicineId,
            medicineCode: item.medicineCode,
            medicineName: item.medicineName,
            batchId: item.batchId,
            batchNumber: item.batchNumber,
            expDate: item.expDate || '',
            quantity: item.quantity,
            unit: item.unit,
            unitPrice: item.unitPrice,
            dosageInstructions: originalReq?.dosageInstructions || 'Theo chỉ định của cán bộ y tế',
          });
        }
      }
    }

    // 2. Process Medical Supplies Usage: Deduct from supplies stock
    const finalSuppliesUsed: ClinicVisitSupplyUsage[] = [];
    if (payload.suppliesUsed && payload.suppliesUsed.length > 0) {
      for (const s of payload.suppliesUsed) {
        if (s.quantity <= 0) continue;
        const sup = this.supplies.find((item) => item.id === s.supplyId);
        if (!sup) throw new Error(`Không tìm thấy vật tư y tế ID: ${s.supplyId}`);
        if (sup.quantity < s.quantity) {
          throw new Error(`Vật tư "${sup.name}" chỉ còn ${sup.quantity} ${sup.unit}, không đủ để cấp ${s.quantity}.`);
        }
        sup.quantity -= s.quantity;
        finalSuppliesUsed.push({
          supplyId: sup.id,
          supplyCode: sup.code,
          supplyName: sup.name,
          quantity: s.quantity,
          unit: sup.unit,
        });
      }
    }

    // 3. Create Clinic Visit Record
    const now = new Date().toISOString();
    const newVisit: ClinicVisit = {
      ...payload,
      id: `vis-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      visitCode,
      medicinesUsed: finalMedicinesUsed,
      suppliesUsed: finalSuppliesUsed,
      inventoryTransactionId: inventoryTxId,
      createdAt: now,
    };

    this.clinicVisits.unshift(newVisit);

    // 4. If vitals provided, optionally update student health profile
    if (payload.vitals?.weight || payload.vitals?.height) {
      const p = this.getStudentHealthProfile(student.id);
      if (p) {
        const height = payload.vitals.height || p.height;
        const weight = payload.vitals.weight || p.weight;
        let bmi = p.bmi;
        if (height && weight && height > 0) {
          const hM = height / 100;
          bmi = parseFloat((weight / (hM * hM)).toFixed(1));
        }
        this.updateStudentHealthProfile(student.id, { height, weight, bmi });
      }
    }

    this.saveAll();
    this.logAudit(
      'Tiếp nhận học sinh',
      `Đã ghi nhận ca khám ${newVisit.visitCode} cho học sinh ${newVisit.studentName} (${newVisit.className}). Lý do: ${newVisit.reasons.join(', ')}`
    );
    this.notify();
    return newVisit;
  }

  public updateClinicVisit(id: string, updates: Partial<ClinicVisit>): ClinicVisit {
    const idx = this.clinicVisits.findIndex((v) => v.id === id);
    if (idx === -1) throw new Error(`Không tìm thấy lượt khám ID: ${id}`);
    this.clinicVisits[idx] = {
      ...this.clinicVisits[idx],
      ...updates,
    };
    this.saveAll();
    this.logAudit('Cập nhật ca khám', `Cập nhật ca khám ${this.clinicVisits[idx].visitCode}`);
    this.notify();
    return this.clinicVisits[idx];
  }

  public deleteClinicVisit(id: string): void {
    const idx = this.clinicVisits.findIndex((v) => v.id === id);
    if (idx === -1) throw new Error('Không tìm thấy ca khám cần xóa.');
    const visit = this.clinicVisits[idx];

    // If there was an associated inventory transaction, cancel it
    if (visit.inventoryTransactionId) {
      try {
        this.cancelTransaction(visit.inventoryTransactionId, `Hủy do xóa ca khám ${visit.visitCode}`);
      } catch (err) {
        console.warn('Could not auto cancel linked inventory transaction', err);
      }
    }

    this.clinicVisits.splice(idx, 1);
    this.saveAll();
    this.logAudit('Xóa ca khám', `Đã xóa ca khám ${visit.visitCode} của học sinh ${visit.studentName}`);
    this.notify();
  }

  // --- Health Events (Sự kiện y tế / Tai nạn thương tích) ---
  public getHealthEvents(): HealthEvent[] {
    return [...this.healthEvents].sort((a, b) => b.dateTime.localeCompare(a.dateTime));
  }

  public addHealthEvent(data: Omit<HealthEvent, 'id' | 'eventCode'>): HealthEvent {
    const year = new Date().getFullYear();
    const prefix = `SK-${year}-`;
    const yearEvents = this.healthEvents.filter((e) => e.eventCode.startsWith(prefix));
    const nextSeq = yearEvents.length + 1;
    const eventCode = `${prefix}${String(nextSeq).padStart(4, '0')}`;

    const newEvent: HealthEvent = {
      ...data,
      id: `evt-${Date.now()}`,
      eventCode,
    };
    this.healthEvents.unshift(newEvent);
    this.saveAll();
    this.logAudit('Ghi nhận sự kiện y tế', `Ghi nhận sự kiện: ${newEvent.eventType} tại ${newEvent.location}`);
    this.notify();
    return newEvent;
  }

  public updateHealthEvent(id: string, data: Partial<HealthEvent>): HealthEvent {
    const idx = this.healthEvents.findIndex((e) => e.id === id);
    if (idx === -1) throw new Error('Không tìm thấy sự kiện y tế');
    this.healthEvents[idx] = { ...this.healthEvents[idx], ...data };
    this.saveAll();
    this.notify();
    return this.healthEvents[idx];
  }

  // --- Health Checkups (Khám sức khỏe định kỳ) ---
  public getHealthCheckups(filters?: { schoolYear?: string; className?: string; studentId?: string }): HealthCheckup[] {
    let result = [...this.healthCheckups];
    if (filters?.schoolYear && filters.schoolYear !== 'all') {
      result = result.filter((c) => c.schoolYear === filters.schoolYear);
    }
    if (filters?.className && filters.className !== 'all') {
      result = result.filter((c) => c.className === filters.className);
    }
    if (filters?.studentId) {
      result = result.filter((c) => c.studentId === filters.studentId);
    }
    return result.sort((a, b) => b.checkupDate.localeCompare(a.checkupDate));
  }

  public addHealthCheckup(data: Omit<HealthCheckup, 'id' | 'checkupCode' | 'createdAt'>): HealthCheckup {
    const year = new Date().getFullYear();
    const prefix = `KS-${year}-`;
    const yearCheckups = this.healthCheckups.filter((c) => c.checkupCode.startsWith(prefix));
    const nextSeq = yearCheckups.length + 1;
    const checkupCode = `${prefix}${String(nextSeq).padStart(4, '0')}`;

    const newCheckup: HealthCheckup = {
      ...data,
      id: `chk-${Date.now()}`,
      checkupCode,
      createdAt: new Date().toISOString(),
    };
    this.healthCheckups.unshift(newCheckup);

    // Sync back to student health profile
    const p = this.getStudentHealthProfile(data.studentId);
    if (p) {
      this.updateStudentHealthProfile(data.studentId, {
        height: data.height,
        weight: data.weight,
        bmi: data.bmi,
        visionLeft: data.eyesightLeft,
        visionRight: data.eyesightRight,
        dentalCondition: data.dentalCondition,
        specialAttention: data.hasRefraction || data.scoliosis || data.nutritionStatus !== 'Bình thường',
      });
    }

    this.saveAll();
    this.logAudit('Khám sức khỏe định kỳ', `Nhập kết quả khám sức khỏe cho học sinh: ${newCheckup.studentName}`);
    this.notify();
    return newCheckup;
  }

  // --- Reverse Lookups & Cross-Module Queries ---
  public getStudentHistory(studentId: string): {
    student?: Student;
    profile?: StudentHealthProfile;
    visits: ClinicVisit[];
    medicinesTaken: {
      date: string;
      medicineName: string;
      batchNumber: string;
      quantity: number;
      unit: string;
      visitCode: string;
    }[];
    suppliesUsed: {
      date: string;
      supplyName: string;
      quantity: number;
      unit: string;
      visitCode: string;
    }[];
    checkups: HealthCheckup[];
  } {
    const student = this.getStudentById(studentId);
    const profile = this.getStudentHealthProfile(studentId);
    const visits = this.clinicVisits.filter((v) => v.studentId === studentId);
    const checkups = this.healthCheckups.filter((c) => c.studentId === studentId);

    const medicinesTaken: any[] = [];
    const suppliesUsed: any[] = [];

    for (const v of visits) {
      for (const m of v.medicinesUsed || []) {
        medicinesTaken.push({
          date: v.visitDate,
          medicineName: m.medicineName,
          batchNumber: m.batchNumber,
          quantity: m.quantity,
          unit: m.unit,
          visitCode: v.visitCode,
        });
      }
      for (const s of v.suppliesUsed || []) {
        suppliesUsed.push({
          date: v.visitDate,
          supplyName: s.supplyName,
          quantity: s.quantity,
          unit: s.unit,
          visitCode: v.visitCode,
        });
      }
    }

    return {
      student,
      profile,
      visits,
      medicinesTaken,
      suppliesUsed,
      checkups,
    };
  }

  public getMedicineUsageHistory(medicineId: string): {
    visits: {
      visitCode: string;
      visitDate: string;
      studentName: string;
      className: string;
      batchNumber: string;
      quantity: number;
      unit: string;
      reason: string;
    }[];
    totalQuantity: number;
  } {
    const rows: any[] = [];
    let totalQuantity = 0;

    for (const v of this.clinicVisits) {
      for (const m of v.medicinesUsed || []) {
        if (m.medicineId === medicineId) {
          totalQuantity += m.quantity;
          rows.push({
            visitCode: v.visitCode,
            visitDate: v.visitDate,
            studentName: v.studentName,
            className: v.className,
            batchNumber: m.batchNumber,
            quantity: m.quantity,
            unit: m.unit,
            reason: v.reasons.join(', '),
          });
        }
      }
    }

    return { visits: rows, totalQuantity };
  }

  public getBatchUsageHistory(batchNumber: string): {
    visits: {
      visitCode: string;
      visitDate: string;
      studentName: string;
      className: string;
      medicineName: string;
      quantity: number;
      unit: string;
      reason: string;
    }[];
    totalQuantity: number;
  } {
    const rows: any[] = [];
    let totalQuantity = 0;

    for (const v of this.clinicVisits) {
      for (const m of v.medicinesUsed || []) {
        if (m.batchNumber === batchNumber) {
          totalQuantity += m.quantity;
          rows.push({
            visitCode: v.visitCode,
            visitDate: v.visitDate,
            studentName: v.studentName,
            className: v.className,
            medicineName: m.medicineName,
            quantity: m.quantity,
            unit: m.unit,
            reason: v.reasons.join(', '),
          });
        }
      }
    }

    return { visits: rows, totalQuantity };
  }

  public getClassClinicStats(className: string): {
    totalVisits: number;
    totalStudents: number;
    studentsWithVisitsCount: number;
    topReasons: { reason: string; count: number }[];
    visits: ClinicVisit[];
  } {
    const classVisits = this.clinicVisits.filter((v) => v.className === className);
    const classStudents = this.students.filter((s) => s.className === className);

    const visitedStudentIds = new Set(classVisits.map((v) => v.studentId));

    const reasonCounts: Record<string, number> = {};
    for (const v of classVisits) {
      for (const r of v.reasons) {
        reasonCounts[r] = (reasonCounts[r] || 0) + 1;
      }
    }

    const topReasons = Object.entries(reasonCounts)
      .map(([reason, count]) => ({ reason, count }))
      .sort((a, b) => b.count - a.count);

    return {
      totalVisits: classVisits.length,
      totalStudents: classStudents.length,
      studentsWithVisitsCount: visitedStudentIds.size,
      topReasons,
      visits: classVisits,
    };
  }

  public getMonthlyClinicReport(monthStr: string): {
    month: string;
    totalVisits: number;
    outcomes: Record<string, number>;
    healthEventsCount: number;
    byReason: Record<string, number>;
    medicinesUsed: { medicineName: string; quantity: number; unit: string }[];
    visitsByGrade: Record<number, number>;
    visitsByClass: { className: string; count: number }[];
    commonReasons: { reason: string; count: number; percentage: number }[];
    commonTreatments: { treatment: string; count: number }[];
    emergencyTransfersCount: number;
    parentContactedCount: number;
    medicinesUsedSummary: {
      medicineName: string;
      batchNumber: string;
      quantity: number;
      unit: string;
    }[];
    suppliesUsedSummary: {
      supplyName: string;
      quantity: number;
      unit: string;
    }[];
    events: HealthEvent[];
  } {
    const monthVisits = this.clinicVisits.filter((v) => v.visitDate.startsWith(monthStr));

    const visitsByGrade: Record<number, number> = { 6: 0, 7: 0, 8: 0, 9: 0 };
    const classMap: Record<string, number> = {};
    const reasonMap: Record<string, number> = {};
    const treatmentMap: Record<string, number> = {};
    const outcomes: Record<string, number> = {};
    let emergencyTransfersCount = 0;
    let parentContactedCount = 0;

    const medMap: Record<string, { medicineName: string; batchNumber: string; quantity: number; unit: string }> = {};
    const supMap: Record<string, { supplyName: string; quantity: number; unit: string }> = {};

    for (const v of monthVisits) {
      const student = this.getStudentById(v.studentId);
      if (student && student.grade) {
        visitsByGrade[student.grade] = (visitsByGrade[student.grade] || 0) + 1;
      }

      classMap[v.className] = (classMap[v.className] || 0) + 1;
      
      if (v.outcome) {
        outcomes[v.outcome] = (outcomes[v.outcome] || 0) + 1;
      }

      for (const r of v.reasons) {
        reasonMap[r] = (reasonMap[r] || 0) + 1;
      }

      if (v.treatmentType) {
        treatmentMap[v.treatmentType] = (treatmentMap[v.treatmentType] || 0) + 1;
      }

      if (v.isTransferred || v.outcome === 'Chuyển viện') {
        emergencyTransfersCount++;
      }
      if (v.parentContacted) {
        parentContactedCount++;
      }

      for (const m of v.medicinesUsed || []) {
        const key = `${m.medicineName}_${m.batchNumber}`;
        if (!medMap[key]) {
          medMap[key] = {
            medicineName: m.medicineName,
            batchNumber: m.batchNumber,
            quantity: 0,
            unit: m.unit,
          };
        }
        medMap[key].quantity += m.quantity;
      }

      for (const s of v.suppliesUsed || []) {
        if (!supMap[s.supplyName]) {
          supMap[s.supplyName] = {
            supplyName: s.supplyName,
            quantity: 0,
            unit: s.unit,
          };
        }
        supMap[s.supplyName].quantity += s.quantity;
      }
    }

    const totalReasons = Object.values(reasonMap).reduce((sum, c) => sum + c, 0) || 1;
    const commonReasons = Object.entries(reasonMap)
      .map(([reason, count]) => ({
        reason,
        count,
        percentage: parseFloat(((count / totalReasons) * 100).toFixed(1)),
      }))
      .sort((a, b) => b.count - a.count);

    const visitsByClass = Object.entries(classMap)
      .map(([className, count]) => ({ className, count }))
      .sort((a, b) => b.count - a.count);

    const commonTreatments = Object.entries(treatmentMap)
      .map(([treatment, count]) => ({ treatment, count }))
      .sort((a, b) => b.count - a.count);

    const events = this.healthEvents.filter((e) => e.dateTime.startsWith(monthStr));

    return {
      month: monthStr,
      totalVisits: monthVisits.length,
      outcomes,
      healthEventsCount: events.length,
      byReason: reasonMap,
      medicinesUsed: Object.values(medMap).map(m => ({
        medicineName: m.medicineName,
        quantity: m.quantity,
        unit: m.unit,
      })),
      visitsByGrade,
      visitsByClass,
      commonReasons,
      commonTreatments,
      emergencyTransfersCount,
      parentContactedCount,
      medicinesUsedSummary: Object.values(medMap),
      suppliesUsedSummary: Object.values(supMap),
      events,
    };
  }

  // Export JSON Backup (Updated to version 3.0 with complete student and clinic records)
  public exportBackupJson(): string {
    const backupData = {
      version: '3.0',
      exportedAt: new Date().toISOString(),
      schoolName: this.settings.schoolName,
      medicines: this.medicines,
      batches: this.batches,
      transactions: this.transactions,
      suppliers: this.suppliers,
      supplies: this.supplies,
      usageRecords: this.usageRecords,
      inventoryChecks: this.inventoryChecks,
      auditLogs: this.auditLogs,
      settings: this.settings,
      students: this.students,
      healthProfiles: this.healthProfiles,
      clinicVisits: this.clinicVisits,
      healthEvents: this.healthEvents,
      healthCheckups: this.healthCheckups,
      classes: this.classes,
    };
    return JSON.stringify(backupData, null, 2);
  }

  // Restore JSON Backup (Supports version 1, 2, and 3)
  public restoreBackupJson(jsonString: string) {
    try {
      const data = JSON.parse(jsonString);
      if (!data.medicines || !data.batches) {
        throw new Error('Định dạng tệp sao lưu không hợp lệ.');
      }
      this.medicines = data.medicines;
      this.batches = data.batches;
      this.transactions = data.transactions || [];
      this.suppliers = data.suppliers || DEFAULT_SUPPLIERS;
      this.supplies = data.supplies || [];
      this.usageRecords = data.usageRecords || [];
      this.inventoryChecks = data.inventoryChecks || [...INITIAL_INVENTORY_CHECKS];
      this.auditLogs = data.auditLogs || [];
      if (data.settings) this.settings = data.settings;
      if (data.students) this.students = data.students;
      if (data.healthProfiles) this.healthProfiles = data.healthProfiles;
      if (data.clinicVisits) this.clinicVisits = data.clinicVisits;
      if (data.healthEvents) this.healthEvents = data.healthEvents;
      if (data.healthCheckups) this.healthCheckups = data.healthCheckups;
      if (data.classes) this.classes = data.classes;
      this.saveAll();
      this.logAudit('Khôi phục dữ liệu', 'Đã khôi phục thành công từ tệp sao lưu dự phòng JSON');
      this.notify();
    } catch (err: any) {
      throw new Error(`Không thể khôi phục dữ liệu: ${err.message}`);
    }
  }
}

export const db = new AppDatabase();
